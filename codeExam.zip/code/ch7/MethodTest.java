// This source is an example application.
// You are granted a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// There, therefore is, not guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL WE BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
/**
 * This is another example of a fairly simple test.
 * It performs various timings of different types of method calls.
 */
public class MethodTest extends Test {

  private static final String NAME = "MethodTest";
  static final String synchObj = "SYNCH";

  static int testVar;

  private final static int ITERATIONS = 1000;
  private final static int CALL_ITERATIONS = 10000;
  private int numberOfVariations = 0;

  public MethodTest() {
    
  }

  public String getName() {
    return NAME;
  }

  public void displayResults() {
    super.displayResults();
    System.out.println("");

  }

  /**
   * The score here is the total score divided by the
   * number of variations in the test.
   */
  public long getScore() {
    long score = super.getScore();
    score = score / numberOfVariations;
    return score;
  }

  public void runTest() {

    int i, j;

    PerfMonitor mon = 
    new PerfMonitor("Local:\t\t\t\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        method();
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("Void Local:\t\t\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        voidMethod();
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("Local, 1 parameter:\t\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        method1Parm(1);
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("Local, 2 parameters:\t\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        method2Parm(1, 2);
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("Local, 3 String parameters:\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        method3StringParm("A", "AB", "ABC");
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("Local final:\t\t\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        finalMethod();
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("Local private:\t\t\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        privateMethod();
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("Local synchronized:\t\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        synchronizedMethod();
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("Local final synchronized:\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        finalSynchronizedMethod();
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("Local synchronized block:\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        synchronizedBlockMethod();
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("Static:\t\t\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        staticMethod();
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("Void Static:\t\t\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        staticVoidMethod();
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("Static, 1 parameter:\t\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        staticMethod1Parm(1);
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("Static, 2 parameters:\t\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        staticMethod2Parm(1, 2);
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("Static, 3 String parameters:\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        staticMethod3StringParm("A", "AB", "ABC");
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("Static final:\t\t\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        staticFinalMethod();
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("Static private:\t\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        staticPrivateMethod();
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("Static synchronized:\t\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        staticSynchronizedMethod();
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("Static final synchronized:\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        staticFinalSynchronizedMethod();
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("Static synchronized block:\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        staticSynchronizedBlockMethod();
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    MethodClass obj = new MethodClass();

    mon = new PerfMonitor("NonLocal:\t\t\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        obj.method();
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("Void NonLocal:\t\t\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        obj.voidMethod();
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("NonLocal, 1 parameter:\t\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        obj.method1Parm(1);
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("NonLocal, 2 parameters:\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        obj.method2Parm(1, 2);
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("NonLocal, 3 String parameters:\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        obj.method3StringParm("A", "AB", "ABC");
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("NonLocal final:\t\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        obj.finalMethod();
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("NonLocal synchronized:\t\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        obj.synchronizedMethod();
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("NonLocal final synchronized:\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        obj.finalSynchronizedMethod();
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("NonLocal synchronized block:\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        obj.synchronizedBlockMethod();
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("Interface:\t\t\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        obj.interfaceMethod();
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

    mon = new PerfMonitor("Interface 1 parameter:\t\t");
    for (i = 0; i < ITERATIONS; i++) {
      mon.startTiming(null);    
      for (j = 0; j < CALL_ITERATIONS; j++) {
        obj.interfaceMethod1Parm(1);
      }  
      mon.stopTiming(null);    

    }
    numberOfVariations++;

  }

  /* The following methods are
   * the instance methods to test.
   */
  int method () {
    return 0;
  }

  void voidMethod () {
    
  }

  int method1Parm (int parm1) {
    return parm1;
  }

  int method2Parm (int parm1, int parm2) {
    return parm1;
  }

  String method3StringParm (String parm1, String parm2, String parm3) {
    return parm1;
  }

  final int finalMethod () {
    return 0;
  }

  private int privateMethod () {
    return 0;
  }

  synchronized int synchronizedMethod () {
    return 0;
  }

  final synchronized int finalSynchronizedMethod () {
    return 0;
  }

  int synchronizedBlockMethod () {
    synchronized (synchObj) {
      return 0;
    }
  }

  static int staticMethod () {
    testVar++;
    return testVar;
  }

  static void staticVoidMethod () {
    testVar++;    
  }

  static int staticMethod1Parm (int parm1) {
    testVar++;
    return parm1+testVar;
  }

  static int staticMethod2Parm (int parm1, int parm2) {
    testVar++;
    return parm1+testVar;
  }

  static String staticMethod3StringParm (String parm1, String parm2, String parm3) {
    testVar++;
    return parm1;
  }

  static final int staticFinalMethod () {
    testVar++;
    return testVar;
  }

  static private int staticPrivateMethod () {
    testVar++;
    return testVar;
  }

  static synchronized int staticSynchronizedMethod () {
    return 0;
  }

  static final synchronized int staticFinalSynchronizedMethod () {
    testVar++;
    return testVar;
  }

  static int staticSynchronizedBlockMethod () {
    synchronized (synchObj) {
      testVar++;
      return testVar;
    }
  }

}