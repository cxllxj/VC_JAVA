// This source is an example application.
// You are granted a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// There, therefore is, not guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL WE BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
public class MethodClass implements MethodInterface {

  static final String synchObj = "SYNCH";

  static int testVar;

  public int method () {
    return 0;
  }

  public void voidMethod () {
    
  }

  public int method1Parm (int parm1) {
    return parm1;
  }

  public int method2Parm (int parm1, int parm2) {
    return parm1;
  }

  public String method3StringParm (String parm1, String parm2, String parm3) {
    return parm1;
  }

  public final int finalMethod () {
    return 0;
  }

  synchronized int synchronizedMethod () {
    return 0;
  }

  public final synchronized int finalSynchronizedMethod () {
    return 0;
  }

  public int synchronizedBlockMethod () {
    synchronized (synchObj) {
      return 0;
    }
  }

  public static int staticMethod () {
    testVar++;
    return testVar;
  }

  public static void staticVoidMethod () {
    
  }

  public static int staticMethod1Parm (int parm1) {
    testVar++;
    return parm1+testVar;
  }

  public static int staticMethod2Parm (int parm1, int parm2) {
    testVar++;
    return parm1+testVar;
  }

  public static String staticMethod3StringParm (String parm1, String parm2, String parm3) {
    testVar++;
    return parm1;
  }

  public static final int staticFinalMethod () {
    testVar++;
    return testVar;
  }

  public static synchronized int staticSynchronizedMethod () {
    testVar++;
    return testVar;
  }

  public static final synchronized int FinalSynchronizedMethod () {
    testVar++;
    return testVar;
  }

  public static int staticSynchronizedBlockMethod () {
    synchronized (synchObj) {
      testVar++;
      return testVar;
    }
  }

  public int interfaceMethod () {
    return 0;
  }

  public int interfaceMethod1Parm (int parm1) {
    return parm1;
  }

}

