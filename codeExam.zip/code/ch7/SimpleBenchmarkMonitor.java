// This source is an example application.
// You are granted a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// There, therefore is, not guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL WE BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
import java.util.*;
import java.io.*;

public class SimpleBenchmarkMonitor extends PerfMonitor {

  private long  minimumTime;      // fastest individual time
  private int minimumTransaction; // Which one was the minimum
  private long  maximumTime;      // slowest individual time
  private int maximumTransaction; // Which one was the maximum

  /**
    * Constructs a SimpleBenchmarkMonitor that has a major id of "General"
    * and a minor id specified as input. 
    * @param id minor id used to identify the SimpleBenchmarkMonitor 
    **/
  public SimpleBenchmarkMonitor (String id) {
    super(id); 
  }

  /**
    * Constructs a SimpleBenchmarkMonitor that has a major id of classId
    * and a minor id specified as input. 
    * @param classid major id used to identify the SimpleBenchmarkMonitor
    * @param id minor id used to identify the SimpleBenchmarkMonitor 
    **/
  public SimpleBenchmarkMonitor (String classId, String id) {
    super(classId, id); 
  }

  /**
    * Constructs a SimpleBenchmarkMonitor that has a major id of "General"
    * and an empty string for the minor id.
    **/
  public SimpleBenchmarkMonitor () {
    super();
  }

  public void printMonitor(PrintWriter out) {
    super.printMonitor(out);

    // Also print out the minimum and maximum transaction times
    out.println("The minimum time for an iteration was: " + 
                minimumTime + " milliseconds.");
    out.println("  This occurred on iteration number : " + 
                minimumTransaction + ".");
    out.println("The maximum time for an iteration was: " + 
                maximumTime + " milliseconds.");
    out.println("  This occurred on iteration number : " + 
                maximumTransaction + ".");
    out.flush();
  }

  public void clearMonitor() {
    super.clearMonitor();
    minimumTime = 0;
    minimumTransaction = 0;
    maximumTime = 0;
    maximumTransaction = 0;
  }

  public long stopTiming(Object obj) {

    long transaction_time = super.stopTiming(obj);

    // Keep track of the minimum and maximum
    // times.
    if (transaction_time < minimumTime ||
        minimumTime == 0) {
      minimumTime = transaction_time;
      minimumTransaction = getEventCount();
    }
    if (transaction_time > maximumTime) {
      maximumTime = transaction_time;
      maximumTransaction = getEventCount();
    }                              

    return transaction_time;
  }
}
