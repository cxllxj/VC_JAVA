// This source is an example application.
// You are granted a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// There, therefore is, not guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL WE BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
/**
 * This is another example of a fairly simple test.
 * It performs various timings of different types of loops.
 */
public class LoopTest extends Test {

  private static final String NAME = "LoopTest";
  static final String synchObj = "SYNCH";

  private final static int ITERATIONS = 1000;
  private final static int CALL_ITERATIONS = 10000;
  private int numberOfVariations = 0;

  public LoopTest() {
    
  }

  public String getName() {
    return NAME;
  }

  public void displayResults() {
    super.displayResults();
    System.out.println("");

  }

  /**
   * The score here is the total score divided by the
   * number of variations in the test.
   */
  public long getScore() {
    long score = super.getScore();
    score = score / numberOfVariations;
    return score;
  }

  public void runTest() {

    int i, j;

    PerfMonitor mon = 
       new PerfMonitor("Single loop:\t\t\t\t");
    mon.startTiming(null);    
    for (i = 0; i < ITERATIONS*CALL_ITERATIONS; i++) {
    }
    mon.stopTiming(null);    

    numberOfVariations++;

    mon = new PerfMonitor("Double loop:\t\t\t");
    mon.startTiming(null);    
    for (i = 0; i < ITERATIONS; i++) {
      for (j = 0; j < CALL_ITERATIONS; j++) {
      }  
    }
    mon.stopTiming(null);    
    numberOfVariations++;

    int var1 = 0;
    mon = new PerfMonitor("Loop 1 var:\t\t");
    mon.startTiming(null);    
    for (i = 0; i < ITERATIONS; i++) {
      for (j = 0; j < CALL_ITERATIONS; j++) {
        var1++;
      }  
    }
    mon.stopTiming(null);
    int var2 = var1;
    numberOfVariations++;

  }
}