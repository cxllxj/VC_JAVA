// This source is an example application.
// You are granted a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// There, therefore is, not guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL WE BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
import java.io.*;
import java.util.*;

/**
 * This is the root class for driving benchmarks. Extend 
 * it for a specific benchmark you are interested in.
 */
public abstract class Benchmark {
  public static final byte NON_NUMERIC_ENTRY = -99;
  public static final byte EXIT_CHOICE = 0;
  public static final byte RUN_ALL_CHOICE = 1;
  public static final byte NUMBER_OF_CHOICES = 2;

  // This attribute will hold tests the benchmark measures
  private java.util.Vector tests;
  private java.util.Vector setups;

  private long score;
  private long geometricMean = 1;
  private int menuChoices;

  /**
   * Public default constructor
   */
  public Benchmark() {
    tests = new java.util.Vector(10);
    setups = new java.util.Vector(10);
  }

  /**
   * This method should be overridden if you want to produce 
   * specific total resultsfor your own benchmark. This 
   * default behavior will produce a cumulative score and
   * the geometric mean of the scores for all tests run.
   */
  public void displayTestTotals() {

    Butil.textOut("The total cumulative score for the" +
                       " tests was " + score);
    Butil.textOut("The geometric mean of the scores for" +
                       " the tests was " + 
                       Math.pow(geometricMean,
                                (1/(double)tests.size())));
  }

  /**
   * Add a Test to the total score for the benchmark.
   * This method should be overridden if you want to produce 
   * specific total results for your own benchmark.
   * @param Test
   */
  public void addToGlobalScore(Test test) {

    score += test.getScore();
    geometricMean *= test.getScore();
  }

  /**
   * This method adds tests to the suite of tests being 
   * measured.
   * @param Test the test to add
   */
  public void addTest(Test test) {
    tests.addElement(test);
  }

  /**
   * This method adds set up actions to the menu. 
   * 
   * @param Setup the set up to add
   */
  public void addSetup(Setup setup) {
    setups.addElement(setup);
  }

  /**
   * This method actually drives the test suite.
   */
  public void doIt() {
    short selection = 0;

    int numTests = tests.size();
    int numSetups = setups.size();

    if (numTests == 0) {
      Butil.textOut("You must specify at least one test!");
      return;
    }

    while (true) { // do forever

      printMenu(selection);

      selection = (short)getNumericInput();

      if (selection != NON_NUMERIC_ENTRY) {

        switch (selection) {
        
        case EXIT_CHOICE:  // Exit the Benchmark
          {
            Butil.textOut("Benchmark complete.");
            return;
          }

        case RUN_ALL_CHOICE: // Run all tests
          { 
            for (int i = 0; i < numTests; i++) {
              // run a test
              ((Test)tests.elementAt(i)).runTest();
              // add its score to the global score
              addToGlobalScore((Test)tests.elementAt(i));
              // display the results for the specific test
              ((Test)tests.elementAt(i)).displayResults();
            }

            // display the results for all the tests
            displayTestTotals();

            break;
          }

        default:  // Run a specific test
          {
           int testNumber = selection - NUMBER_OF_CHOICES;
           if (testNumber < numSetups) {
            ((Setup)setups.elementAt(testNumber)).runSetup();
            } else {
              testNumber -= numSetups;

              if (testNumber > numTests) {
                Butil.textOut("You don't have that many tests!");
              } else {
               ((Test)tests.elementAt(testNumber)).runTest();
               ((Test)
               tests.elementAt(testNumber)).displayResults();
              }
            }

            break;
          }
        }  // switch
      }
    }  // while
  }

  /**
   * Print a nice menu based on all of the tests in the 
   * suite.
   */
  private void printMenu(short selection) {
    if (selection != NON_NUMERIC_ENTRY) {
      Butil.textOut("");
      Butil.textOut(EXIT_CHOICE + ". Exit Benchmark.");
      Butil.textOut(RUN_ALL_CHOICE + ". Run all tests.");

      // at least this many choices
      menuChoices = NUMBER_OF_CHOICES; 

      // print the names of the setup actions in a menu
      for (int i = 0; i < setups.size(); i++) {
        Butil.textOut((i+menuChoices) + ". Run " +
                    ((Setup)setups.elementAt(i)).getName());
      }

      menuChoices += setups.size();

      // print the names of each individual test in a menu
      for (int i = 0; i < tests.size(); i++) {
        Butil.textOut((i+menuChoices) + ". Run " +
                      ((Test)tests.elementAt(i)).getName());
      }

      menuChoices += tests.size();
    }
    Butil.textOut("");
    Butil.textOut("Enter selection here: ");
  }

  /**
   * Helper method to read a number.
   */
  private synchronized static int getNumericInput() {

    BufferedReader input = 
    new BufferedReader(new InputStreamReader(System.in));

    String keyboard_input;
    int number = 0;
    try {
      keyboard_input = input.readLine();
      number = Integer.valueOf(keyboard_input).intValue();
    } catch (IOException exception) {
      Butil.textOut("An IO Exception occured");
    } catch (NumberFormatException exception) {
      Butil.textOut("Invalid numeric entered");
      number = NON_NUMERIC_ENTRY;
    }
    return number;
  }
}

