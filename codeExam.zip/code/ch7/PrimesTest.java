// This source is an example application.
// You are granted a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// There, therefore is, not guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL WE BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
/**
 * This is a simple test that generates
 * prime numbers and times that.
 */
 public class PrimesTest extends Test {

  private int iterations;
  private int numberOfPrimes;
  private int numberOfPrimesFound;
  private static final String NAME = "PrimesTest";

  public PrimesTest(int iterationsIn, int number_of_primesIn) {
     super();
     iterations = iterationsIn;
     numberOfPrimes= number_of_primesIn;
  }

  public void runTest() {

    // Create a simple monitor that records more than the default
    SimpleBenchmarkMonitor mon = new SimpleBenchmarkMonitor(NAME);

    // find all the prime numbers from 2 to numberOfPrimes, 
    // iterations times
    for (int i = 0; i < iterations; i++) {
      mon.startTiming(null);    

       numberOfPrimesFound += eratosthenes(numberOfPrimes);

      mon.stopTiming(null);    
    }
  }

  public String getName() {
    return NAME;
  }

  public void displayResults() {
    super.displayResults();
    System.out.println("The " + getName() + " Test found " + 
                       (numberOfPrimesFound * iterations) + 
                       " prime numbers.");
    System.out.println("");
  }

  /**
   * This override of the default getScore method
   * returns a result of the default score divided
   * by 100. In this case a lower value is better.
   */
  public long getScore()
  {
    long score = super.getScore();
    score = score / 100;
    return score;
  }

  public int eratosthenes(int numberToLookAt) {
    // no even number is prime so don't bother looking
    int max = numberToLookAt/2;
    if ((numberToLookAt % 2) == 0) // remove the last even
      max = max - 1;

    // If bit i is 0 then the number (i*2)+1 is prime
    // Assume all the numbers are prime, already set 
    java.util.BitSet possiblePrimes = new java.util.BitSet(max);

    int countOfPrimes = 1; // 2 is prime
    int currentBit = 1, step = 3, nextNonPrime = 4;
    while (nextNonPrime <= max) {
      if (possiblePrimes.get(currentBit) == false) {
        countOfPrimes++;
        int nonPrime = nextNonPrime;
        while (nonPrime <= max) {
          possiblePrimes.set(nonPrime);
          nonPrime += step;
        }
      }

      currentBit++;
      step += 2;
      nextNonPrime += ((2 * step) - 2);
    }

    for (; currentBit <= max; ++currentBit) {
      if (possiblePrimes.get(currentBit) == false)
        countOfPrimes++;
    }
    return countOfPrimes;
  }
}