// This source is an example application.
// You are granted a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// There, therefore is, not guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL WE BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
import java.util.BitSet;

public class Primes {
  public int eratosthenes1(int numberToLookAt) {
    // no even number is prime so don't bother looking 
    int max = numberToLookAt/2;
    if ((numberToLookAt % 2) == 0) // remove the last even
      max = max - 1;

    // If bit i is 1 then the number (i*2)+1 is prime
    BitSet possiblePrimes = new BitSet(max+1);
    // Assume all the numbers are prime, set them to true
    for (int i = 1; i <= max; i++)
      possiblePrimes.set(i);

    int countOfPrimes = 1; // 2 is prime
    int currentBit = 1, step = 3, nextNonPrime = 4;
    while (nextNonPrime <= max) {
      if (possiblePrimes.get(currentBit)) {
        countOfPrimes++;
        int nonPrime = nextNonPrime;
        while (nonPrime <= max) {
          possiblePrimes.clear(nonPrime);
          nonPrime += step;
        }
      }

      currentBit++;
      step += 2;
      nextNonPrime += ((2 * step) - 2);
    }

    for (; currentBit <= max; ++currentBit) {
      if (possiblePrimes.get(currentBit))
        countOfPrimes++;
    }
    return countOfPrimes;
  }

  public int eratosthenes2(int numberToLookAt) {
    // no even number is prime so don't bother looking
    int max = numberToLookAt/2;
    if ((numberToLookAt % 2) == 0) // remove the last even
      max = max - 1;

    // If bit i is 0 then the number (i*2)+1 is prime
    // Assume all the numbers are prime, already set 
    BitSet possiblePrimes = new BitSet(max+1);

    int countOfPrimes = 1; // 2 is prime
    int currentBit = 1, step = 3, nextNonPrime = 4;
    while (nextNonPrime <= max) {
      if (possiblePrimes.get(currentBit) == false) {
        countOfPrimes++;
        int nonPrime = nextNonPrime;
        while (nonPrime <= max) {
          possiblePrimes.set(nonPrime);
          nonPrime += step;
        }
      }

      currentBit++;
      step += 2;
      nextNonPrime += ((2 * step) - 2);
    }

    for (; currentBit <= max; ++currentBit) {
      if (possiblePrimes.get(currentBit) == false)
        countOfPrimes++;
    }
    return countOfPrimes;
  }

  public int eratosthenes3(int numberToLookAt) {
    // no even number is prime so don't bother looking
    int max = numberToLookAt/2;
    if ((numberToLookAt % 2) == 0) // remove the last even
      max = max - 1;

    // If bit i is 0 then the number (i*2)+1 is prime
    // Assume all the numbers are prime, already set 
    boolean[] possiblePrimes = new boolean[max+1];

    int countOfPrimes = 1; // 2 is prime
    int currentBit = 1, step = 3, nextNonPrime = 4;
    while (nextNonPrime <= max) {
      if (possiblePrimes[currentBit] == false) {
        countOfPrimes++;
        int nonPrime = nextNonPrime;
        while (nonPrime <= max) {
          possiblePrimes[nonPrime] = true;
          nonPrime += step;
        }
      }

      currentBit++;
      step += 2;
      nextNonPrime += ((2 * step) - 2);
    }

    for (; currentBit <= max; ++currentBit) {
      if (possiblePrimes[currentBit] == false)
        countOfPrimes++;
    }
    return countOfPrimes;
  }

  public static void main(String[] s) {
    int n = 1000000;
    Primes p = new Primes();
    int count = 0;

    long time1 = System.currentTimeMillis();
    count = p.eratosthenes1(n);
    long time2 = System.currentTimeMillis();
    System.out.println("eratosthenes1 found " + count + 
                       " primes in the first " + n + 
                       " numbers in " + (time2-time1) + 
                       " milliseconds");

    time1 = System.currentTimeMillis();
    count = p.eratosthenes2(n);
    time2 = System.currentTimeMillis();
    System.out.println("eratosthenes2 found " + count + 
                       " primes in the first " + n + 
                       " numbers in " + (time2-time1) + 
                       " milliseconds");

    time1 = System.currentTimeMillis();
    count = p.eratosthenes3(n);
    time2 = System.currentTimeMillis();
    System.out.println("eratosthenes3 found " + count + 
                       " primes in the first " + n + 
                       " numbers in " + (time2-time1) + 
                       " milliseconds");

  }
}
