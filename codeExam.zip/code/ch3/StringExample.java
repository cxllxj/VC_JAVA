// This source is an example application.
// You are granted a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// There, therefore is, not guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL WE BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
import java.util.*;
public class StringExample {

  public static String generateFileName (String dataDir, 
                                         long idHigh, 
                                         long idLow) {
    String result;
    result = dataDir + java.io.File.pathSeparator + idHigh + 
             java.io.File.separator + idLow;

    return result;
  }

  public static String generateFileNameFast (String dataDir, 
                                             long idHigh, 
                                             long idLow) {
    int pos;
    char buffer[] = new char[128];

    pos = privLong32(idLow, 127, buffer);
    buffer[--pos] = java.io.File.separatorChar;
    pos = privLong32(idHigh, (pos-1), buffer);

    if (dataDir != null) {
      buffer[--pos] = java.io.File.pathSeparatorChar;
      int len = dataDir.length();
      if (pos > len) {
        dataDir.getChars(0, len, buffer, (pos - len));
        pos = pos - len;
      }
    }

    return new String(buffer, pos, (128-pos));
  }

  private static final char privDigitToChar(int i) {
    char c;

    c = (char)('0' + i);
    if (c > '9') {
      c = (char)(c + (char)('a' - '9' - 1));
    }

    return c;
  }

  private static final int privLong32(long val, int pos, 
                                      char buf[]) {
    int i = pos;

    do {
      buf[i] = privDigitToChar((int)(val & 31L));
      val>>>= 5;
      i--;
    } while ((i >= 0) && (val != 0));

    if (val == 0)
      i++;

    return i;
  }

  public static void main(String [] argv) {

    long idHigh = 123456;
    long idLow = 123456;

    long time1 = System.currentTimeMillis();

    for (int i=0; i < 10000; ++i) {
      generateFileName("Dirname", idHigh, idLow);
    }

    long time2 = System.currentTimeMillis();
    System.out.println("generateFileName took " 
                       + (time2-time1) + " milliseconds");


    time1 = System.currentTimeMillis();

    for (int i=0; i < 10000; ++i) {
      generateFileNameFast("Dirname", idHigh, idLow);
    }

    time2 = System.currentTimeMillis();
    System.out.println("generateFileNameFast took " 
                       + (time2-time1) + " milliseconds");

  }
}
