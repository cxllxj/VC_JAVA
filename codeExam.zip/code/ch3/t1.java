// This source is an example application.
// You are granted a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// There, therefore is, not guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL WE BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
import java.util.*;
public class t1 {

  public String buildName(String firstName, String middleName, String lastName) {
    String name = firstName.concat(" ");
    name = name.concat(middleName);
    name = name.concat(" ");
    name = name.concat(lastName);
    return name;
  }

  public String buildName2(String firstName, String middleName, String lastName) {
    StringBuffer buf = new StringBuffer(firstName);
    buf.append(" ");
    buf.append(middleName);
    buf.append(" ");
    buf.append(lastName);
    return buf.toString();
  }

  static void m1(String stringToParse) {
    // Create a tokenizer that will break the string at a comma
    StringTokenizer st = new StringTokenizer(stringToParse, ",");
    String sub1 = null;
    try {
      while (true) {
        sub1 = (String)st.nextToken();
        // Do wonderful things with sub1
      }
    } catch (NoSuchElementException ex) {
      
    }
  }

  static void m2(String stringToParse) {
    String sub1 = null;
    int i1=0;
    int i2;

    // find the index of the first comma
    i2 = stringToParse.indexOf(',');

    while (i2 >= 0) {
      sub1 = stringToParse.substring(i1, i2);

      if (sub1.length() > 0) {
        // Do wonderful things with sub1
      }

      // skip over the comma
      i1 = i2+1;
      // look for commas from our last position
      i2 = stringToParse.indexOf(',', i1);
    }

    // get final substring
    sub1 = stringToParse.substring(i1);
    
    if (sub1.length() > 0) {
      // Do wonderful things with sub1
    }
  }

  public static void main(String [] argv) {

    long time1 = System.currentTimeMillis();

    for (int i=0; i < 1000; ++i) {
      m1("ab,c,def,g,hij,k");
    }

    long time2 = System.currentTimeMillis();
    System.out.println("m1 took " + (time2-time1) + " milliseconds");

    time1 = System.currentTimeMillis();

    for (int i=0; i < 1000; ++i) {
      m2("ab,c,def,g,hij,k");
    }

    time2 = System.currentTimeMillis();
    System.out.println("m2 took " + (time2-time1) + " milliseconds");
  }
}
