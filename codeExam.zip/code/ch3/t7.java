// This source is an example application.
// You are granted a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// There, therefore is, not guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL WE BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
import java.util.*;
public class t7 {

    public static void method1(Enumeration someEnum) {
        String s1;
        while (someEnum.hasMoreElements()) {
            Object someObject = someEnum.nextElement();
        }
    }

    public static void method2(Enumeration someEnum) {
        try {
            while (true) {
                Object someObject = someEnum.nextElement();
            }
        } catch (NoSuchElementException e) {

        }
    }

    public static void main(String [] argv) {
        try {
            java.util.Hashtable ht = new Hashtable();

            ht.put("A","A");ht.put("B","A");
            ht.put("C","A");ht.put("D","A");
            ht.put("E","A");ht.put("F","A");
            ht.put("G","A");ht.put("H","A");
            ht.put("I","A");ht.put("J","A");
            ht.put("K","A");ht.put("L","A");
            ht.put("M","A");ht.put("N","A");
            ht.put("O","A");ht.put("P","A");
            ht.put("Q","A");ht.put("R","A");
            ht.put("S","A");ht.put("T","A");
            ht.put("U","A");ht.put("V","A");
            ht.put("W","A");ht.put("X","A");
            ht.put("Y","A");ht.put("Z","A");

            java.util.Enumeration enum = ht.keys();

            long time1 = System.currentTimeMillis();

            for (int i=0; i < 100000; ++i) {
                method1(enum);
            }

            long time2 = System.currentTimeMillis();
            System.out.println("method1 took " + (time2-time1) + " milliseconds");

            enum = ht.keys();
            time1 = System.currentTimeMillis();

            for (int i=0; i < 100000; ++i) {
                method2(enum);
            }

            time2 = System.currentTimeMillis();
            System.out.println("method2 took " + (time2-time1) + " milliseconds");
        } catch (Exception e) {

        }

    }
}
