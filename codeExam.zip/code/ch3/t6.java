// This source is an example application.
// You are granted a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// There, therefore is, not guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL WE BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
import java.util.*;
public class t6 {

  public void exceptionMeth1() {
    try {
      method1();
    } catch (Method1Exception e) {
      // do something with the exception
      
    }
    try {
      method2();
    } catch (Method2Exception e) {
      // do something with the exception
      
    }
    try {
      method3();
    } catch (Method3Exception e) {
      // do something with the exception 
      
    }
  }

  public void exceptionMeth2() {
    try {
      method1();
      method2();
      method3();
    } catch (Method1Exception e1) {
      // do something with exception 1 
      
    } catch (Method2Exception e2) {
      // do something with exception 2 
      
    } catch (Method3Exception e3) {
      // do something with exception 3 
      
    }
  }

  public void exceptionMeth3() throws Method1Exception, 
                                      Method2Exception, 
                                      Method3Exception {
    method1();
    method2();
    method3();
  }

  public void method1() throws Method1Exception {
  }

  public void method2() throws Method2Exception {
  }

  public void method3() throws Method3Exception {
  }

  public static void main(String [] argv) {
     try {

     t6 obj = new t6();
     long time1 = System.currentTimeMillis();

    for (int i=0; i < 10000000; ++i) {
      obj.exceptionMeth1();
    }

    long time2 = System.currentTimeMillis();
    System.out.println("e1 took " + (time2-time1) + " milliseconds");

     time1 = System.currentTimeMillis();

    for (int i=0; i < 10000000; ++i) {
      obj.exceptionMeth2();
    }

     time2 = System.currentTimeMillis();
    System.out.println("e2 took " + (time2-time1) + " milliseconds");

     time1 = System.currentTimeMillis();

    for (int i=0; i < 10000000; ++i) {
      obj.exceptionMeth3();
    }

     time2 = System.currentTimeMillis();
    System.out.println("e3 took " + (time2-time1) + " milliseconds");
     } catch (Exception e) {
     }

  }
}

class Method1Exception extends Exception {
  
}

class Method2Exception extends Exception {
  
}

class Method3Exception extends Exception {
  
}

