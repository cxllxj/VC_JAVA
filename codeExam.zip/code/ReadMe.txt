The code directory contains code from each of the chapters with major code 
segments. Windows NT .bat files are provided to help set up environments for code
where this may be tricky. Edit the .bat file to match your own environment (replace
paths, drive letters, etc.)

The appropriate chapter in the book will also provide advise on running the example.
