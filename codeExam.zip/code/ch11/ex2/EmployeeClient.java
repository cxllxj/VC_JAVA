// This source is an example application.
// You are granted a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// There, therefore is, not guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL WE BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
import java.io.*;
import java.util.*;
import java.rmi.*;
import javax.naming.*; // new for IIOP

public class EmployeeClient {
  public static void main(String[] args) {
    long startTime, endTime;
    Employee obj = null;
    String rmiName = null;

    if (args.length != 0) {
      rmiName = args[0];
    } else {
      System.out.println("Please pass the server name " 
                         + "as the argument.");
      return;
    }

    try {
      Context initialNamingContext = new InitialContext(); // new for IIOP
      obj = (Employee) javax.rmi.PortableRemoteObject.narrow(initialNamingContext.lookup(rmiName),
                                                              Employee.class);
    } catch (Exception e) {
      e.printStackTrace();
    }

    startTime = System.currentTimeMillis();

    for (int i = 0; i < 1000; i++) {

      try {
        obj.setName("Steve");
        obj.setSalary(1000000.67);
        obj.setId(12345);
        obj.addInfo("cat", "Mikey");
        obj.addInfo("hair", "Brown");
      } catch (Exception e) {
        e.printStackTrace();
        return;
      }
    }

    endTime = System.currentTimeMillis();

    System.out.println("A fine grained approach took " 
                       + (endTime - startTime) 
                       + " milliseconds.");

    startTime = System.currentTimeMillis();

    EmployeeParms empParm = new EmployeeParmsBase();
    for (int i = 0; i < 1000; i++) {
      empParm.setName("Steve");
      empParm.setSalary(1000000.67);
      empParm.setId(12345);
      empParm.addInfo("cat", "Mikey");
      empParm.addInfo("hair", "Brown");

      try {
        obj.setFromHelper(empParm);
      } catch (Exception e) {
        e.printStackTrace();
        return;
      }
      empParm.clearInfo();
    }
    endTime = System.currentTimeMillis();

    System.out.println("A coarse grained approach took " 
                       + (endTime - startTime) 
                       + " milliseconds.");
  } 
} 
