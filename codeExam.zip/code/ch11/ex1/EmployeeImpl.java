// This source is an example application.
// You are granted a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// There, therefore is, not guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL WE BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//

import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;

public class EmployeeImpl extends UnicastRemoteObject
implements Employee {
  private String name;
  private double salary;
  private long id;
  private java.util.Hashtable info = 
                                   new java.util.Hashtable(87);

  public EmployeeImpl(String inName) throws RemoteException {
    super();
    name = inName;
  }

  public String getName() throws RemoteException {
    return name;
  }

  public void setName(String inName) throws RemoteException {
    name = inName;
  }

  public double getSalary() throws RemoteException {
    return salary;
  }

  public void setSalary(double inSalary) throws 
                                         RemoteException {
    salary = inSalary;
  }

  public long getId() throws RemoteException {
    return id;
  }

  public void setId(long inId) throws RemoteException {
    id = inId;
  }

  public String getInfo(String key) throws RemoteException {
    return (String)info.get(key);
  }

  public void addInfo(String key, 
                      String value) throws RemoteException {
    info.put(key, value);
  }

  public void setFromHelper(EmployeeParms helper) throws 
                                              RemoteException {
    String inName;
    if ((inName = helper.getName()) != null)
      setName(inName);

    double inSalary;
    if ((inSalary = helper.getSalary()) != 0)
      setSalary(inSalary);

    long inId;
    if ((inId = helper.getId()) != 0)
      setId(inId);

    java.util.Hashtable inInfo;

    if ((inInfo = helper.getProperties()) != null) {
      java.util.Enumeration keys = inInfo.keys();
      java.util.Enumeration values = inInfo.elements();

      int size = inInfo.size();
      for (int i = 0; i < size; i++) {
        try {
          info.put(keys.nextElement(), values.nextElement());
        } catch (java.util.NoSuchElementException e) {
          
        }
      }
    }
  }

  public static void main(String[] args) {
    // Create and install the security manager
    System.setSecurityManager(new RMISecurityManager());

    try {
      EmployeeImpl obj = new EmployeeImpl(args[0]);
      Naming.rebind(args[0], obj);
    } catch (Exception e) {
      e.printStackTrace();
      return;
    }

    System.out.println("The Employee server is now active.");
  }
}
