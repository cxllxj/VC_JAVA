// This source is an example application.
// IBM grants you a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided by IBM for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// IBM, therefore, cannot guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL IBM BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
// 5648 - BP1
// (C) Copyright IBM Corp. 1998
// All rights reserved.
// US Government Users Restricted Rights -
// Use, duplication, or disclosure restricted
// by GSA ADP Schedule Contract with IBM Corp.
//
// Licensed Materials - Property of IBM
/**
 * This is the base class for specific tests.
 * Extend it to create your own tests.
 */
public class CompanyTest extends Test {
  private final static String NAME = "Test the company";

  public CompanyTest() {
    
  }

  private Thread threads[];
  private int tCount;
  private java.util.Vector recorders;
  private long score;

  private void startThreads(Company theCompany) {

    short maxWH = theCompany.getMaxWarehouses();
    int maxTerminals = SetValues.getNumberOfTerminals();
    if (threads == null) {
      threads = new Thread[SetValues.threadLimit];
      tCount = 0;
    }

    for (byte whID = 1; whID <= maxWH; whID++) {
      for (int i=1; i <= maxTerminals; i++) {
        if (tCount < SetValues.threadLimit) {
          System.out.print("Start Thread ");
          System.out.print(tCount);

          threads[tCount] = 
           new Thread(new CompanyRunnable(whID, theCompany));
          threads[tCount].start();
          tCount++;

          Butil.textOut(" Complete");
        }
      }

      if (SetValues.getTestType()) // running a minimal test
        Butil.SecondsToSleep(5);
    }
  }

  private synchronized void stopThreads() {
    int i;
    for (i = 0; i < tCount; i++) {
      threads[i] = null;
    }
    tCount = 0;
  }

  /**
   * Implement this method to do the work in
   * your own test.
   */
  public void runTest() {
    Company theCompany = CompanySetups.getCompany();
    startThreads(theCompany);
    // wait for all the transactions to complete
    theCompany.waitForMeasurements();
    stopThreads();
    recorders = theCompany.getRecorders();
    theCompany.reset();
  }

  /**
   * Implement this method return the
   * name of your own test.
   */
  public String getName() {
    return NAME;
  }

  /**
   * Override this method to add your own results.
   * call super.displayResults to reuse this default.
   */
  public void displayResults() {
    score = 0;
    if (recorders != null) {

      for (int i = 0; i < recorders.size(); i++) {
        TransactionRecorder recorder = 
           (TransactionRecorder)recorders.elementAt(i);
        recorder.displayResults();
        score += recorder.getScore();
      }

      Butil.textOut("The score for the "+ getName() + 
                         " test was " + getScore());
      PerfMonitor.clearMonitors();
    }
  }

  /**
   * Override this method to calculate your own score.
   * call super.getScore to reuse this default.
   */
  public long getScore() {
    return score;
  }
}




