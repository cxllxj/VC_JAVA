// This source is an example application.
// IBM grants you a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided by IBM for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// IBM, therefore, cannot guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL IBM BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
// 5648 - BP1
// (C) Copyright IBM Corp. 1998
// All rights reserved.
// US Government Users Restricted Rights -
// Use, duplication, or disclosure restricted
// by GSA ADP Schedule Contract with IBM Corp.
//
// Licensed Materials - Property of IBM

import java.util.*;
import infra.Util.DisplayScreen;

class StockLevelTransaction extends CommonTransaction {
  private static final long WAITTIMESTYPING = 2;
  private static final long WAITTIMESTHINKING = 5;

  private Company company;
  private byte warehouseId;
  private byte  districtId;
  private District district;
  private Map orderTable;
  private int threshold;
  private int lowStock;

  private DisplayScreen backScreen;
  private DisplayScreen initScreen;
  private DisplayScreen stockScreen;

  public StockLevelTransaction(Company inCompany,
                               byte inWarehouseId,
                               byte inDistrictId) {
    super(WAITTIMESTYPING, WAITTIMESTHINKING);

    company = inCompany;
    warehouseId = inWarehouseId;  // 2.8.1.1
    districtId = inDistrictId;  // 2.8.1.1

    district = 
       company.getWarehouse(warehouseId).
               getDistrict(districtId); // 2.8.2.2 bullet 3
    orderTable = district.getOrderTable();

    // 2.8.3.1
    backScreen = new DisplayScreen();
    backScreen.putText("Stock-Level", 36, 0, 11);
    backScreen.putText("Warehouse:", 0, 1, 10);
    backScreen.putInt (warehouseId, 11, 1, 4);
    backScreen.putText("District:", 17, 1, 10);
    backScreen.putInt (districtId, 28, 1, 2);
    backScreen.putText("Stock Level Threshold:", 0, 3, 22);
    backScreen.putText("low stock:",  0, 5,10);

    initScreen = new DisplayScreen(backScreen);
    // initScreen.putInt(warehouseId, 11, 1, 4);
    // initScreen.putInt(districtId, 28, 1, 2);
    initScreen.putCharFill('9', 23, 3, 2);
    initScreen.putCharFill('9', 11, 5, 3);

    stockScreen = new DisplayScreen();
  }

  public void init() {
    threshold = (int)Butil.random(10,20); // 2.8.1.2
    lowStock = 0;
  }

  public synchronized void delete() {
    
  }

  public void process() {
    int lastOrderId = 
       district.lastOrderId(); // 2.8.2.2 bullet 3
    int lastMinus20;
    if (lastOrderId <= 20)      // 2.8.2.2 bullet 4
      lastMinus20 = 1;
    else
      lastMinus20 = lastOrderId - 20;

    for (int  id = lastMinus20; id <= lastOrderId; id++) {
      // get currentOrder with write lock
      Order currentOrder = 
         (Order)orderTable.get(new Integer(id));
      if (currentOrder != null) {
        Object[] orderlineList = 
           currentOrder.getOrderlineList();
        int orderLineCount = 
           currentOrder.getOrderlineCount();

        Orderline currentOrderLine;
        int i;
        for (i=0; i < orderLineCount; i++) {
          currentOrderLine = (Orderline)orderlineList[i];
          // find stock in the warehouse's stock table 
          // that match the item IDs of the items in the 
          // orderline list that have less than threshold 
          // quantity
          // 2.8.2.2 bullet 5
          if (currentOrderLine.getStock().getQuantity() < threshold)
            ++lowStock;
        }
      } // if
    } // for
  }

  public void initialDisplay() {
    if (SetValues.getScreenWrite())
      initScreen.display();
  }

  public synchronized void secondDisplay() {
    stockScreen.copyScreen(backScreen);
    stockScreen.putInt(threshold, 23, 3, 2);
    stockScreen.putInt(lowStock, 11, 5, 3);

    if (SetValues.getScreenWrite())
      stockScreen.display();
  }
}
