// This source is an example application.
// IBM grants you a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided by IBM for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// IBM, therefore, cannot guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL IBM BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
// 5648 - BP1
// (C) Copyright IBM Corp. 1998
// All rights reserved.
// US Government Users Restricted Rights -
// Use, duplication, or disclosure restricted
// by GSA ADP Schedule Contract with IBM Corp.
//
// Licensed Materials - Property of IBM

/**
 * This class organizes a random deck
 * of the transaction types for the TransactionManager to use.
 */
class TransactionDeck {

  private Transaction[] transArray;
  private int iteration;
  private SynchronizationPoint synchPoint;
  private long base_time;
  private long rampup_time; // in milliseconds
  private long measurement_time; // in milliseconds
  private int[] deck;
  private TransactionRecorder myRecorder;

  // Build the TransactionDeck
  public TransactionDeck(Company company, 
                         byte warehouseId) {
    deck = new int[23];
    synchPoint = company.getSynchronizationPoint();
    synchPoint.signalStarted();

    Butil.random_init();

    // get times in milliseconds
    rampup_time = SetValues.getRampupTime() * 1000;
    measurement_time = SetValues.getMeasurementTime() * 1000;

    // create a random array of integers
    deck = buildDeck();

    // used by stock-level transaction
    byte districtId = 
    (byte)Butil.random(1,
                       company.getMaxDistricts());

    // create transaction objects
    NewOrderTransaction newOrderTransaction = 
    new NewOrderTransaction(company, warehouseId);
    PaymentTransaction paymentTransaction = 
    new PaymentTransaction(company, warehouseId);
    OrderStatusTransaction orderStatusTransaction = 
    new OrderStatusTransaction(company, warehouseId);
    DeliveryTransaction deliveryTransaction = 
    new DeliveryTransaction(company, warehouseId);
    StockLevelTransaction stockLevelTransaction = 
    new StockLevelTransaction(company, warehouseId, 
                              districtId);

    // fill in the transaction array
    transArray = new Transaction[Transaction.MAXTXNTYPES];
    transArray[Transaction.NEW_ORDER] = newOrderTransaction;
    transArray[Transaction.PAYMENT] = paymentTransaction;
    transArray[Transaction.ORDER_STATUS] = 
    orderStatusTransaction;
    transArray[Transaction.DELIVERY] = deliveryTransaction;
    transArray[Transaction.STOCK_LEVEL] = 
    stockLevelTransaction;

    myRecorder = new TransactionRecorder();
    myRecorder.setTransactionTimer(Transaction.NEW_ORDER, 
                           newOrderTransaction.getTimer());
    myRecorder.setTransactionTimer(Transaction.PAYMENT, 
                           paymentTransaction.getTimer());
    myRecorder.setTransactionTimer(Transaction.ORDER_STATUS,
                           orderStatusTransaction.getTimer());
    myRecorder.setTransactionTimer(Transaction.DELIVERY, 
                           deliveryTransaction.getTimer());
    myRecorder.setTransactionTimer(Transaction.STOCK_LEVEL, 
                           stockLevelTransaction.getTimer());
  }

  // Run a transaction and
  // return a new mode as the test switches states.
  // Register recorded results when finished.
  byte perform(byte mode) {

    int txntype = deck[iteration];
    iteration++;
    if (iteration == 23) { //pass complete, build a new deck
      deck = buildDeck(); 
      iteration = 0;
    }

    // Perform the transaction specified in the 
    // current distribution
    transArray[txntype].perform();

    // find out how much time is left
    long current_time = System.currentTimeMillis();
    switch (mode) {
    case SynchronizationPoint.RECORDING:
      // if measurement time is over, then start ramp_down
      if ((current_time - base_time) > (measurement_time)) {
        // signal this run completed
        synchPoint.signalDone(myRecorder);
        // go into ramp_down mode
        mode = SynchronizationPoint.RAMP_DOWN;
      }
      break;
    case SynchronizationPoint.RAMP_UP:
      // if all terminals have started and 
      // rampup time is over,  start recording
      if (synchPoint.allStarted() &&
          ((current_time - base_time) >= (rampup_time))) {
        myRecorder.zeroTimers(); // reinitialize timers
        base_time = System.currentTimeMillis();
        mode = SynchronizationPoint.RECORDING;
      }
      break;
    case SynchronizationPoint.RAMP_DOWN:
      if (synchPoint.allDone()) // all threads are done
        mode = SynchronizationPoint.TIMED_DONE;
      break;
    default: break;
    }
    return mode;
  }

  // builds an array of integers to use to
  // randomize the order of transactions executed
  private int[] buildDeck() {
    int real_deck[] = new int[23];
    int cross_deck[] = new int[23];
    int rand_val;
    int i;
    // set up cross_deck
    for (i = 0; i < 23; i++)
      cross_deck[i] = i;

    // assign new-order
    for (i = 0; i < 10; i++) {
      rand_val = (int)Butil.random(0,23-1-i);
      real_deck[cross_deck[rand_val]] = 
      Transaction.NEW_ORDER;
      cross_deck[rand_val] = cross_deck[23-1-i];
    }

    // assign payment
    for (i = 0; i < 10; i++) {
      rand_val = (int)Butil.random(0,13-1-i);
      real_deck[cross_deck[rand_val]] = Transaction.PAYMENT;
      cross_deck[rand_val] = cross_deck[13-1-i];
    }

    // order status
    rand_val = (int)Butil.random(0,3-1);
    real_deck[cross_deck[rand_val]] = 
    Transaction.ORDER_STATUS;
    cross_deck[rand_val] = cross_deck[3-1];

    // delivery
    rand_val = (int)Butil.random(0,2-1);
    real_deck[cross_deck[rand_val]] = Transaction.DELIVERY;
    cross_deck[rand_val] = cross_deck[2-1];
    // stock-level
    rand_val = 0;
    real_deck[cross_deck[rand_val]] = 
    Transaction.STOCK_LEVEL;

    return real_deck;
  }
}
