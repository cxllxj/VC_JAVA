// This source is an example application.
// IBM grants you a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided by IBM for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// IBM, therefore, cannot guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL IBM BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
// 5648 - BP1
// (C) Copyright IBM Corp. 1998
// All rights reserved.
// US Government Users Restricted Rights -
// Use, duplication, or disclosure restricted
// by GSA ADP Schedule Contract with IBM Corp.
//
// Licensed Materials - Property of IBM

import infra.Factory.Factory;
import infra.Base;
import infra.Factory.Container;
import infra.Entity;
import infra.Location;

public
class Stock extends Entity {
  private static Class StockClassRef;
  private static Location with = Location.createWith();

  static {
    try {
      StockClassRef = Class.forName("Stock");
    } catch (ClassNotFoundException e) {
      Butil.textOut("Stock Static Init - "
                    + "ClassNotFoundException");
    }
  }

  // misc:
  private Company   company;

  // BOB-C required fields
  private char    district_text[];
  private String  data;
  private int   id;
  private int   quantity;
  private float   ytd;
  private short   orderCount;
  private short   remoteCount;
  private byte    warehouseId;

  public static Stock createStock(Base nearobj,
                                  Company inCompany,
                                  int itemId,
                                  byte wId) {
    Stock newStock = null;

    newStock = (Stock)
    Factory.createEntity(StockClassRef, nearobj, with);

    newStock.initStock(inCompany, new Integer(itemId), wId);

    return newStock;
  }

  public void destroy() {
    data = null;
    Factory.destroyPermInstance(district_text);
    super.destroy();
  }

  public Stock(Company inCompany, int itemId, byte wId) {
    Integer hit;
    int district;
    short maxDistricts;

    company = inCompany;

    // 4.3.3.1 bullet 2 sub-bullet 1
    id    = itemId;
    warehouseId = wId;
    maxDistricts = company.getMaxDistricts();
    district_text = new char[25*maxDistricts];
    for (district=0; district < maxDistricts; district++) {
      char [] temp_chars = 
         Butil.create_random_a_string(25, 25).toCharArray();
      System.arraycopy(temp_chars, 0,
                       district_text, district*25, 25);
    }
    quantity  = (int)Butil.random(10,100);
    ytd   = 0;
    orderCount  = 0;
    remoteCount = 0;
    data = Butil.create_a_string_with_original(26,50,
                                               10f,null);
  }

  public Stock() {
    
  }

  public void
  initStock(Company inCompany, Integer itemId, byte wId) {
    int district;
    short maxDistricts;
    Integer hit;

    // 4.3.3.1 bullet 2 sub-bullet 1
    quantity  = (int)Butil.random(10,100);
    ytd   = 0;
    orderCount  = 0;
    remoteCount = 0;
    hit = new Integer(0);
    data =Butil.create_a_string_with_original(26,50,10f,hit);

    company = inCompany;

    // 4.3.3.1 bullet 2 sub-bullet 1
    id = itemId.intValue();
    warehouseId = wId;
    maxDistricts = company.getMaxDistricts();
    district_text = new char[maxDistricts*25];
    for (district=0; district < maxDistricts; district++) {
      char [] temp_chars = 
         Butil.create_random_a_string(25, 25).toCharArray();
      System.arraycopy(temp_chars, 0,
                       district_text, district*25, 25);
    }
  }

  public synchronized int getQuantity() {
    return quantity;
  }

  public synchronized void changeQuantity(int delta) {
    quantity += delta;
  }

  public synchronized void incrementOrderCount() {
    ++orderCount;
  }

  public synchronized void incrementRemoteCount() {
    ++remoteCount;
  }

  public synchronized Integer getId() {
    return new Integer(id);
  }

 public synchronized String getDistrictInfo(byte districtId){
    return new String(district_text, (districtId-1)*25, 25);
  }

  public synchronized String getData() {
    return data;
  }

  public synchronized void incrementYTD(short ol_quantity) {
    ytd += ol_quantity;
  }
}
