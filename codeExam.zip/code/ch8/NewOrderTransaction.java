// This source is an example application.
// IBM grants you a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided by IBM for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// IBM, therefore, cannot guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL IBM BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
// 5648 - BP1
// (C) Copyright IBM Corp. 1998
// All rights reserved.
// US Government Users Restricted Rights -
// Use, duplication, or disclosure restricted
// by GSA ADP Schedule Contract with IBM Corp.
//
// Licensed Materials - Property of IBM
import infra.Factory.Factory;
import infra.Base;
import infra.Entity;
import infra.Location;
import infra.Util.DisplayScreen;
import java.util.*;

class NewOrderTransaction extends CommonTransaction {

  private static final long WAITTIMESTYPING = 18;
  private static final long WAITTIMESTHINKING = 12;

  private Company company;
  private byte    warehouseId;    // W_ID
  private byte    districtId;   // D_ID
  private short   customerId;   // C_ID
  private Warehouse warehouse;
  private District  district;
  private short   number_of_orderlines; // ol_cnt
  private boolean rollback;   // rbk
  private float   warehouseTaxRate; // W_TAX
  private float   districtTaxRate;  // D_TAX
  private int   orderId;    // O_ID
  private float   customerDiscountRate; // C_DISCOUNT
  private String  customerLastName; // C_LAST
  private String  customerCreditStatus; // C_CREDIT
  private short   orderline_count;  // O_OL_CNT
  private Order   thisOrder;
  private DisplayScreen backScreen;
  private DisplayScreen initScreen;
  private DisplayScreen orderScreen;

  public NewOrderTransaction(Company inCompany,
                             byte inWarehouseId) {

    super(WAITTIMESTYPING, WAITTIMESTHINKING);
    int i;

    company = inCompany;

    // 2.4.1.1
    warehouseId = inWarehouseId;
    warehouse = company.getWarehouse(warehouseId);

    // 2.4.3.1
    backScreen = new DisplayScreen();
    backScreen.putText("New Order", 35, 0, 9);
    backScreen.putText("Warehouse:", 0, 1, 10);
    backScreen.putInt (warehouseId, 11, 1, 4);
    backScreen.putText("District:", 18, 1, 9);
    backScreen.putText("Date:", 54, 1, 5);
    backScreen.putText("Customer:", 0, 2, 10);
    backScreen.putText("Name:", 18, 2, 5);
    backScreen.putText("Credit:", 43, 2, 7);
    backScreen.putText("%Disc:", 56, 2, 6);
    backScreen.putText("Order Number:", 0, 3, 14);
    backScreen.putText("Number of Lines:", 24, 3,26);
    backScreen.putText("W_tax:", 51, 3,6);
    backScreen.putText("D_tax:", 66, 3, 6);
    backScreen.putText(" Supp_W  Item_Id  Item Name                 Qty  Stock  B/G  Price    Amount", 0, 5, 79);
    backScreen.putText("Execution Status:",  0, 21,17);
    backScreen.putText("Total:", 61, 21,6);

    initScreen = new DisplayScreen(backScreen);
    // initScreen.putCharFill('9', 11, 1, 4);
    initScreen.putCharFill('9', 28, 1, 2);
    initScreen.putText("DD-MM-YYYY hh:mm:ss", 60, 1, 19);
    initScreen.putCharFill('9', 11, 2, 4);
    initScreen.putCharFill('X', 24, 2, 16);
    initScreen.putCharFill('X', 51, 2, 2);
    initScreen.putText("99.99", 63, 2, 5);
    initScreen.putCharFill('9', 14, 3, 8);
    initScreen.putCharFill('9', 41, 3, 2);
    initScreen.putText("99.99", 58, 3, 5);
    initScreen.putText("99.99", 73, 3, 5);
    for (i=6; i<21; i++) {
      initScreen.putCharFill('9',  2, i, 4);
      initScreen.putCharFill('9',  9, i, 6);
      initScreen.putCharFill('X', 18, i, 24);
      initScreen.putCharFill('9', 44, i, 2);
      initScreen.putCharFill('9', 50, i, 3);
      initScreen.putChar    ('X', 57, i);
      initScreen.putText("$999.99",  61, i,7);
      initScreen.putText("$9999.99", 70, i,8);
    }
    initScreen.putCharFill('X', 18, 21, 24);
    initScreen.putText("$99999.99", 69, 21,9);

    orderScreen = new DisplayScreen();
  }

  public void delete() {
    
  }

  public void init() {
    // 2.4.1.2
    districtId = 
       (byte)(Butil.random(1,company.getMaxDistricts()));
    short a_c_id = Butil.A_C_ID;
    short c_c_id = Butil.C_C_ID;
    customerId = (short)Butil.NUrand_val((int)a_c_id, 1, 
               (int)company.getMaxCustomers(), 
               (int)c_c_id );

    // 2.4.1.3
    number_of_orderlines = (short)Butil.random(5,15);

    // 2.4.1.4
    rollback = (boolean)(Butil.random(1,100) == 1);
    rollback = false;
    district  = warehouse.getDistrict(districtId);
  }

  public void process() {
    NewOrder theNewOrder;
    // 2.4.2.2 bullet 3
    warehouseTaxRate = warehouse.getTaxRate();

    // 2.4.2.2 bullet 4
    districtTaxRate = district.getTaxRate();
    orderId = district.nextOrderId();

    // 2.4.2.2 bullet 5
    long uniqueCustomerId = 
       company.buildUniqueCustomerKey(warehouseId, 
                                      districtId, 
                                      customerId);
    // get customer 
    Customer customer  = 
       company.getCustomer(uniqueCustomerId);
    customerDiscountRate = customer.getDiscountRate();
    customerLastName = customer.getLastName();
    customerCreditStatus = customer.getCreditStatus();

    // 2.4.2.2 bullet 6
    thisOrder = Order.createOrder(district,
                                  company,
                                  orderId,
                                  districtId,
                                  warehouseId,
                                  customerId,
                                  customer,
                                  districtTaxRate,
                                  warehouseTaxRate,
                                  customerDiscountRate);

    theNewOrder = NewOrder.createNewOrder(district,
                                          thisOrder,
                                          orderId,
                                          districtId,
                                          warehouseId);

    // 2.4.1.5
    if (thisOrder.processLines(warehouse, 
                               number_of_orderlines, 
                               rollback)) {
      orderline_count = thisOrder.getOrderlineCount();
      district.addOrder(thisOrder);
      district.addNewOrder(theNewOrder);  
      customer.addOrder(thisOrder);
    } else {
      // 2.4.2.2 bullet 8.1 (2nd sentence)
      // & 2.4.2.3 --  ROLLBACK TRANSACTION IF INVALID
      // can't delete unless removed from district and 
      // customer
      Factory.deleteEntity(thisOrder);
      Factory.deleteEntity(theNewOrder);
      orderline_count = 0;
    }
  }

  public void initialDisplay() {
    // 2.4.3.1
    if (SetValues.getScreenWrite())
      initScreen.display();
  }

  public synchronized void secondDisplay() {
    orderScreen.copyScreen(backScreen);
    java.util.Date screenDate = new java.util.Date();

    orderScreen.putInt(districtId, 28, 1, 2);
    orderScreen.putDate(screenDate, 60, 1, 10);
    orderScreen.putTime(screenDate, 71, 1, 8);
    orderScreen.putInt(customerId, 11, 2, 4);
    orderScreen.putText(customerLastName, 24, 2, 16);
    orderScreen.putText(customerCreditStatus, 51, 2, 2);
    orderScreen.putDouble((customerDiscountRate*100.0), 63,
                           2, 5);
    orderScreen.putInt(orderId, 14, 3, 8);
    orderScreen.putInt(orderline_count, 41, 3, 2);
    orderScreen.putDouble((warehouseTaxRate*100.0), 58, 3,
                           5);
    orderScreen.putDouble((districtTaxRate*100.0), 73, 3,
                           5);

    if (orderline_count > 0) {
      Object[] orderlineList;
      int lineCount, i;
      orderlineList = thisOrder.getOrderlineList();
      lineCount = thisOrder.getOrderlineCount();
      for (i = 0; i < lineCount; i++) {
        Orderline curLine = (Orderline)orderlineList[i];

        orderScreen.putInt(curLine.getSupplyWarehouse(),
                           2, i+6, 4);
        orderScreen.putInt(curLine.getItemId(), 9, i+6, 6);
        orderScreen.putText(curLine.getItemName(),
                            18, i+6, 24);
        orderScreen.putInt(curLine.getQuantity(),
                           44, i+6, 2);
        orderScreen.putInt(curLine.getStockQuantity(),
                           50, i+6, 3);
        orderScreen.putChar(curLine.getBrandGeneric(), 
                            57, i+6);
        orderScreen.putDollars(curLine.getItemPrice(),  
                               61, i+6,7);
        orderScreen.putDollars(curLine.getAmount(), 
                               70, i+6,8);
      }
    }

    if (orderline_count > 0) {
      orderScreen.putText("---- Order is valid ----", 
                          18, 21, 24);
      orderScreen.putDollars(thisOrder.getTotalAmount(), 
                             69, 21,9);
    } else {
      orderScreen.putText("ITEM NUMBER IS NOT VALID", 18, 
                          21, 24);
      orderScreen.putDollars(0.0, 69, 21,9);
    }

    if (SetValues.getScreenWrite())
      orderScreen.display();
  }

  public synchronized void processPreloadedOrders() {
    orderId = district.nextOrderId();
    long uniqueCustomerId = 
       company.buildUniqueCustomerKey(warehouseId, 
                                      districtId, 
                                      customerId);
    // get customer  with a write lock
    Customer customer = 
       company.getCustomer(uniqueCustomerId);

    thisOrder = Order.createOrder(district,
                                  company,
                                  orderId,
                                  districtId,
                                  warehouseId,
                                  customerId,
                                  customer,
                                  0.00f, 0.00f, 0.00f);

    district.addOrder(thisOrder);  
    customer.addOrder(thisOrder);

    java.util.Date orderdate = (java.util.Date)
      Factory.newInstanceNear("java.util.Date", thisOrder);
    thisOrder.setEntryDateTime(orderdate);
    if (orderId <= 
        (company.getInitialOrders() - 
         company.getInitialNewOrders())) {
      byte carrierId = (byte)Butil.random(1,10);
      thisOrder.setCarrierId(carrierId);
    }
    thisOrder.setAllLocal(true);

    thisOrder.processLines(warehouse, 
                           number_of_orderlines, false);
    orderline_count = thisOrder.getOrderlineCount();

    if (orderId <= 
        (company.getInitialOrders() - 
         company.getInitialNewOrders())) {  
      NewOrder theNewOrder = 
         NewOrder.createNewOrder(district, 
                                 thisOrder,
                                 orderId,
                                 districtId,
                                 warehouseId);
      district.addNewOrder(theNewOrder);  
    }
  }

  public synchronized void 
     setDistrictandCustomer(byte inDistrictId, 
                            short inCustomerId) {
    districtId = inDistrictId;
    customerId = inCustomerId;
  }
}
