// This source is an example application.
// IBM grants you a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided by IBM for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// IBM, therefore, cannot guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL IBM BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
// 5648 - BP1
// (C) Copyright IBM Corp. 1998
// All rights reserved.
// US Government Users Restricted Rights -
// Use, duplication, or disclosure restricted
// by GSA ADP Schedule Contract with IBM Corp.
//
// Licensed Materials - Property of IBM
import infra.Factory.Factory;
import infra.Base;
import infra.Entity;
import infra.Location;

import java.util.*;

public
class Customer extends Entity {

  private static final  String bad_credit = "BC";
  private static final  String good_credit = "GC";

  private static Class CustomerClassRef;
  private static Location with = Location.createWith();

  static
  {
    try {
      CustomerClassRef = Class.forName("Customer");
    } catch (ClassNotFoundException e) {
      Butil.textOut(
           "Customer Static Init - ClassNotFoundException");
    }
  }

  private Order   lastOrder;
  private String  firstName;  // C_FIRST
  private String  middleName; // C_MIDDLE
  private String  lastName; // C_LAST
  private Address address;  // see Address object
  private String  phone;    // C_PHONE
  private Date    since;    // C_SINCE
  private String  data;   // C_DATA
  private float   creditLimit;  // C_CREDIT_LIMIT
  private float   discount; // C_DISCOUNT
  private float   balance;  // C_BALANCE
  private float   ytd;    // C_YTD_PAYMENT
  private char    credit1;  // C_CREDIT
  private char    credit2;  // C_CREDIT
  private short   customerId; // C_ID
  private short   paymentCount; // C_PAYMENT_CNT
  private short   deliveryCount;  // C_DELIVERY_CNT
  private byte    districtId; // C_D_ID
  private byte    warehouseId;  // C_W_ID

  public static Customer createCustomer(Base nearobj) {
    return (Customer)Factory.createEntity(CustomerClassRef,
                                          nearobj, with);
  }

  public void destroy() {
    Factory.deleteEntity(address);

    Factory.destroyPermInstance(since);

    super.destroy();
  }

  public Customer() {
    address = Address.createAddress(this);
    since = (Date)Factory.newInstanceNear("java.util.Date", this);
    creditLimit = 0.00f;
    balance = 0.00f;
    ytd = 0.00f;
    paymentCount = 0;
    deliveryCount = 0;
    lastOrder = null;
  }

  public short getId() {
    return customerId;
  }

  public synchronized void addOrder(Order thisOrder) {
    lastOrder = thisOrder;
  }

  public synchronized Order getLatestOrder() {
    return lastOrder;
  }

  public String getFirstName() {
    return firstName;
  }

  public String getMiddleName() {
    return middleName;
  }

  public String getLastName() {
    return lastName;
  }

  public Address getAddress() {
    return address;
  }

  public float getDiscountRate() {
    return discount;
  }

  public String getCreditStatus() {
    String result;
    if (credit1 == 'G')
      result = good_credit;
    else
      result = bad_credit;
    return result;
  }

  public byte getWarehouseId() {
    return warehouseId;
  }

  public byte getDistrictId() {
    return districtId;
  }

  public synchronized float getBalance() {
    return balance;
  }


  public float getCreditLimit() {
    return creditLimit;
  }

  public synchronized void adjustBalance(float amount) {
    balance += amount;
  }

  public synchronized void increaseYTD(float amount) {
    ytd += amount;
  }

  public synchronized void incrementPaymentCount() {
    ++paymentCount;
  }

  public synchronized void incrementDeliveryCount() {
    ++deliveryCount;
  }

  public synchronized void updateCustomerData(String newData) {
    // 2.5.2.2 bullet 6
    //Shift in new data, but never exceed 500 characters
    StringBuffer temp = new StringBuffer(newData.length() 
                                         + data.length());
    temp.append(newData);
    temp.append(data);

    if (temp.length() > 500) // truncate if needed
      temp.setLength(500);

    data = temp.toString();
  }

  public synchronized void setUsingRandom(short inCustomerId,
                                          byte inWarehouseId,
                                          byte inDistrictId) {

    // set in the things we are given as input
    customerId=inCustomerId;
    districtId=inDistrictId;
    warehouseId=inWarehouseId;

    if (inCustomerId <= 1000)
      lastName = Butil.create_random_last_name(inCustomerId);
    else
      lastName = Butil.create_random_last_name(0);

    firstName = Butil.create_random_a_string(8,16);
    middleName = "OE";
    address.setUsingRandom(); // created in init
    phone = Butil.create_random_n_string(16,16);
    if (Butil.random(1, 10) > 1) {
      credit1 = 'G';
      credit2 = 'C';
    } else {
      credit1 = 'B';
      credit2 = 'C';
    }
    creditLimit = 50000.00f;
    discount = Butil.create_random_float_val_return(0.0f, 
                                                    0.5000f, 
                                                    0.0001f);
    balance = -10.00f;
    ytd = 10.00f;
    paymentCount = 1;
    deliveryCount = 0;
    data = Butil.create_random_a_string(300,500);
  }

  public String getPhone() {
    return phone;
  }

  public Date getSince() {
    return since;
  }

  public synchronized String getCustomerDataParts() {
    try {
      return data;
    } catch (Throwable t)
    {
       t.printStackTrace();
       System.out.println(data.length());
       System.exit(0);
    }
    return null;
  }
}
