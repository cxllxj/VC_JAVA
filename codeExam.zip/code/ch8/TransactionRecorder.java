// This source is an example application.
// IBM grants you a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided by IBM for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// IBM, therefore, cannot guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL IBM BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
// 5648 - BP1
// (C) Copyright IBM Corp. 1998
// All rights reserved.
// US Government Users Restricted Rights -
// Use, duplication, or disclosure restricted
// by GSA ADP Schedule Contract with IBM Corp.
//
// Licensed Materials - Property of IBM

import infra.Util.DisplayScreen;

public class TransactionRecorder {

  private DisplayScreen screen;
  private DisplayScreen screen2;

  private TransactionTimer[] timers;

  public TransactionRecorder() {
    timers = 
       new TransactionTimer[Transaction.MAXTXNTYPES];
    buildDisplay();
  }

  public synchronized void zeroTimers() {
     for (int i = 0; i < Transaction.MAXTXNTYPES; i++) {
       timers[i].clearMonitor();
     }
  }

  public synchronized void 
     setTransactionTimer(byte transactionType, 
                         TransactionTimer transTimer) {
    timers[transactionType] = transTimer;
  }

  public synchronized void displayResults() {
   PerfMonitor.processMonitors();
   screen.copyScreen(screen2);

   screen.putLong(timers[Transaction.NEW_ORDER].
                  getEventCount(),23,4,5);
   screen.putDouble(timers[Transaction.NEW_ORDER].
                    getTime()/1000.0d,35,4,6,2);
   screen.putDouble(timers[Transaction.NEW_ORDER].
                    getMinimumTime()/1000.0d,46,4,6,3);
   screen.putDouble(timers[Transaction.NEW_ORDER].
                    getMaximumTime()/1000.0d,57,4,6,3);
   screen.putDouble(timers[Transaction.NEW_ORDER].
                    monitorMeanTime()/1000.0d,68,4,6,3);
   screen.putLong(timers[Transaction.PAYMENT].
                  getEventCount(), 23, 5, 5);
   screen.putDouble(timers[Transaction.PAYMENT].
                    getTime()/1000.0d, 35, 5, 6, 2);
   screen.putDouble(timers[Transaction.PAYMENT].
                    getMinimumTime()/1000.0d, 46, 5, 6, 3);
   screen.putDouble(timers[Transaction.PAYMENT].
                    getMaximumTime()/1000.0d, 57, 5, 6, 3);
   screen.putDouble(timers[Transaction.PAYMENT].
                    monitorMeanTime()/1000.0d, 68, 5, 6, 3);
   screen.putLong(timers[Transaction.ORDER_STATUS].
                  getEventCount(), 23, 6, 5);
   screen.putDouble(timers[Transaction.ORDER_STATUS].
                    getTime()/1000.0d, 35, 6, 6, 2);
   screen.putDouble(timers[Transaction.ORDER_STATUS].
                    getMinimumTime()/1000.0d, 46, 6, 6, 3);
   screen.putDouble(timers[Transaction.ORDER_STATUS].
                    getMaximumTime()/1000.0d, 57, 6, 6, 3);
   screen.putDouble(timers[Transaction.ORDER_STATUS].
                    monitorMeanTime()/1000.0d, 68, 6, 6, 3);
   screen.putLong(timers[Transaction.DELIVERY].
                  getEventCount(), 23, 7, 5);
   screen.putDouble(timers[Transaction.DELIVERY].
                    getTime()/1000.0d, 35, 7, 6, 2);
   screen.putDouble(timers[Transaction.DELIVERY].
                    getMinimumTime()/1000.0d, 46, 7, 6, 3);
   screen.putDouble(timers[Transaction.DELIVERY].
                    getMaximumTime()/1000.0d, 57, 7, 6, 3);
   screen.putDouble(timers[Transaction.DELIVERY].
                    monitorMeanTime()/1000.0d, 68, 7, 6, 3);
   screen.putLong(timers[Transaction.STOCK_LEVEL].
                  getEventCount(), 23, 8, 5);
   screen.putDouble(timers[Transaction.STOCK_LEVEL].
                    getTime()/1000.0d, 35, 8, 6, 2);
   screen.putDouble(timers[Transaction.STOCK_LEVEL].
                    getMinimumTime()/1000.0d, 46, 8, 6, 3);
   screen.putDouble(timers[Transaction.STOCK_LEVEL].
                    getMaximumTime()/1000.0d, 57, 8, 6, 3);
   screen.putDouble(timers[Transaction.STOCK_LEVEL].
                    monitorMeanTime()/1000.0d, 68, 8, 6, 3);

    // print out information
    screen.display();
  }
  
public synchronized long getScore() {
 long score = timers[Transaction.NEW_ORDER].getEventCount();
 double time = timers[Transaction.NEW_ORDER].getTime()/1000.0d;
 score += timers[Transaction.PAYMENT].getEventCount();
 time += timers[Transaction.PAYMENT].getTime()/1000.0d;
 score += timers[Transaction.ORDER_STATUS].getEventCount();
   time += timers[Transaction.ORDER_STATUS].getTime()/1000.0d;

   score += timers[Transaction.DELIVERY].getEventCount();
   time += timers[Transaction.DELIVERY].getTime()/1000.0d;

   score += timers[Transaction.STOCK_LEVEL].getEventCount();
   time += timers[Transaction.STOCK_LEVEL].getTime()/1000.0d;

   // time = time / 60.od; // convert to minutes

   score = (long)(score / time);

   return score;
  }

  private void buildDisplay() {
    screen2 = new DisplayScreen(12, 80);
    screen2.putCharFill('=', 0, 0, 79);
    screen2.putCharFill('.', 0, 2, 25);
    screen2.putText("Results  (time in seconds)", 
                    27, 2, 26);
    screen2.putCharFill('.', 54, 2, 25);
    screen2.putText("New Order>", 0, 4, 14, 
                    DisplayScreen.alignRight);
    screen2.putText("Payment>", 0, 5, 14, 
                    DisplayScreen.alignRight);
    screen2.putText("OrderStatus>", 0, 6, 14, 
                    DisplayScreen.alignRight);
    screen2.putText("Delivery>", 0, 7, 14, 
                    DisplayScreen.alignRight);
    screen2.putText("Stock Level>", 0, 8, 14, 
                    DisplayScreen.alignRight);
    for (int i = 4; i < 9; i++) {
      screen2.putText("Count:", 16, i, 6);
      screen2.putText("Time:", 29, i, 5);
      screen2.putText("Min:", 42, i, 4);
      screen2.putText("Max:", 53, i, 4);
      screen2.putText("Avg:", 64, i, 4);
    }

    screen = new DisplayScreen(12, 80);
  }
}
