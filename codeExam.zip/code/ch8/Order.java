// This source is an example application.
// IBM grants you a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided by IBM for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// IBM, therefore, cannot guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL IBM BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
// 5648 - BP1
// (C) Copyright IBM Corp. 1998
// All rights reserved.
// US Government Users Restricted Rights -
// Use, duplication, or disclosure restricted
// by GSA ADP Schedule Contract with IBM Corp.
//
// Licensed Materials - Property of IBM
import infra.Factory.Factory;
import infra.Base;
import infra.Entity;
import infra.Location;
import java.util.*;

public class Order extends Entity {
  private static Class OrderClassRef;
  private static Location with = Location.createWith();

  static {
    try {
      OrderClassRef = Class.forName("Order");
    } catch (ClassNotFoundException e) {
      Butil.textOut("Order Static Init - "
                    + "ClassNotFoundException");
    }
  }

  private Company company;
  private Customer  customer;
  private Object[]  orderlineList;
  private float   totalAmount;
  private float   customerDiscountRate;
  private float   districtTax;
  private float   warehouseTax;
  private Date    entryDateTime;  // O_ENTRY_D
  private int   orderId;    // O_ID
  private short   customerId;   // O_C_ID
  private short   carrierId;    // O_CARRIER_ID
  private short   orderLineCount; // O_OL_CNT
  private byte    districtId;   // O_D_ID
  private byte    warehouseId;  // O_W_ID
  private boolean allLocal;   // O_ALL_LOCAL

  public static Order createOrder(Base nearobj,
                              Company inCompany,
                              int inOrderId,
                              byte inDistrictId,
                              byte inWarehouseId,
                              short inCustomerId,
                              Customer inCustomer,
                              float inDistrictTaxRate,
                              float inWarehouseTaxRate,
                              float inCustomerDiscountRate) {
    Order newOrder = null;

    newOrder = (Order)Factory.createEntity(OrderClassRef, 
                                           nearobj, with);

    newOrder.initOrder (inCompany,
                        inOrderId,
                        inDistrictId,
                        inWarehouseId,
                        inCustomerId,
                        inCustomer,
                        inDistrictTaxRate,
                        inWarehouseTaxRate,
                        inCustomerDiscountRate);
    return newOrder;
  }

  public void destroy() {
    Orderline orderline;
    int i;

    Factory.destroyPermInstance(entryDateTime);

    // delete all orderlines & 
    // remove them from the orderlineTable
    for (i = 0; i < orderLineCount; i++) {
      orderline = (Orderline)orderlineList[i];
      orderlineList[i] = null;
      Factory.deleteEntity(orderline);
    }
    Factory.destroyPermInstance(orderlineList);
    orderlineList = null;
    orderLineCount = 0;

    Factory.destroyPermInstance(entryDateTime);
    entryDateTime = null;

    super.destroy();
  }

  public Order(Company inCompany,
               int inOrderId,
               byte inDistrictId,
               byte inWarehouseId,
               short inCustomerId,
               Customer inCustomer,
               float inDistrictTaxRate,
               float inWarehouseTaxRate,
               float inCustomerDiscountRate) {
    company = inCompany;
    orderId = inOrderId;
    districtId  = inDistrictId;
    warehouseId = inWarehouseId;
    customerId  = inCustomerId;
    customer = inCustomer;

    // 2.4.1.6
    Date entryDateTime = (Date)
    Factory.newInstanceNear("java.util.Date", this);

    // BOB-C spec 2.4.2.2 bullet 6
    carrierId = 0;  // will be set when order is delivered
    allLocal = true;  // all orderlines supplied from home
                      // warehouse, reset to false if 
                      // supplied from remote warehouse

    orderLineCount  = 0;
    districtTax   = inDistrictTaxRate;
    warehouseTax    = inWarehouseTaxRate;
    customerDiscountRate  = inCustomerDiscountRate;
    orderlineList   = new Object[20];
  }

  public Order() {
    
  }

  public void initOrder(Company inCompany,
                        int inOrderId,
                        byte inDistrictId,
                        byte inWarehouseId,
                        short inCustomerId,
                        Customer inCustomer,
                        float inDistrictTaxRate,
                        float inWarehouseTaxRate,
                        float inCustomerDiscountRate) {
    company = inCompany;
    orderId = inOrderId;
    districtId  = inDistrictId;
    warehouseId = inWarehouseId;
    customerId  = inCustomerId;
    customer = inCustomer;

    orderLineCount  = 0;
    orderlineList   = new Object[20];

    // 2.4.1.6
    entryDateTime = (Date)
    Factory.newInstanceNear("java.util.Date", this);

    // BOB-C spec 2.4.2.2 bullet 6
    carrierId = 0;  // will be set when order is delivered
    allLocal = true;  // all orderlines supplied from home 
                      // warehouse,reset to False if 
                      // supplied from remote warehouse
    districtTax   = inDistrictTaxRate;
    warehouseTax    = inWarehouseTaxRate;
    customerDiscountRate  = inCustomerDiscountRate;
  }

  public synchronized boolean 
     processLines(Warehouse inWarehouse,
                  short number_of_orderlines,
                  boolean rollback) {
    byte supplyWarehouseId;
    boolean processLinesResult = true;
    float amount = 0;

    for (short i=1; i <= number_of_orderlines; ++i) {
      Orderline newOrderline;
      newOrderline = Orderline.createOrderline(this,
                                      company,
                                      orderId,
                                      districtId,
                                      warehouseId,
                                      i,
                                      number_of_orderlines,
                                      rollback);

      // 2.4.1.5 - #2
      supplyWarehouseId = warehouseId;
      if ((Butil.random(1,100)==1) && 
          (company.getMaxWarehouses() > 1)) {  
        while (supplyWarehouseId == warehouseId) {
          supplyWarehouseId = (byte)
          Butil.random(1,company.getMaxWarehouses());
        }
        allLocal = false;
      }

      newOrderline.setSupplyWarehouse(supplyWarehouseId);

      if (newOrderline.validateAndProcess(inWarehouse)) {
        // 2.4.2.2 bullet 8.5
        //newOrderline.process(); // called in validate
        amount += newOrderline.getAmount();
        orderlineList[orderLineCount] = newOrderline;

        // 2.4.2.2 bullet 7
        orderLineCount++;
      } else {
        // SIGNAL ROLLBACK HERE IF INVALID
        processLinesResult = false;
        Factory.deleteEntity(newOrderline);
      } // if
    } // for

    // 2.4.2.2 bullet 9
    totalAmount = amount*(1-customerDiscountRate)
                        *(1+warehouseTax+districtTax);

    return processLinesResult;
  }

  public synchronized void dateOrderlines() {
    Date orderdate;

    // date order lines according to 2.7.4.2 bullet 6
    int i;
    Orderline orderline;

    for (i = 0; i < orderLineCount; i++) {
      orderline = (Orderline)orderlineList[i];
      orderdate = (Date)
      Factory.newInstanceNear("java.util.Date", this);
      orderline.setDeliveryTime(orderdate);
    }
  }

  public synchronized Integer getId() {
    int temp = orderId;
    return new Integer(temp);
  }

  public synchronized Customer getCustomer() {
    return customer;
  }

  public synchronized float getTotalAmount() {
    return totalAmount;
  }

  public synchronized Date getEntryTime() {
    return entryDateTime;
  }

  public synchronized void setCarrierId(short inCarrierId) {
    carrierId = inCarrierId;
  }

  public synchronized short getCarrierId() {
    return carrierId;
  }

  public synchronized Object[] getOrderlineList() {
    return orderlineList;
  }

  public synchronized short getOrderlineCount() {
    return orderLineCount;
  }

  public synchronized void setAllLocal(boolean inAllLocal) {
    allLocal = inAllLocal;
  }

  public synchronized void setEntryDateTime(Date inDate) {
    if (entryDateTime != null)
      Factory.destroyPermInstance(entryDateTime);
    entryDateTime = inDate;
  }

  public synchronized boolean 
     processPreloadedLines(Warehouse inWarehouse,
                           short number_of_orderlines,
                           boolean rollback) {
    byte supplyWarehouseId;
    String districtInfo;
    boolean processLinesResult = true;
    float amount = 0;

    for (short i=1; i <= number_of_orderlines; ++i) {
      Orderline newOrderline = 
         Orderline.createOrderline(this,
                                   company,
                                   orderId,
                                   districtId,
                                   warehouseId,
                                   i,
                                   number_of_orderlines,
                                   rollback);

      supplyWarehouseId = warehouseId;
      newOrderline.setSupplyWarehouse(supplyWarehouseId);
      newOrderline.setQuantity((short)5);
      if (orderId <= 
          (company.getInitialOrders() - 
           company.getInitialNewOrders())) {
        Date orderdate = (Date)
        Factory.newInstanceNear("java.util.Date", this);
        newOrderline.setDeliveryTime(orderdate);
      } else {
        newOrderline.setAmount(
          Butil.create_random_float_val_return(0.01f, 
                                               9999.99f,
                                               .01f));
      }
      districtInfo = Butil.create_random_a_string(25, 25);
      newOrderline.setDistrictInfo(districtInfo);

      orderlineList[orderLineCount] = newOrderline;
      orderLineCount++;
    }
    return true;
  }
}
