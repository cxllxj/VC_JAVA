// This source is an example application.
// IBM grants you a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided by IBM for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// IBM, therefore, cannot guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL IBM BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
// 5648 - BP1
// (C) Copyright IBM Corp. 1998
// All rights reserved.
// US Government Users Restricted Rights -
// Use, duplication, or disclosure restricted
// by GSA ADP Schedule Contract with IBM Corp.
//
// Licensed Materials - Property of IBM
import infra.Factory.Factory;
import infra.Factory.Container;
import infra.Factory.ExpandingContainer;
/**
 * This is the base class for specific set up
 * actions. Extend it to create your own set up
 * actions.
 */
public class CompanySetups extends Setup {

  private final static String NAME = "Set up company.";
  public static final byte NON_NUMERIC_ENTRY = -99;

  private static Company theCompany;
  private static Container companyContainer = null;

  public static Company getCompany() {
    return theCompany;
  }

  public CompanySetups() {
    if (companyContainer == null) {
      companyContainer = 
         ExpandingContainer.createExpandingContainer();
      companyContainer.setContainerName("BOB Company");
    }
  }

  /**
   * Implement this method to do the work in
   * your own set up.
   */
  public void runSetup() {

    short selection = Butil.NON_NUMERIC_ENTRY;

    while (selection == Butil.NON_NUMERIC_ENTRY) {

      Butil.textOut(
          "1. Create a company with a minimal population.");
      Butil.textOut(
          "2. Create a company with a 1% population.");
      Butil.textOut(
          "3. Create a company with a 10% population.");
      Butil.textOut(
          "4. Create a company with a 100% population.");
      Butil.textOut(
          "5. Add a warehouse to the existing company.");
      Butil.textOut("6. Exit.");
      Butil.textOut("Enter selection here: ");

      selection = (short)Butil.getNumericInput();

      if ((selection < 1) || (selection > 7)) {
        selection = Butil.NON_NUMERIC_ENTRY;
      } else {

        if (theCompany != null) {
          Factory.deleteEntity(theCompany);
        }

       theCompany = Company.createCompany(companyContainer);

        switch (selection) {
        case 1: // Create New Company (minimally populated)
          {
            theCompany.setPopulationValues(-1);
            break;
          }

        case 2:  // Create New Company (1%)
          {
            theCompany.setPopulationValues(1);
            break;
          }

        case 3: // Create New Company (10%)
          {
            theCompany.setPopulationValues(10);
            break;
          }

        case 4:  // Create New Company (fully populated)
          {
            theCompany.setPopulationValues(100);
            break;
          }

        case 6:
          {
            return;
          }
        }
        theCompany.primeWithDummyData();
      }
    }
  }

  /**
   * Implement this method return the
   * name of your own test.
   */
  public String getName() {
    return NAME;
  }
}


