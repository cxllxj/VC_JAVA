The workload used by the example benchmark of chapter 8 is based on the TPC-C 
specification, TPC Benchmark C , Standard Specification, Revision 3.2, August
27 1996. TPC Benchmark is a trademark of the Transaction Processing 
Performance Council. 

TPC Fair Use policy:

Variations from the TPC-C specifications are noted below. Due to these
variations, any results based on this benchmark are not comparable to
any official TPC result.

We have written a Java application that implements the business logic,
but not the data base access, of the transactions specified in the
Transaction Processing Performance Council (TPC) TPC BENCHMARK C
specification. Of course this is not an official TPC-C benchmark
because;

* it is an OO implementation with appropriate changes to the schema,
* it does not support object persistence with ACID properties
   corresponding to a RDB implementation,
* it is self driving and does not measure "terminal response" or
  "communication interface" time,
* it is posible to vary the object populations in non-standard ways,
* and has not been audited by TPC.

See Chapter 8 for more information.
