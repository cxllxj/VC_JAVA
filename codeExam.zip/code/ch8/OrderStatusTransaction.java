// This source is an example application.
// IBM grants you a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided by IBM for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// IBM, therefore, cannot guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL IBM BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
// 5648 - BP1
// (C) Copyright IBM Corp. 1998
// All rights reserved.
// US Government Users Restricted Rights -
// Use, duplication, or disclosure restricted
// by GSA ADP Schedule Contract with IBM Corp.
//
// Licensed Materials - Property of IBM
import java.util.*;
import infra.Util.DisplayScreen;

class OrderStatusTransaction extends CommonTransaction {
  private static final long WAITTIMESTYPING = 2;
  private static final long WAITTIMESTHINKING = 10;
  private Company company;
  private byte    warehouseId;

  private byte    districtId;
  private String  cust_last_name;
  private boolean use_customerId;
  private short   customerId;
  private Customer  customer;
  private float   customerBalance;
  private String  customerFirstName;
  private String  customerMiddleName;
  private String  customerLastName;

  private Warehouse warehouse;
  private District  district;
  private Order   currentOrder;
  private int   orderId;
  private Date    orderEntryDate;
  private short   orderCarrierId;
  private int   orderLineCount;

  private byte    ol_supplying_warehouse[];
  private int   ol_item_id[];
  private String  ol_item_name[];
  private short   ol_quantity[];
  private int   ol_stock[];
  private char    ol_b_g[];
  private float   ol_item_price[];
  private float   ol_amount[];
  private Date    ol_delivery_date[];

  private DisplayScreen backScreen;
  private DisplayScreen initScreen;
  private DisplayScreen orderScreen;

  public OrderStatusTransaction(Company inCompany,
                                byte inWarehouseId) {
    super(WAITTIMESTYPING, WAITTIMESTHINKING);

    int i;
    company = inCompany;
    warehouseId = inWarehouseId;

    ol_supplying_warehouse = 
       new byte[Transaction.MAXORDERLINES];
    ol_item_id = new int[Transaction.MAXORDERLINES];
    ol_item_name = new String[Transaction.MAXORDERLINES];
    ol_quantity = new short[Transaction.MAXORDERLINES];
    ol_stock = new int[Transaction.MAXORDERLINES];
    ol_b_g = new char[Transaction.MAXORDERLINES];
    ol_item_price = new float[Transaction.MAXORDERLINES];
    ol_amount = new float[Transaction.MAXORDERLINES];
    ol_delivery_date = new Date[Transaction.MAXORDERLINES];

    // 2.6.3.1
    backScreen = new DisplayScreen();
    backScreen.putText("Order-Status", 34, 0, 12);
    backScreen.putText("Warehouse:", 0, 1, 10);
    backScreen.putInt (warehouseId, 11, 1, 4);
    backScreen.putText("District:", 18, 1, 9);
    backScreen.putText("Customer:", 0, 2, 10);
    backScreen.putText("Name:", 18, 2, 5);
    backScreen.putText("Cust-Balance:", 0, 3, 14);
    backScreen.putText("Order-Number:", 0, 5, 14);
    backScreen.putText("Entry-Date:", 25, 5, 12);
    backScreen.putText("Carrier-Number:", 59, 5, 16);
    backScreen.putText("Supply-W     Item-Id    Qty      "
                       + "Amount     Delivery-Date", 
                       0, 6, 60);

    initScreen = new DisplayScreen(backScreen);
    // initScreen.putCharFill('9', 11, 1, 4);
    initScreen.putCharFill('9', 28, 1, 2);
    initScreen.putCharFill('9', 10, 2, 4);
    initScreen.putCharFill('X', 23, 2, 16);
    initScreen.putCharFill('X', 40, 2, 2);
    initScreen.putCharFill('X', 43, 2, 16);
    initScreen.putText("$-99999.99", 14, 3, 10);
    initScreen.putCharFill('9', 14, 5, 8);
    initScreen.putText("DD-MM-YYYY", 37, 5, 10);
    initScreen.putText("hh:mm:ss", 48, 5, 8);
    initScreen.putCharFill('9', 75, 5, 2);

    for (i=7; i<22; i++) {
      initScreen.putCharFill('9',  2, i, 4);
      initScreen.putCharFill('9', 13, i, 6);
      initScreen.putCharFill('9', 24, i, 2);
      initScreen.putText("$99999.99", 32, i,9);
      initScreen.putText("DD-MM-YYYY", 46, i, 10);
    }

    orderScreen = new DisplayScreen();
  }

  public synchronized void delete() {
    
  }

  public synchronized void init( ) {
    // 2.6.1.2
    districtId = (byte)Butil.random(1,
                    company.getMaxDistricts());
    int y = (int)Butil.random(1,100);
    if (y <= 60) {
      // 2.6.1.2 bullet one (select Customer by last name)
      cust_last_name = Butil.create_random_last_name(0);
      use_customerId = false;
    } else {
      // 2.6.1.2 bullet two (select Customer by ID)
      customerId = (short)Butil.NUrand_val(Butil.A_C_ID,1, 
                company.getMaxCustomers(),
                Butil.C_C_ID );
      use_customerId = true;
    }
  }

  public void process() {
    int line_number = 0;
    if (use_customerId) {
      // 2.6.2.2 bullet 3, case 1
      long uniqueCustomerId =
      company.buildUniqueCustomerKey(warehouseId,
                                     districtId,
                                     customerId);
      // get customer 
      customer = company.getCustomer(uniqueCustomerId);
    } else {
      // 2.6.2.2 bullet 3, case 2
      // get customer 
      customer = 
         company.getCustomerByLastName(warehouseId,
                                       districtId,
                                       cust_last_name);
    }
    if (customer != null) {
      customerId = customer.getId();
      customerBalance = customer.getBalance();
      customerFirstName = customer.getFirstName();
      customerMiddleName = customer.getMiddleName();
      customerLastName = customer.getLastName();

      // 2.6.2.2 bullet 4
      // get write lock on current order
      currentOrder = customer.getLatestOrder();
      if (currentOrder != null) {
        orderId = currentOrder.getId().intValue();
        orderEntryDate = currentOrder.getEntryTime();
        orderCarrierId = currentOrder.getCarrierId();
        orderLineCount = 
           currentOrder.getOrderlineCount();

        // 2.6.2.2 bullet 5
        Orderline orderline;
        Object[] orderlineList;
        int i;
        orderlineList = currentOrder.getOrderlineList();

        for (i = 0; i < orderLineCount; i++) {
          orderline = (Orderline)orderlineList[i];
          ol_supplying_warehouse[line_number] = 
             orderline.getSupplyWarehouse();
          ol_item_id[line_number] = orderline.getItemId();
          ol_item_name[line_number] = 
             orderline.getItemName();
          ol_quantity[line_number] = 
             orderline.getQuantity();
          ol_stock[line_number] = 
             orderline.getStockQuantity();
          ol_b_g[line_number] = 
             orderline.getBrandGeneric();
          ol_item_price[line_number] = 
             orderline.getItemPrice();
          ol_amount[line_number] = orderline.getAmount();
          ol_delivery_date[line_number] = 
             orderline.getDeliveryDateTime();

          line_number++;
        }
      } else {
        
      }
    } else {
      customerId = 0;
      customerFirstName = "";
      customerMiddleName = "";
      customerLastName = cust_last_name;
      customerBalance = 0.0f;
      currentOrder = null;
    }
  }

  public synchronized void initialDisplay() {
    Date screenDate = new Date();
    // 2.6.3.1
    orderScreen.putDate(screenDate, 37, 5, 10);

    if (SetValues.getScreenWrite())
      initScreen.display();
  }

  public synchronized void secondDisplay() {
    Date screenDate = new Date();
    orderScreen.copyScreen(backScreen);
    // 2.6.3.3
    orderScreen.putInt(districtId, 28, 1, 2);
    orderScreen.putInt(customerId, 10, 2, 4);
    orderScreen.putText(customerFirstName, 23, 2, 16);
    orderScreen.putText(customerMiddleName, 40, 2, 2);
    orderScreen.putText(customerLastName, 43, 2, 16);
    orderScreen.putDollars(customerBalance, 14, 3, 10);
    if (currentOrder != null) {
      Date deliveryDate;
      orderScreen.putInt(orderId, 14, 5, 8);
      orderScreen.putDate(orderEntryDate, 37, 5, 10);
      orderScreen.putTime(orderEntryDate, 48, 5, 8);
      orderScreen.putInt(orderCarrierId, 75, 5, 2);

      for (int i=0; i < orderLineCount; i++) {
        orderScreen.putInt(ol_supplying_warehouse[i],  
                           2, i+7, 4);
        orderScreen.putInt(ol_item_id[i], 13, 
                           i+7, 6);
        orderScreen.putInt(ol_quantity[i], 24, 
                           i+7, 2);
        orderScreen.putDollars(ol_amount[i], 32, 
                               i+7,9);
        deliveryDate = ol_delivery_date[i];
        if (deliveryDate != null)
          orderScreen.putDate(deliveryDate, 46, 
                              i+7, 10);
      }
    } else {
      if (customer == null) {
        orderScreen.putText("No customer found "
                            + "for last name.",  
                            2, 4, 32);
      } else {
        orderScreen.putText("No orders pending.",  
                            2, 7, 20);
      }
    }

    if (SetValues.getScreenWrite())
      orderScreen.display();

  }

}
