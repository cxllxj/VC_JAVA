// This source is an example application.
// IBM grants you a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided by IBM for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// IBM, therefore, cannot guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL IBM BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
// 5648 - BP1
// (C) Copyright IBM Corp. 1998
// All rights reserved.
// US Government Users Restricted Rights -
// Use, duplication, or disclosure restricted
// by GSA ADP Schedule Contract with IBM Corp.
//
// Licensed Materials - Property of IBM
import infra.Factory.Factory;
import infra.Base;
import infra.Entity;
import infra.Location;

import java.util.*;

public
class District extends Entity {

  private static Class DistrictClassRef;
  private static Location with = Location.createWith();

  static {
    try {
      DistrictClassRef = Class.forName("District");
    } catch (ClassNotFoundException e) {
      Butil.textOut(
            "District Static Init - ClassNotFoundException");
    }
  }

  // misc stuff
  private Map orderTable;
  private Map newOrderTable;

  private String  name;   // D_NAME
  private Address   address;  // see Address
  private float   taxRate;  // D_TAX
  private float   ytd;    // D_YTD
  private int   nextOrder;  // D_NEXT_O_ID
  private byte    districtId; // D_ID
  private byte    warehouseId;  // D_W_ID

  public static District createDistrict(Base nearobj, 
                                        byte inWarehouseId, 
                                        byte inDistrictId) {
    District newDistrict = null;

    newDistrict = (District)
    Factory.createEntity(DistrictClassRef, nearobj, with);

    newDistrict.initDistrict(inWarehouseId, inDistrictId);
    return newDistrict;
  }

  public void destroy() {
    Factory.deleteEntity(address);
    address = null;

    // Remove everything from the orderTable and then delete
    Iterator orderIter = orderTable.values().iterator();
    Order order;
    while (orderIter.hasNext()) {
      order = (Order)orderIter.next();
      orderIter.remove();
      Factory.deleteEntity(order);
    }
    //   Factory.deleteEntity(orderTable);
    orderTable = null;

    Iterator newOrderIter = newOrderTable.
                             values().iterator();
    NewOrder newOrder;
    while (newOrderIter.hasNext()) {
      newOrder = (NewOrder)newOrderIter.next();
      newOrderIter.remove();
      Factory.deleteEntity(newOrder);
    }
    //  Factory.deleteEntity(newOrderTable);
    newOrderTable = null;

    super.destroy();
  }

  public
  District(byte inWarehouseId,
           byte inDistrictId) {
    districtId = inDistrictId;
    warehouseId = inWarehouseId;
    address = Address.createAddress(this);
    nextOrder = 1;
    orderTable = Collections.synchronizedMap(new TreeMap());
    newOrderTable=Collections.synchronizedMap(new TreeMap());
  }

  public District() {
    
  }

  public void initDistrict(byte inWarehouseId,
                           byte inDistrictId) {
    districtId = inDistrictId;
    warehouseId = inWarehouseId;
    address = Address.createAddress(this);
    orderTable = Collections.synchronizedMap(new TreeMap());
    newOrderTable=Collections.synchronizedMap(new TreeMap());
    nextOrder = 1;
  }

  public int getId() {
    return districtId;
  }

  public float getTaxRate() {
    return taxRate;
  }

  public Address getAddress() {
    return address;
  }

  public synchronized int
  lastOrderId() {
    
    int temp = nextOrder - 1;
    return temp;
  }

  public synchronized int nextOrderId() {
    return nextOrder++;
  }

  public synchronized void receivePayment(float amount) {
    ytd += amount;
  }

  public synchronized void setUsingRandom() {
    // districtId & warehouseId were already set in 
    // the constructor
    // 4.3.3.1 bullet 2, sub-bullet 2
    name = Butil.create_random_a_string(6,10);
    address.setUsingRandom();     // address
    taxRate = Butil.create_random_float_val_return(0.0f, 
                                                   0.2000f, 
                                                   0.0001f); // tax rate
    ytd = 30000.00f;
  }

  public synchronized void
  addOrder(Order anOrder) {
    orderTable.put(anOrder.getId(), anOrder);
  }

  public synchronized Order retrieveOrder(Order order) {
    return (Order)orderTable.get(order.getId());
  }

  public synchronized void addNewOrder(NewOrder aNewOrder) {
    newOrderTable.put(aNewOrder.getId(), aNewOrder);
  }

  public synchronized NewOrder removeFirstNewOrder() {
    NewOrder temp = null;
    
    // attach an iterator to the newOrderTable
    Iterator newOrders = newOrderTable.values().iterator();

    // since a TreeMap table is sorted by key, 
    // the first value returned by an iterator 
    // will be the element with the least key, as required
    // by 2.7.4.2 2nd bullet get newOrder with a write lock
    if (newOrders.hasNext()) {
      temp = (NewOrder)newOrders.next();
      newOrders.remove();
    }

    return temp;
  }

  public synchronized Map getOrderTable() {
    return orderTable;
  }

  public synchronized String getName() {
    return name;
  }
}
