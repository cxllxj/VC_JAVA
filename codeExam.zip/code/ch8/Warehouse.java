// This source is an example application.
// IBM grants you a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided by IBM for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// IBM, therefore, cannot guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL IBM BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
// 5648 - BP1
// (C) Copyright IBM Corp. 1998
// All rights reserved.
// US Government Users Restricted Rights -
// Use, duplication, or disclosure restricted
// by GSA ADP Schedule Contract with IBM Corp.
//
// Licensed Materials - Property of IBM
import infra.Factory.Factory;
import infra.Base;
import infra.Factory.Container;
import infra.Entity;
import infra.Location;
import java.util.*;

public
class Warehouse extends Entity {

  private static Class WarehouseClassRef;
  private static Location with = Location.createWith();

  static {
    try {
      WarehouseClassRef = Class.forName("Warehouse");
    } catch (ClassNotFoundException e) {
      Butil.textOut("Warehouse Static Init - "
                    + "ClassNotFoundException");
    }
  }

  public static Warehouse createWarehouse(Base nearobj,
                                          Company inCompany,
                                          Map inItemTable) {
    Warehouse newWarehouse = null;

    newWarehouse = (Warehouse)
    Factory.createEntity(WarehouseClassRef, nearobj, with);

    newWarehouse.initWarehouse(inCompany, inItemTable);

    return newWarehouse;
  }

  // BOB-C required fields
  private String  name;   // W_NAME
  private Address   address;  // Address
  private float   taxRate;  // Tax Rate
  private float   ytd;    // W_YTD
  private byte    warehouseId;  // W_ID
  private Company   company;
  private Map stockTable;
  private Map itemTable;
  private Object[] districts;
  private int distCount;

  public void destroy() {

    // delete all districts & remove them from the District table
    District district;
    int i;
    for (i=0; i<distCount; i++) {
      district = (District)districts[i];
      districts[i] = null;
      Factory.deleteEntity(district);
    }
    Factory.destroyPermInstance(districts);
    districts = null;

    // delete all stock & remove them from the stockTable
    Iterator stockIter = stockTable.values().iterator();
    Stock stock;
    while (stockIter.hasNext()) {
      stock = (Stock)stockIter.next();
      stockIter.remove();
      stock.destroyInstance();
    }
    stock = null;
    //  Factory.deleteEntity(stockTable);
    stockTable = null;

    Factory.deleteEntity(address);
    address = null;

    super.destroy();
  }

  public Warehouse(Company inCompany,
                   Map inItemTable) {
    company = inCompany;
    districts = new Object[20];
    stockTable = Collections.synchronizedMap(new TreeMap());
    itemTable = inItemTable;
    address = Address.createAddress(this);

    ytd = 0;
    loadStockTable();  // 4.3.3.1 bullet 2, sub-bullet 1
  }

  public Warehouse() {
  }

  public void initWarehouse(Company inCompany,
                            Map inItemTable) {
    ytd = 0;
    company = inCompany;
    districts = new Object[20];
    stockTable = Collections.synchronizedMap(new TreeMap());
    itemTable = inItemTable;
    address = Address.createAddress(this);

    ytd = 0;
    loadStockTable();  // 4.3.3.1 bullet 2, sub-bullet 1
  }

  public boolean validDistrict(byte inDistrictId) {
    District currentDistrict;
    int i;

    for (i=0; i<distCount; i++) {
      currentDistrict = (District)districts[i];
      if (currentDistrict.getId() == inDistrictId)
        return true;
    }

    return false; // not found
  }

  public byte getId() {
    return warehouseId;
  }

  public float getTaxRate() {
    return taxRate;
  }

  public Address getAddress() {
    return address;
  }

  public District getDistrict(byte inDistrictId) {
    District result = null;
    if (inDistrictId > 0) {
      inDistrictId--;
      if (inDistrictId < distCount)
        result = (District)districts[inDistrictId];
    }
    return result;
  }

  public Stock retrieveStock(int inItemId) {
    return (Stock)stockTable.get(new Integer(inItemId));
  }

  public Item retrieveItem(int inItemId) {
    return (Item )itemTable.get(new Integer(inItemId));
  }

  public synchronized void receivePayment(float amount) {
    ytd += amount;
  }

  public District getDistrict(int distId) {
    District result = null;
    if (distId > 0) {
      distId--;
      if (distId < distCount)
        result = (District)districts[distId];
    }
    return result;
  }

  public int getDistrictCount() {
    return distCount;
  }

  public synchronized void setUsingRandom(byte whID) {
    warehouseId = whID;

    // 4.3.3.1 bullet 2
    name = Butil.create_random_a_string(6,10);
    address.setUsingRandom();       // address
    taxRate = Butil.create_random_float_val_return(0.0f, 
                                                   0.2000f,
                                                   0.0001f);
    ytd = 300000.00f;

    distCount = company.getMaxDistricts();
    for (int i = 0; i < distCount; ++i) {
      byte newDistrictId = (byte)(i + 1);
      District newDistrict = 
         District.createDistrict(this,
                                 warehouseId, 
                                 newDistrictId);

      newDistrict.setUsingRandom();
      districts[i] = newDistrict;
    }
  }

  public String getName() {
    return new String(name);
  }

  public void loadStockTable() {
    Iterator itemIter = itemTable.values().iterator();
    Item currItem;
    Stock newStock;
    int i = 0;

    while (itemIter.hasNext()) {
      currItem = (Item)itemIter.next();
      i++;
      newStock = Stock.createStock(this,
                              company, 
                              currItem.getId().intValue(),
                              warehouseId);

      stockTable.put(newStock.getId(),newStock);
    }
  }
}
