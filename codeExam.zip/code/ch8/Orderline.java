// This source is an example application.
// IBM grants you a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided by IBM for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// IBM, therefore, cannot guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL IBM BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
// 5648 - BP1
// (C) Copyright IBM Corp. 1998
// All rights reserved.
// US Government Users Restricted Rights -
// Use, duplication, or disclosure restricted
// by GSA ADP Schedule Contract with IBM Corp.
//
// Licensed Materials - Property of IBM
import infra.Factory.Factory;
import infra.Base;
import infra.Entity;
import infra.Location;
import java.util.*;

public
class Orderline extends Entity {
  private static Class OrderlineClassRef;
  static Location near = Location.createNear();

  static {
    try {
      OrderlineClassRef = Class.forName("Orderline");
    } catch (ClassNotFoundException e) {
      Butil.textOut("Orderline Static Init - "
                    + "ClassNotFoundException");
    }
  }

  private Date    deliveryDateTime; // OL_DELIVERY_DATE
  private String  districtInfo;   // OL_DIST_INFO
  private float   amount;     // OL_AMOUNT
  private int     orderId;    // OL_O_ID
  private int     itemId;     // OL_I_ID
  private short   orderLineNumber;  // OL_NUMBER
  private short   quantity;   // OL_QUANTITY
  private byte    districtId;   // OL_D_ID
  private byte    warehouseId;    // OL_W_ID
  private byte    supplyWarehouseId;  // OL_SUPPLY_W_ID
  private Company company;
  private Warehouse warehouse;
  private Stock   stock;
  private String  itemName;
  private float   itemPrice;
  private int     stockQuantity;
  private char    BrandGeneric;

  public static Orderline createOrderline(Base nearobj,
                                Company inCompany,
                                int inOrderId,
                                byte inDistrictId,
                                byte inWarehouseId,
                                short inLineNumber,
                                short number_of_orderlines,
                                boolean rollback) {
    Orderline newOrderline = null;

    newOrderline = (Orderline)
    Factory.createEntity(OrderlineClassRef, nearobj, near);

    newOrderline.initOrderline (inCompany,
                                inOrderId,
                                inDistrictId,
                                inWarehouseId,
                                inLineNumber,
                                number_of_orderlines,
                                rollback);
    return newOrderline;
  }

  public void destroy() {
    districtInfo = null;

    Factory.destroyPermInstance(deliveryDateTime);
    deliveryDateTime = null;

    super.destroy();
  }

  public Orderline(Company inCompany,
                   int inOrderId,
                   byte inDistrictId,
                   byte inWarehouseId,
                   short inLineNumber,
                   short number_of_orderlines,
                   boolean rollback) {
    company = inCompany;
    orderId = inOrderId;
    districtId = inDistrictId;
    warehouseId = inWarehouseId;
    orderLineNumber = inLineNumber;  // 2.4.2.2. bullet 8.5

    // 2.4.1.5 - #1
    itemId = Butil.NUrand_val(Butil.A_OL_I_ID, 1, 
                              company.getMaxItems(), 
                              Butil.C_OL_I_ID );

    // 2.4.1.5 - #1 Comment
    if ((inLineNumber == number_of_orderlines) && rollback)
       // if rollback=true then set to unused item
      itemId = 0;  

    // 2.4.2.2 bullet 8.5
    deliveryDateTime = null;

    // 2.4.1.5 - #3
    quantity = (short)Butil.random(1,10);

    // set defaults for remaining fields
    //   ('Process' method will complete)
    amount = 0.0f;
    districtInfo = null;
  }

  public Orderline() {
    
  }

  public void initOrderline(Company inCompany,
                            int inOrderId,
                            byte inDistrictId,
                            byte inWarehouseId,
                            short inLineNumber,
                            short number_of_orderlines,
                            boolean rollback) {
    company = inCompany;
    orderId = inOrderId;
    districtId = inDistrictId;
    warehouseId = inWarehouseId;
    orderLineNumber = inLineNumber;  // 2.4.2.2. bullet 8.5

    // 2.4.1.5 - #1
    itemId = Butil.NUrand_val(Butil.A_OL_I_ID, 1, 
                              company.getMaxItems(), 
                              Butil.C_OL_I_ID );

    // 2.4.1.5 - #1 Comment
    if ((inLineNumber == number_of_orderlines) && rollback)
      // if rollback=1 then set to unused item
      itemId = 0;  

    // 2.4.2.2 bullet 8.5
    deliveryDateTime = null;

    // 2.4.1.5 - #3
    quantity = (short)Butil.random(1,10);

    // set defaults for remaining fields
    //   ('Process' method will complete)
    amount = 0.0f;
    districtInfo = null;
  }

  public synchronized boolean 
     validateAndProcess(Warehouse inWarehouse) {
    boolean temp;
    Item itemRef=null;
    Stock stockRef=null;

    if (inWarehouse != null) {
      itemRef = inWarehouse.retrieveItem(itemId);
      stockRef = inWarehouse.retrieveStock(itemId);
    }

    if ((inWarehouse != null) &&
        (itemRef != null) &&
        (stockRef != null)) {
      //item = itemRef;
      stock = stockRef;
      process(itemRef, stockRef);

      temp = true;
    } else
      temp = false;

    return temp;
  }

  private void process(Item itemRef, Stock stockRef) {
    // 2.4.2.2 bullet 8.1 (1st sentence)
    itemName  = itemRef.getName();
    itemPrice = itemRef.getPrice();
    String itemData  = itemRef.getBrandInfo();

    // 2.4.2.2 bullet 8.2
    stockQuantity = stockRef.getQuantity();
    String stock_districtInfo = 
       stockRef.getDistrictInfo(districtId);
    String stockData = stockRef.getData();

    if (stockQuantity >= (quantity + 10))
      stockRef.changeQuantity(-quantity);
    else
      stockRef.changeQuantity(91-quantity);

    stockRef.incrementYTD(quantity);
    stockRef.incrementOrderCount();
    if (warehouseId == supplyWarehouseId)
      stockRef.incrementRemoteCount();

    // 2.4.2.2 bullet 8.3
    amount = quantity * itemPrice;

    // 2.4.2.2 bullet 8.4
    if ((itemData.indexOf("ORIGINAL") > 0) && 
        (stockData.indexOf("ORIGINAL") > 0))
      BrandGeneric = 'B';
    else
      BrandGeneric = 'G';

    // 2.4.2.2 bullet 8.5
    districtInfo = stock_districtInfo;
  }

  public Stock getStock() {
    return stock;
  }

  public synchronized float getAmount() {
    return amount;
  }

  public synchronized char getBrandGeneric() {
    return BrandGeneric;
  }

  public synchronized int getItemId() {
    return itemId;
  }

  public synchronized String getItemName() {
    return itemName;
  }

  public synchronized float getItemPrice() {
    return itemPrice;
  }

  public synchronized byte getSupplyWarehouse() {
    return supplyWarehouseId;
  }

  public synchronized int getStockQuantity() {
    return stockQuantity;
  }

  public synchronized void 
     setSupplyWarehouse(byte inWarehouseId) {
    supplyWarehouseId = inWarehouseId;
  }

  public synchronized Date getDeliveryDateTime() {
    return deliveryDateTime;
  }

  public synchronized void 
     setDeliveryTime(Date deliveryTime) {
    if (deliveryDateTime != null)
      Factory.destroyPermInstance(deliveryDateTime);

    deliveryDateTime = deliveryTime;
  }

  public synchronized short getQuantity() {
    return quantity;
  }

  public synchronized void setQuantity(short inQuantity) {
    quantity = inQuantity;
  }

  public synchronized void setAmount(float inAmount) {
    amount = inAmount;
  }

  public synchronized void setDistrictInfo(String inInfo) {
    districtInfo = inInfo;
  }
}
