// This source is an example application.
// IBM grants you a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided by IBM for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// IBM, therefore, cannot guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL IBM BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
// 5648 - BP1
// (C) Copyright IBM Corp. 1998
// All rights reserved.
// US Government Users Restricted Rights -
// Use, duplication, or disclosure restricted
// by GSA ADP Schedule Contract with IBM Corp.
//
// Licensed Materials - Property of IBM
import infra.Factory.Factory;
import infra.Base;
import infra.Entity;
import infra.Location;

public
class NewOrder extends Entity {

  private static Class NewOrderClassRef;
  private static Location with = Location.createWith();

  static {
    try {
      NewOrderClassRef = Class.forName("NewOrder");
    } catch (ClassNotFoundException e) {
      Butil.textOut("NewOrder Static Init - "
                    + "ClassNotFoundException");
    }
  }

  private Order order;
  private int	orderId;		// NO_O_ID
  private byte  districtId;   // NO_D_ID
  private byte  warehouseId;    // NO_W_ID

  public static NewOrder createNewOrder(Base nearobj,
                                        Order inOrder,
                                        int inOrderId,
                                        byte inDistrictId,
                                        byte inWarehouseId) {
    NewOrder newNewOrder = null;

    newNewOrder = (NewOrder)
    Factory.createEntity(NewOrderClassRef, nearobj, with);

    newNewOrder.initNewOrder(inOrder,
                             inOrderId,
                             inDistrictId,
                             inWarehouseId);
    return newNewOrder;
  }

  public NewOrder(Order inOrder,
                  int inOrderId,
                  byte inDistrictId,
                  byte inWarehouseId) {
    order = inOrder;
    orderId = inOrderId;
    districtId = inDistrictId;
    warehouseId = inWarehouseId;
  }

  public NewOrder() {
    
  }

  public void initNewOrder(Order inOrder,
                           int inOrderId,
                           byte inDistrictId,
                           byte inWarehouseId) {
    order   = inOrder;
    orderId  = inOrderId;
    districtId   = inDistrictId;
    warehouseId  = inWarehouseId;
  }

  public synchronized Integer getId() {
     return new Integer(orderId);
  }

  public synchronized Order getOrder() {
    return order;
  }
}
