// This source is an example application.
// IBM grants you a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided by IBM for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// IBM, therefore, cannot guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL IBM BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
// 5648 - BP1
// (C) Copyright IBM Corp. 1998
// All rights reserved.
// US Government Users Restricted Rights -
// Use, duplication, or disclosure restricted
// by GSA ADP Schedule Contract with IBM Corp.
//
// Licensed Materials - Property of IBM
import infra.Factory.Factory;
import infra.Base;
import infra.Entity;
import infra.Location;

import java.util.*;

public
class History extends Entity {
  private static Class HistoryClassRef;
  private static Location with;

  static {
    try {
      with = Location.createWith();
      HistoryClassRef = Class.forName("History");
    } catch (ClassNotFoundException e) {
      Butil.textOut(
             "History Static Init - ClassNotFoundException");
    }
  }

  private Date    date;     // H_DATE
  private String  data;     // H_DATA
  private float   amount;     // H_AMOUNT
  private short   customerId;   // H_C_ID
  private byte    customerDistrictId; // H_C_D_ID
  private byte    customerWarehouseId;  // H_C_W_ID
  private byte    districtId;   // H_D_ID
  private byte    warehouseId;    // H_W_ID

  public static History createHistory(Base nearobj, 
                                short  inCustomerId,
                                byte   inCustomerDistrictId,
                                byte   inCustomerWarehouseId,
                                byte   inDistrictId,
                                byte   inWarehouseId,
                                Date   inDate,
                                float  inAmount,
                                String inData) {
    History newHistory = null;

    newHistory = (History)
        Factory.createEntity(HistoryClassRef, nearobj, with);

    newHistory.initHistory (inCustomerId,
                            inCustomerDistrictId,
                            inCustomerWarehouseId,
                            inDistrictId,
                            inWarehouseId,
                            inDate,
                            inAmount,
                            inData);

    return newHistory;
  }

  public History(short  inCustomerId,
                 byte   inCustomerDistrictId,
                 byte   inCustomerWarehouseId,
                 byte   inDistrictId,
                 byte   inWarehouseId,
                 Date   inDate,
                 float  inAmount,
                 String inData) {
    customerId    = inCustomerId;   // H_C_ID
    customerDistrictId  = inCustomerDistrictId; // H_C_D_ID
    customerWarehouseId = inCustomerWarehouseId;// H_C_W_ID
    districtId    = inDistrictId;   // H_D_ID
    warehouseId   = inWarehouseId;  // H_W_ID
    date      = inDate;   // H_DATE
    amount    = inAmount;   // H_AMOUNT
    data      = inData;   // H_DATA
  }

  public History() {
    
  }

  public void initHistory(short  inCustomerId,
                          byte   inCustomerDistrictId,
                          byte   inCustomerWarehouseId,
                          byte   inDistrictId,
                          byte   inWarehouseId,
                          Date   inDate,
                          float  inAmount,
                          String inData) {
    customerId    = inCustomerId;   // H_C_ID
    customerDistrictId  = inCustomerDistrictId; // H_C_D_ID
    customerWarehouseId = inCustomerWarehouseId;// H_C_W_ID
    districtId    = inDistrictId;   // H_D_ID
    warehouseId   = inWarehouseId;  // H_W_ID
    date      = inDate;   // H_DATE
    amount    = inAmount;   // H_AMOUNT
    data      = inData;   // H_DATA
  }

  public synchronized String
  buildData(String warehouseName,
            String districtName) {

    data = warehouseName + "   " + districtName;
    String temp = data;
    return temp;
  }
}
