// This source is an example application.
// IBM grants you a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided by IBM for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// IBM, therefore, cannot guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL IBM BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
// 5648 - BP1
// (C) Copyright IBM Corp. 1998
// All rights reserved.
// US Government Users Restricted Rights -
// Use, duplication, or disclosure restricted
// by GSA ADP Schedule Contract with IBM Corp.
//
// Licensed Materials - Property of IBM

import infra.Factory.Factory;
import infra.Base;
import infra.Entity;
import infra.Location;

public
class Address extends Entity {
  private static Class AddressClassRef;
  static Location near = Location.createNear();

  private String street1;
  private String street2;
  private String city;
  private String state;
  private String zip;

  static {
    try {
      AddressClassRef = Class.forName("Address");
    } catch (ClassNotFoundException e) {
      Butil.textOut("Address Static Init - "
                    + "ClassNotFoundException");
    }
  }

  public static Address
  createAddress(Base nearobj) {
    Address newAddress = null;

    newAddress = (Address)
    Factory.createEntity(AddressClassRef, nearobj, near);

    return newAddress;
  }

  public static Address
  createAddress(Base ownobj, Base nearobj, Location loc) {
    Address newAddress = null;

    newAddress = (Address)
    Factory.createEntity(AddressClassRef, nearobj, loc);

    return newAddress;
  }

  public synchronized void setUsingRandom() {
   street1 =new String(Butil.create_random_a_string(10,20));
   street1 =new String(Butil.create_random_a_string(10,20));
   street2 =new String(Butil.create_random_a_string(10,20));
   city =new String(Butil.create_random_a_string(10,20));
   state =new String(Butil.create_random_a_string(2,2));
   zip =new String(Butil.create_random_n_string(9,9));
  }

  public synchronized String getStreet1() {
    return street1;
  }

  public synchronized String getStreet2() {
    return street2;
  }

  public synchronized String getCity() {
    return city;
  }

  public synchronized String getState() {
    return state;
  }

  public synchronized String getZip() {    
    return zip;
  }
}
