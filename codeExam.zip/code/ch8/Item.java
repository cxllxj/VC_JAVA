// This source is an example application.
// IBM grants you a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided by IBM for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// IBM, therefore, cannot guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL IBM BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
// 5648 - BP1
// (C) Copyright IBM Corp. 1998
// All rights reserved.
// US Government Users Restricted Rights -
// Use, duplication, or disclosure restricted
// by GSA ADP Schedule Contract with IBM Corp.
//
// Licensed Materials - Property of IBM
import infra.Factory.Factory;
import infra.Base;
import infra.Entity;
import infra.Location;

public class Item extends Entity {

  private static Class ItemClassRef;
  private static Location with = Location.createWith();

  static {
    try {
      ItemClassRef = Class.forName("Item");
    } catch (ClassNotFoundException e) {
      Butil.textOut(
            "Item Static Init - ClassNotFoundException");
    }
  }

  private String  name;
  private String  brandInformation;
  private float   price;
  private int   id;

  public static Item createItem(Base nearobj) {
      return (Item)Factory.createEntity(ItemClassRef, 
                                        nearobj, with);
  }

  public Integer getId() {
    return new Integer(id);
  }

  public String getName() {
    return name;
  }

  public String getBrandInfo() {
    return brandInformation;
  }

  public float getPrice() {
    return price;
  }

  public synchronized void setUsingRandom(int inId) {
    id = inId;
    // 4.3.3.1 bullet 1
    name = Butil.create_random_a_string(14, 24);
    price = Butil.create_random_float_val_return(1.00f, 
                                                 100.00f, 
                                                 .01f);

    //Integer hit = new Integer(0);
    brandInformation = 
      Butil.create_a_string_with_original(26, 50, 10, null);
  }
}
