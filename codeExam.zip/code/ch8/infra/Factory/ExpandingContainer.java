// This source is an example application.
// IBM grants you a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided by IBM for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// IBM, therefore, cannot guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL IBM BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
// 5648 - BP1
// (C) Copyright IBM Corp. 1998
// All rights reserved.
// US Government Users Restricted Rights -
// Use, duplication, or disclosure restricted
// by GSA ADP Schedule Contract with IBM Corp.
//
// Licensed Materials - Property of IBM
package infra.Factory;

import infra.Base;
import infra.Factory.Factory;
import infra.Factory.Container;

public class ExpandingContainer extends Container {
  static final int MAX_HEAPS = 1024;
  static private Class heapClass;
  static private Class clsObject;

  static
  {
    try {
      clsObject = Class.forName("java.lang.Object");
      heapClass = Class.forName("infra.Factory.Heap");
    } catch (ClassNotFoundException e) {
      System.out.println(
         "ExpandingContainer-ClassNotFoundException");
    }
  }

  private int containerCount;
  private Object heapList[];

  public static ExpandingContainer 
     createExpandingContainer() {
    ExpandingContainer obj;
    obj = (ExpandingContainer)
    Factory.newPermInstance(
                       "infra.Factory.ExpandingContainer");
    return obj;
  }

  public ExpandingContainer() {
    super();
    containerCount = 0;
    heapList  = super.allocArrayOfNear (clsObject, 
                                        MAX_HEAPS, this);
  }

  public ExpandingContainer(Class heap) {
    super();
    containerCount = 0;
    // set heap class for this expanding container
    heapClass = heap;

    heapList  = super.allocArrayOfNear (clsObject, 
                                        MAX_HEAPS, this);
  }

  public void setContainerName(String name) {
    contName = super.allocStringNear(name, this);
  }

  public void setHeapImpl(Class impl) {
    heapClass = impl;
  }

  public Class getHeapImpl() {
    return heapClass;
  }

  public synchronized Object allocObject(Class clsRef)
  throws InstantiationException, IllegalAccessException
  {
    Object  objRef = null;
    Heap   curHeap = null;

    if (containerCount == 0) {
      curHeap     = (Heap)Factory.permInstance(heapClass);
      curHeap.setContainerName(this.getContainerName() 
                              + "_heap_" + containerCount);
      heapList[0] = curHeap;
      curHeap.setOwningContainer(this);
      containerCount++;
    } else {
      curHeap = (Heap)heapList[containerCount-1];
      if (curHeap.getFreeSpace() < 32768L) {
        curHeap = (Heap)Factory.permInstance(heapClass);
        curHeap.setContainerName(this.getContainerName() 
                               + "_heap_" + containerCount);
        heapList[containerCount] = curHeap;
        curHeap.setOwningContainer(this);
        containerCount++;
      }
    }

    try {
      objRef = curHeap.allocObject(clsRef);
    } catch (ContainerException e) {
      if (containerCount < MAX_HEAPS) {
        curHeap = (Heap)Factory.permInstance(heapClass);
        curHeap.setContainerName(this.getContainerName() 
                               + "_heap_" + containerCount);
        heapList[containerCount] = curHeap;
        curHeap.setOwningContainer(this);
        containerCount++;

        objRef = curHeap.allocObject(clsRef);
      } else {
        throw e;
      }
    }

    return objRef;
  }

  public synchronized Object allocObjectNear(Class clsRef, 
                                             Object nearRef)
  throws InstantiationException, IllegalAccessException
  {
    Object  objRef = null;
    Heap   curHeap = null;

    if (containerCount == 0) {
      curHeap     = (Heap)Factory.permInstance(heapClass);
      curHeap.setContainerName(this.getContainerName() 
                               + "_heap_" + containerCount);
      heapList[0] = curHeap;
      curHeap.setOwningContainer(this);
      containerCount++;
    }

    if (nearRef instanceof Base) {
      curHeap = (Heap)
      ((Base)nearRef).getInstanceContainer();
    } else {
      curHeap = (Heap)heapList[containerCount-1];
    }

    try {
      objRef = curHeap.allocObjectNear(clsRef, nearRef);
    } catch (ContainerException e) {
      objRef = this.allocObject(clsRef);
    }

    return objRef;
  }

  // the follwing methods are only called from the 
  // Heap methods when a heap allocation fails.
  public synchronized Object allocArrayNear (int type, 
                                          int entries, 
                                          Object nearRef) {
    Object result = null;
    Heap   curHeap = null;
    Heap   refHeap = null;

    if (containerCount == 0) {
      curHeap     = (Heap)Factory.permInstance(heapClass);
      curHeap.setContainerName(this.getContainerName() 
                              + "_heap_" + containerCount);
      heapList[0] = curHeap;
      curHeap.setOwningContainer(this);
      containerCount++;
    } else {
      curHeap = (Heap)heapList[containerCount-1];
    }

    if (nearRef instanceof Base) {
      refHeap = (Heap)
      ((Base)nearRef).getInstanceContainer();
      if (refHeap == curHeap) {
        curHeap = (Heap)Factory.permInstance(heapClass);
        curHeap.setContainerName(this.getContainerName() 
                              + "_heap_" + containerCount);
        heapList[containerCount] = curHeap;
        curHeap.setOwningContainer(this);
        containerCount++;
      }
    }

    try {
      result = curHeap.allocArrayNear(type, 
                                      entries, curHeap);
    } catch (ContainerException e) {
      if (containerCount < MAX_HEAPS) {
        curHeap = (Heap)Factory.permInstance(heapClass);
        curHeap.setContainerName(this.getContainerName() 
                              + "_heap_" + containerCount);
        heapList[containerCount] = curHeap;
        curHeap.setOwningContainer(this);
        containerCount++;

        result = curHeap.allocArrayNear(type, 
                                        entries, curHeap);
      } else {
        throw e;
      }
    }
    return result;
  }

  public synchronized String allocStringNear(String str, 
                                          Object nearRef) {
    String result = null;
    Heap   curHeap = null;
    Heap   refHeap = null;

    if (containerCount == 0) {
      curHeap     = (Heap)Factory.permInstance(heapClass);
      curHeap.setContainerName(this.getContainerName() 
                              + "_heap_" + containerCount);
      heapList[0] = curHeap;
      curHeap.setOwningContainer(this);
      containerCount++;
    } else {
      curHeap = (Heap)heapList[containerCount-1];
    }

    if (nearRef instanceof Base) {
      refHeap = (Heap)
      ((Base)nearRef).getInstanceContainer();
      if (refHeap == curHeap) {
        curHeap = (Heap)Factory.permInstance(heapClass);
        curHeap.setContainerName(this.getContainerName() 
                              + "_heap_" + containerCount);
        heapList[containerCount] = curHeap;
        curHeap.setOwningContainer(this);
        containerCount++;
      }
    }

    try {
      result = curHeap.allocStringNear(str, curHeap);
    } catch (ContainerException e) {
      if (containerCount < MAX_HEAPS) {
        curHeap = (Heap)Factory.permInstance(heapClass);
        curHeap.setContainerName(this.getContainerName() 
                              + "_heap_" + containerCount);
        heapList[containerCount] = curHeap;
        curHeap.setOwningContainer(this);
        containerCount++;

        result = curHeap.allocStringNear(str, curHeap);
      } else {
        throw e;
      }
    }
    return result;
  }

  public synchronized String allocStringNear(char [] str, 
                                          Object nearRef) {
    String result = null;
    Heap   curHeap = null;
    Heap   refHeap = null;

    if (containerCount == 0) {
      curHeap     = (Heap)Factory.permInstance(heapClass);
      curHeap.setContainerName(this.getContainerName() 
                              + "_heap_" + containerCount);
      heapList[0] = curHeap;
      curHeap.setOwningContainer(this);
      containerCount++;
    } else {
      curHeap = (Heap)heapList[containerCount-1];
    }

    if (nearRef instanceof Base) {
      refHeap = (Heap)
      ((Base)nearRef).getInstanceContainer();
      if (refHeap == curHeap) {
        curHeap = (Heap)Factory.permInstance(heapClass);
        curHeap.setContainerName(this.getContainerName() 
                              + "_heap_" + containerCount);
        heapList[containerCount] = curHeap;
        curHeap.setOwningContainer(this);
        containerCount++;
      }
    }

    try {
      result = curHeap.allocStringNear(str, curHeap);
    } catch (ContainerException e) {
      if (containerCount < MAX_HEAPS) {
        curHeap = (Heap)Factory.permInstance(heapClass);
        curHeap.setContainerName(this.getContainerName() 
                              + "_heap_" + containerCount);
        heapList[containerCount] = curHeap;
        curHeap.setOwningContainer(this);
        containerCount++;

        result = curHeap.allocStringNear(str, curHeap);
      } else {
        throw e;
      }
    }
    return result;
  }

  public synchronized Object[] allocArrayOfNear(Class cls,
                                          int entries, 
                                          Object nearRef) {
    Object[] result = null;
    Heap   curHeap = null;
    Heap   refHeap = null;

    if (containerCount == 0) {
      curHeap     = (Heap)Factory.permInstance(heapClass);
      curHeap.setContainerName(this.getContainerName() 
                              + "_heap_" + containerCount);
      heapList[0] = curHeap;
      curHeap.setOwningContainer(this);
      containerCount++;
    } else {
      curHeap = (Heap)heapList[containerCount-1];
    }

    if (nearRef instanceof Base) {
      refHeap = (Heap)
      ((Base)nearRef).getInstanceContainer();
      if (refHeap == curHeap) {
        curHeap = (Heap)Factory.permInstance(heapClass);
        curHeap.setContainerName(this.getContainerName() 
                              + "_heap_" + containerCount);
        heapList[containerCount] = curHeap;
        curHeap.setOwningContainer(this);
        containerCount++;
      }
    }

    try {
      result = curHeap.allocArrayOfNear(cls, entries, 
                                        curHeap);
    } catch (ContainerException e) {
      if (containerCount < MAX_HEAPS) {
        curHeap = (Heap)Factory.permInstance(heapClass);
        curHeap.setContainerName(this.getContainerName() 
                              + "_heap_" + containerCount);
        heapList[containerCount] = curHeap;
        curHeap.setOwningContainer(this);
        containerCount++;

        result = curHeap.allocArrayOfNear(cls, entries, 
                                          curHeap);
      } else {
        throw e;
      }
    }
    return result;
  }
}
