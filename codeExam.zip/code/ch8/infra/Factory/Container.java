// This source is an example application.
// IBM grants you a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided by IBM for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// IBM, therefore, cannot guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL IBM BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
// 5648 - BP1
// (C) Copyright IBM Corp. 1998
// All rights reserved.
// US Government Users Restricted Rights -
// Use, duplication, or disclosure restricted
// by GSA ADP Schedule Contract with IBM Corp.
//
// Licensed Materials - Property of IBM
package infra.Factory;

import infra.Base;
import infra.InfraException;
import infra.Factory.Factory;

public class Container extends Base {

  static final int MAX_OBJECTS = 100000;

  public static Container createContainer() {
    Container obj;
    obj = (Container)Factory.newPermInstance(
                       "infra.Factory.Container");
    return obj;
  }

  static Container getContainerFor(Object objRef) {
    Container instContainer = null;
    return instContainer;
  }

  private int objCount;
  protected String contName = "?";

  public Container() {
    objCount = 0;
  }

  public void setContainerName(String name) {
    contName = this.allocStringNear(name, this);
  }

  public String getContainerName() {
    return contName;
  }

  public int getObjCount() {
    return objCount;
  }

  public long getFreeSpace() {
    return (MAX_OBJECTS - objCount) * 100;
  }

  public long getAllocSpace() {
    return objCount * 100;
  }

  public boolean spaceAvailable() {
    return (objCount < MAX_OBJECTS);
  }

  public Object allocObject(Class clsRef)
  throws InstantiationException, IllegalAccessException
  {
    Object  objRef = null;
    // no free space available of the required size
    if (objCount >= MAX_OBJECTS) {
      ContainerException e;
      e = new ContainerException("Heap Full", this);
      throw e;
    }

    try {
      objRef = clsRef.newInstance();

      if (objRef instanceof Base) {
        ((Base)objRef).setInstanceContainer(this);
        objCount++;
      }
    } catch (InstantiationException e) {
      System.out.print("allocObject-");
      System.out.println("Exception" + e.getMessage());
      e.printStackTrace();
      throw e;
    } catch (IllegalAccessException e) {
      System.out.print("allocObject-");
      System.out.println("Exception" + e.getMessage());
      e.printStackTrace();
      throw e;
    }

    return objRef;
  }

  public Object allocObjectNear(Class clsRef, 
                                Object nearRef)
  throws InstantiationException, IllegalAccessException
  {
    Object  objRef = null;
    // no free space available of the required size
    if (objCount >= MAX_OBJECTS) {
      ContainerException e;
      e = new ContainerException("Heap Full", this);
      throw e;
    }
    try {
      objRef = clsRef.newInstance();

      if (objRef instanceof Base) {
        ((Base)objRef).setInstanceContainer(this);
        objCount++;
      }
    } catch (InstantiationException e) {
      System.out.print("allocObjectNear-");
      System.out.println("Exception" + e.getMessage());
      e.printStackTrace();
      throw e;
    } catch (IllegalAccessException e) {
      System.out.print("allocObjectNear-");
      System.out.println("Exception" + e.getMessage());
      e.printStackTrace();
      throw e;
    }

    return objRef;
  }

  public Object allocArrayNear (int type, 
                                int entries, 
                                Object nearRef) {
    Object result = null;
    if (objCount >= MAX_OBJECTS) {
      ContainerException e;
      e = new ContainerException("Heap Full", this);
      throw e;
    }

    switch (type) {
    case Factory.T_BOOLEAN:
      {
        result = new boolean[entries];
        break;
      }
    case Factory.T_CHAR:
      {
        result = new char[entries];
        break;
      }
    case Factory.T_FLOAT:
      {
        result = new float[entries];
        break;
      }
    case Factory.T_DOUBLE:
      {
        result = new double[entries];
        break;
      }
    case Factory.T_BYTE:
      {
        result = new byte[entries];
        break;
      }
    case Factory.T_SHORT:
      {
        result = new short[entries];
        break;
      }
    case Factory.T_INT:
      {
        result = new int[entries];
        break;
      }
    case Factory.T_LONG:
      {
        result = new long[entries];
        break;
      }
    default:
      {
        InfraException e = 
           new InfraException("Array type invalid");
        throw e;
      }
    }

    //objCount++;
    return result;
  }

  public String allocStringNear(String str, 
                                Object nearRef) {
    String result = null;
    // no free space available of the required size
    if (objCount >= MAX_OBJECTS) {
      ContainerException e;
      e = new ContainerException("Heap Full", this);
      throw e;
    }

    result = new String(str);

    return result;
  }

  public String allocStringNear(char [] str, 
                                Object nearRef) {
    String result = null;
    // no free space available of the required size
    if (objCount >= MAX_OBJECTS) {
      ContainerException e;
      e = new ContainerException("Heap Full", this);
      throw e;
    }

    result = new String(str);

    //objCount++;
    return result;
  }

  public Object[] allocArrayOfNear (Class cls, 
                                    int entries, 
                                    Object nearRef) {
    Object[] result = null;
    // no free space available of the required size
    if (objCount >= MAX_OBJECTS) {
      ContainerException e;
      e = new ContainerException("Heap Full", this);
      throw e;
    }

    if (cls == Object.class) {
      result = new Object[entries];
    } else if (cls == String.class) {
      result = new String[entries];
    } else if (cls == Container.class) {
      result = new Container[entries];
    } else { // default
      InfraException e = 
         new InfraException("Class not supported");
      throw e;
    }

    return result;
  }

  public void deallocObject(Object objRef) {
    objCount--;
  }

  public Object reallocObject(Class clsRef, 
                              Object objRef) {
    Object obj = objRef;
    return obj;
  }
}
