// This source is an example application.
// IBM grants you a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided by IBM for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// IBM, therefore, cannot guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL IBM BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
// 5648 - BP1
// (C) Copyright IBM Corp. 1998
// All rights reserved.
// US Government Users Restricted Rights -
// Use, duplication, or disclosure restricted
// by GSA ADP Schedule Contract with IBM Corp.
//
// Licensed Materials - Property of IBM
package infra.Factory;
import infra.Base;
import infra.Factory.Factory;
import infra.Factory.Container;

public class Heap extends Container {
  public static Heap CreateHeap() {
    Heap obj;
    obj = (Heap)Factory.newPermInstance("infra.Factory.Heap");
    return obj;
  }

  public static Heap CreateHeap(Container owning) {
    Heap obj;
    obj = (Heap)Factory.newPermInstance("infra.Factory.Heap");
    obj.setOwningContainer(owning);
    return obj;
  }

  private Container owningContainer;

  public Heap() {
    super();
    owningContainer = null;
  }

  public Heap(Container owning) {
    super();
    owningContainer = owning;
  }

  public void setOwningContainer(Container owning) {
    owningContainer = owning;
  }

  public Container getOwningContainer() {
    return owningContainer;
  }

  public synchronized Object allocObjectNear(Class clsRef, Object nearRef)
  throws InstantiationException, IllegalAccessException
  {
    Object  objRef = null;

    try {
      objRef = super.allocObjectNear(clsRef, nearRef);
    } catch (ContainerException e) {
      objRef = owningContainer.allocObject(clsRef);
    }

    return objRef;
  }

  public Object allocArrayNear (int type, int entries, Object nearRef) {
    Object objRef = null;

    try {
      objRef = super.allocArrayNear(type, entries, nearRef);
    } catch (ContainerException e) {
      objRef = owningContainer.allocArrayNear(type, entries, nearRef);
    }

    return objRef;
  }

  public String allocStringNear(String str, Object nearRef) {
    String objRef = null;

    try {
      objRef = super.allocStringNear(str, nearRef);
    } catch (ContainerException e) {
      objRef = owningContainer.allocStringNear(str, nearRef);
    }

    return objRef;
  }

  public String allocStringNear(char [] str, Object nearRef) {
    String objRef = null;

    try {
      objRef = super.allocStringNear(str, nearRef);
    } catch (ContainerException e) {
      objRef = owningContainer.allocStringNear(str, nearRef);
    }

    return objRef;
  }

  public Object[] allocArrayOfNear (Class cls, int entries, Object nearRef) {
    Object[] objRef = null;

    try {
      objRef = super.allocArrayOfNear(cls, entries, nearRef);
    } catch (ContainerException e) {
      objRef = owningContainer.allocArrayOfNear(cls, entries, nearRef);
    }

    return objRef;
  }
}
