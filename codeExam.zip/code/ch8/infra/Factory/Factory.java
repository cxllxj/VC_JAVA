// This source is an example application.
// IBM grants you a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided by IBM for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// IBM, therefore, cannot guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL IBM BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
// 5648 - BP1
// (C) Copyright IBM Corp. 1998
// All rights reserved.
// US Government Users Restricted Rights -
// Use, duplication, or disclosure restricted
// by GSA ADP Schedule Contract with IBM Corp.
//
// Licensed Materials - Property of IBM
package infra.Factory;
import infra.Base;
import infra.InfraException;
import infra.Entity;
import infra.Location;

public class Factory {

  static final int T_BOOLEAN = 4;
  static final int T_CHAR = 5;
  static final int T_FLOAT = 6;
  static final int T_DOUBLE = 7;
  static final int T_BYTE = 8;
  static final int T_SHORT = 9;
  static final int T_INT = 10;
  static final int T_LONG = 11;

  static Object permInstance(Class clsRef) {
    Object  objRef = null;
    try {
      objRef = clsRef.newInstance();
    } catch (InstantiationException e) {
      System.out.print("newPermInstance-");
      System.out.println("Exception" + e.getMessage());
      e.printStackTrace();
    } catch (IllegalAccessException e) {
      System.out.print("newPermInstance-");
      System.out.println("Exception" + e.getMessage());
      e.printStackTrace();
    }
    return objRef;
  }

  public static Object newPermInstance(String clsName) {
    Class clsRef;
    Object  objRef = null;
    try {
      clsRef = Class.forName(clsName);
      objRef = permInstance(clsRef);
    } catch (ClassNotFoundException e) {
      System.out.println(
                    "newInstanceIn-ClassNotFoundException");
    }
    return objRef;
  }

  public static Object newInstanceIn(Class clsRef, 
                                     Container ctnrRef) {
    Object  objRef = null;
    try {
      objRef = ctnrRef.allocObject(clsRef);
    } catch (InstantiationException e) {
      System.out.print("newInstanceIn-");
      System.out.println("Exception" + e.getMessage());
      e.printStackTrace();
    } catch (IllegalAccessException e) {
      System.out.print("newInstanceIn-");
      System.out.println("Exception" + e.getMessage());
      e.printStackTrace();
    }
    return objRef;
  }

  public static Object newInstanceIn(String clsName, 
                                     Container ctnrRef) {
    Class clsRef;
    Object  objRef = null;
    try {
      clsRef = Class.forName(clsName);
      objRef = newInstanceIn(clsRef, ctnrRef);
    } catch (ClassNotFoundException e) {
      System.out.println(
                    "newInstanceIn-ClassNotFoundException");
    }
    return objRef;
  }

  public static Object newInstanceNear(Class clsRef, 
                                       Base nearObjRef) {
    Container ctnrRef;
    Object  objRef = null;

    try {
      ctnrRef = nearObjRef.getInstanceContainer();
      if (ctnrRef == null) { 
        objRef = clsRef.newInstance();
      } else {
        objRef =ctnrRef.allocObjectNear(clsRef, nearObjRef);
      }
    } catch (InstantiationException e) {
      System.out.print("newInstanceNear-");
      System.out.println("Exception" + e.getMessage());
      e.printStackTrace();
    } catch (IllegalAccessException e) {
      System.out.print("newInstanceNear-");
      System.out.println("Exception" + e.getMessage());
      e.printStackTrace();
    }
    return objRef;
  }

  public static Object newInstanceNear(String clsName, 
                                       Base nearObjRef) {
    Class clsRef;
    Object  objRef = null;

    try {
      clsRef = Class.forName(clsName);
      objRef = newInstanceNear(clsRef, nearObjRef);
    } catch (ClassNotFoundException e) {
      System.out.println(
                  "newInstanceNear-ClassNotFoundException");
    }
    return objRef;
  }

  public static Object newInstanceWith(Class clsRef, 
                                       Base nearObjRef) {
    Container ctnrRef;
    Object  objRef = null;

    try {
      ctnrRef = nearObjRef.getInstanceContainer();
      if (ctnrRef == null) {   
        objRef = clsRef.newInstance();
      } else {
        if (ctnrRef instanceof Heap)
          ctnrRef = ((Heap)ctnrRef).getOwningContainer();
        objRef = ctnrRef.allocObject(clsRef);
      }
    } catch (InstantiationException e) {
      System.out.print("newInstanceNear-");
      System.out.println("Exception" + e.getMessage());
      e.printStackTrace();
    } catch (IllegalAccessException e) {
      System.out.print("newInstanceNear-");
      System.out.println("Exception" + e.getMessage());
      e.printStackTrace();
    }
    return objRef;
  }

  public static Object newInstanceWith(String clsName, 
                                       Base nearObjRef) {
    Class clsRef;
    Container ctnrRef;
    Object  objRef = null;

    try {
      clsRef = Class.forName(clsName);
      objRef = newInstanceWith(clsRef, nearObjRef);
    } catch (ClassNotFoundException e) {
      System.out.println(
                  "newInstanceNear-ClassNotFoundException");
    }
    return objRef;
  }

  public static void destroyPermInstance(Object obj) {
    if (Base.noDestroy) {
      InfraException e = 
        new InfraException("destroy not supported for" 
                           + obj.toString());
      throw e;
    } else {
      if (obj instanceof Base) {
        ((Base)obj).destroyInstance();
      } else {
        // something special for arrays, strings, etc
        Container ctnr = Container.getContainerFor(obj);
        if (ctnr != null) {
          ctnr.deallocObject(obj);
        } // else must be a temp do nothing
      }
    }
  }

  public static Entity createEntity(String clsName, 
                                    Base nearobj, 
                                    Location loc) {
    Entity newEntity = null;

    if (nearobj == null) {
      Class clsRef;
      try {
        clsRef = Class.forName(clsName);
        try {
          newEntity = (Entity)clsRef.newInstance();
        } catch (InstantiationException e) {
          System.out.print("CreateEntity-");
          System.out.println("Exception" + e.getMessage());
          e.printStackTrace();
        } catch (IllegalAccessException e) {
          System.out.print("CreateEntity-");
          System.out.println("Exception" + e.getMessage());
          e.printStackTrace();
        }
      } catch (ClassNotFoundException e) {
        System.out.println(
                    "CreateEntity-ClassNotFoundException");
      }
    } else {
      if (nearobj instanceof Container) {
        newEntity = (Entity)
        Factory.newInstanceIn(clsName, (Container)nearobj);
      } else {
        if (loc.getProximity() == Location.NEAR) {
          newEntity = (Entity)
          Factory.newInstanceNear(clsName, nearobj);
        } else {
          newEntity = (Entity)
          Factory.newInstanceWith(clsName, nearobj);
        }
      }
    }

    return newEntity;
  }

  public static Entity createEntity(Class clsRef, 
                                    Base nearobj, 
                                    Location loc) {
    Entity newEntity = null;

    if (nearobj == null) {
      try {
        newEntity = (Entity)clsRef.newInstance();
      } catch (InstantiationException e) {
        System.out.print("CreateEntity-");
        System.out.println("Exception" + e.getMessage());
        e.printStackTrace();
      } catch (IllegalAccessException e) {
        System.out.print("CreateEntity-");
        System.out.println("Exception" + e.getMessage());
        e.printStackTrace();
      }
    } else {
      if (nearobj instanceof Container) {
        newEntity = (Entity)
        Factory.newInstanceIn(clsRef, (Container)nearobj);
      } else {
        if (loc.getProximity() == Location.NEAR) {
          newEntity = (Entity)
          Factory.newInstanceNear(clsRef, nearobj);
        } else {
          newEntity = (Entity)
          Factory.newInstanceWith(clsRef, nearobj);
        }
      }
    }

    return newEntity;
  }

  public static void deleteEntity(Entity obj) {
    Container ctnr;

    // call instance destroy to clean up owned Entites
    obj.destroy();

    // locate container to deallocate storage from
    ctnr = obj.getInstanceContainer();
    if (ctnr != null) {
      ctnr.deallocObject(obj);
    } else {
      // must be a temp, do nothing!
      
    }
  }
}
