// This source is an example application.
// You are granted a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// There, therefore is, not guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL IBM BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
/**
 * This is the base class for specific tests.
 * Extend it to create your own tests.
 */
public abstract class Test {

  public Test() {    
  }

  /**
   * Implement this method to do the work in
   * your own test.
   */
  abstract public void runTest();

  /**
   * Implement this method return the
   * name of your own test.
   */
  abstract public String getName();

  /**
   * Override this method to add your own results.
   * call super.displayResults to reuse this default.
   */
  public void displayResults() {

    Butil.textOut("The score for the "+ getName() + 
                       " test was " + getScore());
    PerfMonitor.printThenClearStats();
  }

  /**
   * Override this method to calculate your own score.
   * call super.getScore to reuse this default.
   */
  public long getScore() {
    // make sure all monitors have been processed
    PerfMonitor.processMonitors();
    // return the accumulated time as the raw score
    return PerfMonitor.getTotalTime();
  }
}
