// This source is an example application.
// IBM grants you a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided by IBM for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// IBM, therefore, cannot guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL IBM BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
// 5648 - BP1
// (C) Copyright IBM Corp. 1998
// All rights reserved.
// US Government Users Restricted Rights -
// Use, duplication, or disclosure restricted
// by GSA ADP Schedule Contract with IBM Corp.
//
// Licensed Materials - Property of IBM
import infra.Base;
import infra.Entity;
import infra.Location;
import infra.Factory.ExpandingContainer;
import infra.Factory.Container;
import infra.Factory.Factory;

import java.util.*;

public
class Company extends Entity {
  public static final int warehouseCapacity = 512;

  private static Class classRef;
  private static Location near = Location.createNear();

  static
  {
    try {
      classRef = Class.forName("Company");
    } catch (ClassNotFoundException e) {
      Butil.textOut("Company Static Init - " 
                    + "ClassNotFoundException");
    }
  }

  private Object[] warehouseTable;
  private Map      customerTable;
  private TreeMap  lastNameCustomerTable;
  private Map      itemTable;
  private Map      historyTable;
  private Object[] warehouseContainers;
  private long     historyCount;

  // population variables:
  private short maxWarehouses; // no min or max in spec
  private short maxDistricts;// should be 10
  private int maxCustomers;// should be 3,000
  private int maxItems;     // should be 100,000
  private int maxStock;     // should be 100,000
  private int initialOrders;    // should be 3,000
  private int initialNewOrders; // should be 900
  private int initialHistories; // should be 3,000
  private SynchronizationPoint synchronizationPoint;

  public static Company createCompany(Base nearobj) {
    Company newCompany = null;
    newCompany = (Company)Factory.createEntity(classRef, 
                                               nearobj, 
                                               near);
    return newCompany;
  }

  public static Company createCompany(Base ownobj, 
                                      Base nearobj, 
                                      Location loc) {
    Company newCompany = null;
    newCompany = (Company)Factory.createEntity(classRef, 
                                               nearobj, 
                                               loc);
    return newCompany;
  }

  public SynchronizationPoint getSynchronizationPoint() {
    return synchronizationPoint;
  }

  public void destroy() {
    int i;

    // delete all customers & remove them from the customerTable
    Iterator customerIter = customerTable.values().iterator();
    long uniqueCustomerId;
    Customer customer;

    while (customerIter.hasNext()) {
      customer = (Customer)customerIter.next();
      customerIter.remove();
      Factory.deleteEntity(customer);
    }
    customerTable = null;

    // delete all items & remove them from the itemTable
    Iterator itemIter = itemTable.values().iterator();
    Item item;
    while (itemIter.hasNext()) {
      item = (Item)itemIter.next();
      itemIter.remove();
      Factory.deleteEntity(item);
    }
    itemTable = null;

    // delete all history records & remove them from the historyTable
    Iterator historyIter = historyTable.values().iterator();
    History history;
    long histId;
    while (historyIter.hasNext()) {
      history  = (History)historyIter.next();
      historyIter.remove();
      Factory.deleteEntity(history);
    }
    historyTable = null;

    // delete all warehouses & remove them 
    // from the warehouseTable
    for (i=1; i<=maxWarehouses; i++) {
      Container tempWhCont = (Container)warehouseContainers[i];
      Warehouse tempWh     = (Warehouse)warehouseTable[i];
      Factory.deleteEntity(tempWh);
    }
    Factory.destroyPermInstance(warehouseTable);
    Factory.destroyPermInstance(warehouseContainers);
    warehouseTable = null;
    warehouseContainers = null;

    super.destroy();
  }

  public Company() {
    Butil.random_init();
    Butil.textOut("Building the company now Hang....on\n");

    warehouseContainers = new Object[warehouseCapacity];
    warehouseTable = new Object[warehouseCapacity];
    customerTable = 
       Collections.synchronizedMap(new TreeMap());
    lastNameCustomerTable = new TreeMap();
    itemTable = Collections.synchronizedMap(new TreeMap());
    historyTable = 
       Collections.synchronizedMap(new TreeMap());
    historyCount = 0;
    maxWarehouses = 0;
  }

  public short getMaxWarehouses() {
    return maxWarehouses;
  }

  public short getMaxDistricts() {
    return maxDistricts;
  }

  public int getMaxCustomers() {
    return maxCustomers;
  }

  public int getMaxItems() {
    return maxItems;
  }

  public int getInitialOrders() {
    return initialOrders;
  }

  public int getInitialNewOrders() {
    return initialNewOrders;
  }

  public synchronized void primeWithDummyData() {

    // 4.2.1  - varied for throughput (no min/max)
    maxWarehouses = SetValues.getNumberOfWarehouses();

    reset();

    Butil.textOut("Number of Warehouses = " + 
                       maxWarehouses);
    Butil.textOut("Number of Terminals per warehouse = " + 
                       SetValues.getNumberOfTerminals());

    // Item Table must be loaded first--
    // the warehouses use it
    // 4.3.3.1 bullet 1
    loadItemTable();  

    // 4.3.3.1 bullet 2
    loadWarehouseTable(); 

    // 4.3.3.1 bullet 2, sub-bullet 2, point 1
    loadCustomerTable();  

    // 4.3.3.1 bullet 2, sub-bullet 2, point 1, sub-point 1
    loadHistoryTable(); 

    // 4.3.3.1 bullet 2, sub-bullet 2, points 2 & 3
    loadinitialOrders();
  }

  public synchronized void reset() {
   synchronizationPoint = 
   new SynchronizationPoint(SetValues.getNumberOfTerminals()
                            * maxWarehouses);
  }

  public Warehouse getWarehouse(byte warehouseId) {
    Warehouse result;
    result = (Warehouse)warehouseTable[warehouseId];
    return result;
  }

  public Customer getCustomer(long customerId) {
    Customer result;
    result = (Customer) 
      customerTable.get(new Long(customerId));
    return result;
  }

  public boolean isCustomer(long customerId) {
    return customerTable.containsKey(new Long(customerId));
  }

  public long buildUniqueCustomerKey(byte warehouseId,
                                     byte districtId,
                                     short customerId) {
    // warehouseId=1:12, districtId=13:24, customerId=25-64
    long key = warehouseId;
    key = key << 12;
    key += districtId;
    key = key << 40;
    key += customerId;
    return key;
  }

  public synchronized Customer 
     getCustomerByLastName(byte warehouseId,
                           byte districtId,
                           String last_name) {
    String first_name_key;
    //  Hashtable tempCustomerTable = new Hashtable();
    String last_name_limit;
    byte tempWarehouseId;
    byte tempDistrictId;

    // 2.5.2.2 bullet 5 case 2  &  2.6.2.2 bullet 1 case 2
    Customer goodCustomer = null;
    String custKey = Integer.toString((int)warehouseId) 
                     + "_"
                     + Integer.toString((int)districtId) 
                     + "_"
                     + last_name;
    last_name_limit = custKey + "_~";

    Iterator custIter = lastNameCustomerTable.
      subMap(custKey, last_name_limit).values().iterator();
    Customer tempCustomer = null;

    int matching_entries = 0;
    while (custIter.hasNext()) {
      tempCustomer = (Customer)custIter.next();
      // since warehouse and district are already 
      // included in the key we don't have to check again!
      // Instead we just count the entries.
      matching_entries++;
    }

    if (matching_entries > 0) { // so iterate over the same names, only half as far!
      custIter = lastNameCustomerTable.
       subMap(custKey, last_name_limit).values().iterator();

      for (int i = 1; i <= (matching_entries+1)/2; i++) {
        tempCustomer = (Customer)custIter.next();
      }
    }
    return tempCustomer;
  }

  public synchronized void updateHistory(History inHistory) {
    historyCount++;
    historyTable.put(new Long(historyCount), inHistory);
  }

  public synchronized void setPopulationValues(int percent) {
    if (percent > 0) {
      // populate tables as percent of full values in spec:
      Butil.textOut("     (using "
                         + Integer.toString(percent)
                         + "% population)");
      maxDistricts = 10;  // 4.2.2.2
      maxCustomers = 
         (3000 * percent) / 100;  // 4.2.2.2
      maxItems = (100000 * percent) / 100;     // 4.2.2.2
    } else {
      // minimally populated tables
      Butil.textOut("     (using minimal population)");
      maxDistricts = 5; // spec says 10
      maxCustomers = 30; // spec says 3,000
      maxItems = 100;     // spec says 100,000
    }
    maxStock = maxItems;
    initialOrders = maxCustomers;
    initialNewOrders = (short)(maxCustomers 
                               * 0.30);
    initialHistories = maxCustomers;
  }

  public synchronized void loadWarehouseTable() {
    for (byte i = 1; i <= maxWarehouses; ++i) {
      Container whContainer = 
         ExpandingContainer.createExpandingContainer();
      whContainer.setContainerName("Warehouse_" 
                                   + Integer.toString(i));
      // add container to the list of warehouse containers
      warehouseContainers[i] = whContainer;
      Warehouse newWarehouse = 
         Warehouse.createWarehouse(whContainer, 
                                   this, itemTable);
      newWarehouse.setUsingRandom(i);
      warehouseTable[i] = newWarehouse;
    }
  }

  public synchronized void loadCustomerTable() {
    short cID;
    long customers_loaded = 0;
    // go through all of the warehouses
    for (byte whID = 1; whID <= maxWarehouses; ++whID) {
      // go through all districts
      for (byte dID = 1; dID <= maxDistricts; ++dID) {
        // create customers for each district
        for (cID = 1; cID <= maxCustomers; ++cID) {
          Customer newCustomer = 
             Customer.createCustomer(this);
          newCustomer.setUsingRandom(cID, whID, dID);

          long uniqueCustomerNumber = 
             buildUniqueCustomerKey(whID, dID, cID);
          customerTable.put(new Long(uniqueCustomerNumber),
                            newCustomer);

          String custNameKey = Integer.toString((int)whID) 
                 + "_"
                 + Integer.toString((int)dID) + "_"
                 + newCustomer.getLastName() + "_"
                 + Integer.toString((int)cID); 
          
          lastNameCustomerTable.put(custNameKey, 
                                    newCustomer);
        }
        customers_loaded += cID - 1;
      }
    }
  }

  public synchronized void loadItemTable() {
    for (int i = 1; i <= maxItems; ++i) {
      Item anItem = Item.createItem(this);
      anItem.setUsingRandom(i);
      itemTable.put(new Integer(i), anItem);
    }
  }

  public synchronized void loadHistoryTable() {
    String historyData;
    // go through all of the warehouses
    for (byte whID = 1; whID <= maxWarehouses; ++whID) {
      // go through all of the districts for each warehouse
      for (byte dID = 1; dID <= maxDistricts; ++dID) {
        // all of the customers for each district
        for (short cID = 1; cID <= maxCustomers; ++cID) {
          long customerKey = 
             buildUniqueCustomerKey(whID, dID, cID);
          // get customer
          Customer customer = getCustomer(customerKey);
          float amount = 10.00f;
          historyData = Butil.create_random_a_string(12,25);
          Date creation_time = 
             (Date)Factory.newInstanceNear("java.util.Date",
                                            this);

          History newHistory = History.createHistory (this,
                                cID,
                                customer.getDistrictId(),
                                customer.getWarehouseId(),
                                dID,
                                whID,
                                creation_time,
                                amount,
                                historyData);
          updateHistory(newHistory);
        } // for cust
      } // for districts
    } // for warehouse
  }

  public synchronized void loadinitialOrders() {
    // go through all of the warehouses
    for (byte whID = 1; whID <= maxWarehouses; ++whID) {
      NewOrderTransaction newOrderTransaction = 
         new NewOrderTransaction(this, whID);
      // go through all of the districts for each warehouse
      for (byte dID = 1; dID <= maxDistricts; ++dID) {
        // go through all of the customers for each district
        for (short cID = 1; cID <= maxCustomers; ++cID) {
          newOrderTransaction.init();
          newOrderTransaction.setDistrictandCustomer(dID, 
                                                     cID);
          newOrderTransaction.processPreloadedOrders();
        } // for customer
      } // for district
    } // for warehouse
  }

  public void waitForMeasurements() {

    // display rampup start time
    Butil.textOut("	Terminal Rampup began " 
                  + new Date().toString() + " for " 
                  + SetValues.getRampupTime()/60. 
                  + " minutes");  

    // Wait for terminals to ramp up
    while (synchronizationPoint.allStarted() == false)
      Butil.SecondsToSleep(1);

   // display start time
    Butil.SecondsToSleep(SetValues.getRampupTime());
    Butil.textOut("	Timing Measurement began " 
                  + new Date().toString() + " for " 
                  +  SetValues.getMeasurementTime()/60. 
                  + " minutes"); 

    // Wait while terminals do the recorded run
    Butil.SecondsToSleep(SetValues.getMeasurementTime());
    
    while (synchronizationPoint.allDone() == false)
      Butil.SecondsToSleep(1);

    // display stop time
    Butil.textOut("	Timing Measurement ended " 
                  + new Date().toString());  
  }

  public synchronized java.util.Vector getRecorders() {
     return synchronizationPoint.getRecorders();
  }
}
