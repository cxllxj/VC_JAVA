// This source is an example application.
// IBM grants you a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided by IBM for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// IBM, therefore, cannot guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL IBM BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
// 5648 - BP1
// (C) Copyright IBM Corp. 1998
// All rights reserved.
// US Government Users Restricted Rights -
// Use, duplication, or disclosure restricted
// by GSA ADP Schedule Contract with IBM Corp.
//
// Licensed Materials - Property of IBM
import java.util.*;
import java.io.PrintStream;
import infra.Util.DisplayScreen;
import infra.Factory.Factory;
import infra.Base;
import infra.Entity;
import infra.Location;

class DeliveryTransaction extends CommonTransaction {
  private static final long WAITTIMESTYPING = 2;
  private static final long WAITTIMESTHINKING = 5;

  private Company   company;
  private byte      warehouseId;
  private short     carrierId;
  private DeliveryHandler deliveryHandler;
  private Warehouse   warehouse;
  private long      deliveryTime;

  private DisplayScreen backScreen;
  private DisplayScreen initScreen;
  private DisplayScreen deliveryScreen;
  private DisplayScreen queuedScreen;

  public DeliveryTransaction(Company aCompany,
                             byte aWarehouse) {
    super(WAITTIMESTYPING, WAITTIMESTHINKING);
    company = aCompany;
    warehouseId = aWarehouse; // 2.7.1.1
    warehouse = company.getWarehouse(warehouseId);
    deliveryHandler = new DeliveryHandler();

    // 2.7.3.1
    backScreen = new DisplayScreen();
    backScreen.putText("Delivery", 37, 0, 8);
    backScreen.putText("Warehouse:", 0, 1, 10);
    backScreen.putInt (warehouseId, 11, 1, 4);
    backScreen.putText("Carrier Number:", 0, 3, 15);
    backScreen.putText("Execution Status:",  0, 5,17);

    initScreen = new DisplayScreen(backScreen);
    // initScreen.putInt (warehouseId, 11, 1, 4);
    initScreen.putCharFill('9', 16, 3, 2);
    initScreen.putCharFill('X', 18, 5, 25);

    deliveryScreen = new DisplayScreen();
    queuedScreen = new DisplayScreen(16, 64);
  }

  public void destroy() {
    
  }

  public void init() {
    carrierId = (short)Butil.random(1,10);  // 2.7.1.2
  }

  public void process() {

    //place warehouse ID in output stream
    // (2.7.2.2 4 2nd bullet)
    queuedScreen.putText("Warehouse:", 0, 1, 10);
    queuedScreen.putInt (warehouseId, 11, 1, 4);

    //place carrier ID in output stream 
    // (2.7.2.2 4 2nd bullet)
    queuedScreen.putText("Carrier ID:", 16, 1, 12);
    queuedScreen.putInt (carrierId, 28, 1, 2);


    // place header for order info in output stream
    queuedScreen.putText("Items Delivered", 0, 2, 15);
    queuedScreen.putText("District            Order",
                         0, 3, 25);

    int distCount = warehouse.getDistrictCount();
    int distId;

    // iterate over the district list of the given warehouse
    District district;
    for (distId = 1; distId <= distCount; distId++) {
      district = warehouse.getDistrict(distId);;

      // remove currentNewOrder from District 
      NewOrder currentNewOrder = 
         district.removeFirstNewOrder(); // 2.7.4.2 bullet 3
      if (currentNewOrder != null) {
        // 2.7.4.2 bullet 5
        Order matchingOrder = currentNewOrder.getOrder();
        // 2.7.4.2 bullet 4
        Factory.deleteEntity(currentNewOrder);

        // get matchingOrder 2.7.4.2 bullet 5
        matchingOrder.setCarrierId(carrierId);  
        matchingOrder.dateOrderlines(); // 2.7.4.2 bullet 6

        // place district and order IDs in output stream 
        // for each order delivered (2.7.2.2 4 3rd bullet)
        queuedScreen.putInt(district.getId(), 6,distId+3,2);
        queuedScreen.putInt(district.getId(),20,distId+3,5);

        // get customer  with a write lock
        Customer customer = matchingOrder.getCustomer();  // 2.7.4.2 bullet 5

        //2.7.4.2 bullet 7
        customer.adjustBalance(matchingOrder.getTotalAmount());
        customer.incrementDeliveryCount();
      } // if
    } // if

    // place finish time in output stream (2.7.2.2 4 4th bullet)
    Date dayTime = new Date();
    queuedScreen.putText("Processing finished at:", 0, 14, 23);
    queuedScreen.putDate(dayTime, 24, 14, 10);
    queuedScreen.putTime(dayTime, 36, 14, 10);
  }

  public synchronized void display(PrintStream out) {
    synchronized(out) {
      if (SetValues.getScreenWrite())
        queuedScreen.display(out);
    }
  }

  public void initialDisplay() {
    if (SetValues.getScreenWrite())
      initScreen.display();
  }

  public synchronized void secondDisplay() {
    deliveryScreen.copyScreen(backScreen);
    deliveryScreen.putInt(carrierId, 16, 3, 2);
    deliveryScreen.putText("Delivery has been queued", 18, 5, 25);

    if (SetValues.getScreenWrite())
      deliveryScreen.display();
  }

  public synchronized void perform() {
    Date dayTime = new Date();
    TransactionTimer myTimer = getTimer();
    myTimer.startTiming(null);

    //place queuing time in output stream (2.7.2.2 4 1st bullet)
    queuedScreen.clearScreen();
    queuedScreen.putText("Queing Time:", 0, 0, 12);
    queuedScreen.putDate(dayTime, 12, 0, 10);
    queuedScreen.putTime(dayTime, 24, 0, 10);

    // place in deliveryHandler's queue
    deliveryHandler.handleDelivery(this);
    myTimer.stopTiming(null);
  }
}
