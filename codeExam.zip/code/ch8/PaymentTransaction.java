// This source is an example application.
// IBM grants you a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided by IBM for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// IBM, therefore, cannot guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL IBM BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
// 5648 - BP1
// (C) Copyright IBM Corp. 1998
// All rights reserved.
// US Government Users Restricted Rights -
// Use, duplication, or disclosure restricted
// by GSA ADP Schedule Contract with IBM Corp.
//
// Licensed Materials - Property of IBM
import infra.Factory.Factory;
import infra.Base;
import infra.Entity;
import infra.Location;
import infra.Util.DisplayScreen;
import java.util.Date;

class PaymentTransaction extends CommonTransaction {
  private static final long WAITTIMESTYPING = 3;
  private static final long WAITTIMESTHINKING = 12;
  private Company company;
  private byte    warehouseId;  // W_ID
  private byte    districtId; // D_ID
  private boolean home;

  private char    use_customerId;
  private String  cust_last_name;
  private short   customerId;
  private byte    customerWarehouseId;  // C_W_ID
  private byte    customerDistrictId; // C_D_ID
  private float   paymentAmount;
  private Date    paymentTime;

  private Warehouse warehouse;
  private District  district;
  private Customer  customer;

  private DisplayScreen backScreen;
  private DisplayScreen initScreen;
  private DisplayScreen paymentScreen;

  public
  PaymentTransaction(Company inCompany,
                     byte inWarehouseId) { // 2.5.1.1 
    super(WAITTIMESTYPING, WAITTIMESTHINKING);

    company = inCompany;
    warehouseId = inWarehouseId;
    warehouse = company.getWarehouse(warehouseId);// 2.5.2.2 bullet 3

    backScreen = new DisplayScreen();
    backScreen.putText("Payment", 37, 0, 7);
    backScreen.putText("Date:", 0, 1, 5);
    backScreen.putText("Warehouse:", 0, 3, 10);
    backScreen.putText("District:", 41, 3, 9);
    backScreen.putText("Customer:", 0, 8, 9);
    backScreen.putText("Cust-Warehouse:", 16, 8, 15);
    backScreen.putText("Cust-District:", 38, 8, 14);
    backScreen.putText("Name:", 0, 9, 5);
    backScreen.putText("Since:", 49, 9, 6);
    backScreen.putText("Credit:", 49, 10, 7);
    backScreen.putText("%Disc:", 49, 11, 6);
    backScreen.putText("Phone:", 49, 12, 6);
    backScreen.putText("Amount Paid:", 0, 14, 11);
    backScreen.putText("New Cust-Balance:", 36, 14, 17);
    backScreen.putText("Credit Limit:", 0, 15, 12);
    backScreen.putText("Cust-Data:", 0, 17, 10);

    initScreen = new DisplayScreen(backScreen);
    initScreen.putText("DD-MM-YYYY", 6, 1, 10);
    initScreen.putText("hh:mm:ss", 17, 1, 8);
    initScreen.putCharFill('9', 11, 3, 4);
    initScreen.putCharFill('9', 51, 3, 2);
    initScreen.putCharFill('X', 0, 4, 20);
    initScreen.putCharFill('X', 41, 4, 20);
    initScreen.putCharFill('X', 0, 5, 20);
    initScreen.putCharFill('X', 41, 5, 20);
    initScreen.putCharFill('X', 0, 6, 20);
    initScreen.putCharFill('X', 21, 6, 2);
    initScreen.putText("XXXXX-XXXX", 24, 6, 10);
    initScreen.putCharFill('X', 41, 6, 20);
    initScreen.putCharFill('X', 62, 6, 2);
    initScreen.putText("XXXXX-XXXX", 65, 6, 10);
    initScreen.putCharFill('9', 10, 8, 4);
    initScreen.putCharFill('9', 32, 8, 4);
    initScreen.putCharFill('9', 53, 8, 2);
    initScreen.putCharFill('X',  8, 9, 16);
    initScreen.putCharFill('X', 25, 9, 2);
    initScreen.putCharFill('X', 28, 9, 16);
    initScreen.putText("DD-MM-YYYY", 57, 9, 10);
    initScreen.putCharFill('X',  8, 10, 20);
    initScreen.putCharFill('X', 57, 10, 2);
    initScreen.putCharFill('X',  8, 11, 20);
    initScreen.putText("99.99", 57, 11, 5);
    initScreen.putCharFill('X',  8, 12, 20);
    initScreen.putCharFill('X', 29, 12, 2);
    initScreen.putText("XXXXX-XXXX", 32, 12, 10);
    initScreen.putText("XXXXXX-XXX-XXX-XXXX", 57, 12, 19);
    initScreen.putText("$9999.99", 17, 14, 8);
    initScreen.putText("$-99999.99", 54, 14, 10);
    initScreen.putText("$99999.99", 16, 15, 9);
    initScreen.putCharFill('X', 11, 17, 50);
    initScreen.putCharFill('X', 11, 18, 50);
    initScreen.putCharFill('X', 11, 19, 50);
    initScreen.putCharFill('X', 11, 20, 50);

    paymentScreen = new DisplayScreen();
  }

  public synchronized void delete() {
  }

  public synchronized void init() {
    districtId = (byte)
    Butil.random(1, company.getMaxDistricts()); // 2.5.1.2
    //2.5.2.2 bullet 4
    district = warehouse.getDistrict(districtId);

    int x = (int)Butil.random(1,100);
    int y = (int)Butil.random(1,100);

    if (y <= 60) {
      // 2.5.1.2 bullet three
      // Customer will pay using last name, not customer Id
      cust_last_name = Butil.create_random_last_name(0);
      use_customerId = 'F';
    } else {
      // 2.5.1.2 bullet four
      // Customer will pay using CustomerId
      customerId = (short)
      Butil.NUrand_val(Butil.A_C_ID, 1, 
                       company.getMaxCustomers(),
                       Butil.C_C_ID );
      use_customerId = 'T';
    }

    if (x <= 85) {
      // 2.5.1.2 bullet one
      customerDistrictId = districtId;
      customerWarehouseId = warehouseId;
    } else {
      // 2.5.1.2 bullet two
      customerDistrictId = (byte)
      Butil.random(1,company.getMaxDistricts());
      for (customerWarehouseId = (byte)
           Butil.random(1,company.getMaxWarehouses());
          customerWarehouseId != warehouseId;
          customerWarehouseId = (byte)
          Butil.random(1,company.getMaxWarehouses()))
        ;
    }

    paymentAmount = 
       Butil.create_random_float_val_return(1.00f, 
                                            5000.00f,0.01f); // 2.5.1.3
    paymentTime = new Date(); // 2.5.1.4
    home = (customerWarehouseId == warehouseId);
  }


  public void process() {
    warehouse.receivePayment(paymentAmount);
    String warehousename = warehouse.getName();

    district.receivePayment(paymentAmount);

    switch (use_customerId) {
    case 'T':
      {
        // 2.5.2.2 bullet 5
        long uniqueCustomerId =
        company.buildUniqueCustomerKey(customerWarehouseId,
                                       customerDistrictId,
                                       customerId);
        // get customer  with write lock
        customer = company.getCustomer(uniqueCustomerId);
      }
      break;
    case 'F':
      // get customer  with write lock
      customer = company.getCustomerByLastName(warehouseId,
                                            districtId,
                                            cust_last_name);
    } // switch

    if (customer != null) {
      customer.adjustBalance(-paymentAmount);
      customer.increaseYTD(paymentAmount);
      customer.incrementPaymentCount();

      // 2.5.2.2 bullet 6
      if (customer.getCreditStatus() == "BC") {
        String newData = " " + customer.getId() + " " 
           + customer.getDistrictId() + " " 
           + customer.getWarehouseId() + " " 
           + districtId + " " + warehouseId + " " 
           + paymentAmount + " ";
        customer.updateCustomerData(newData);
      }

      Date histdate = new java.util.Date();
      History hist = History.createHistory(warehouse,
                                  customer.getId(),
                                  customer.getDistrictId(),
                                  customer.getWarehouseId(),
                                  districtId,
                                  warehouseId,
                                  histdate,
                                  0.0f,
                                  null);

      // 2.5.2.2 bullet 7
      hist.buildData(warehousename,
                     district.getName());

      // 2.5.2.2 bullet 8
      company.updateHistory(hist);
    }
  }

  public synchronized void initialDisplay() {
    Date date = new Date();
    // 2.5.3.1
    if (SetValues.getScreenWrite())
      initScreen.display();
  }

  public synchronized void secondDisplay() {
    paymentScreen.copyScreen(backScreen);
    Date screenDate = new Date();
    Address ware_addr = warehouse.getAddress();
    Address dist_addr = district.getAddress();
    String phone;
    String zip;

    // 2.5.3.3
    paymentScreen.putDate(screenDate, 6, 1, 10);
    paymentScreen.putTime(screenDate, 17, 1, 8);
    paymentScreen.putInt(warehouseId, 11, 3, 4);
    paymentScreen.putInt(districtId, 51, 3, 2);
    paymentScreen.putText(ware_addr.getStreet1(), 0, 4, 20);
    paymentScreen.putText(dist_addr.getStreet1(), 41, 4,20);
    paymentScreen.putText(ware_addr.getStreet2(), 0, 5, 20);
    paymentScreen.putText(dist_addr.getStreet2(), 41, 5,20);
    paymentScreen.putText(ware_addr.getCity(), 0, 6, 20);
    paymentScreen.putText(ware_addr.getState(), 21, 6, 2);
    zip = ware_addr.getZip();
    paymentScreen.putSubstring(zip, 24, 6, 0, 5);
    paymentScreen.putChar('-', 29, 6);
    paymentScreen.putSubstring(zip, 30, 6, 5, 4);
    paymentScreen.putText(dist_addr.getCity(), 41, 6, 20);
    paymentScreen.putText(dist_addr.getState(), 62, 6, 2);
    zip = dist_addr.getZip();
    paymentScreen.putSubstring(zip, 65, 6, 0, 5);
    paymentScreen.putChar('-', 70, 6);
    paymentScreen.putSubstring(zip, 71, 6, 5, 4);
    if (customer != null) {
      Address cust_addr = customer.getAddress();
      Date custDate = customer.getSince();
      paymentScreen.putInt(customer.getId(), 10, 8, 4);
      paymentScreen.putInt(customer.getWarehouseId(),32,8,4);
      paymentScreen.putInt(customer.getDistrictId(),53,8,2);
      paymentScreen.putText(customer.getFirstName(),8,9,16);
      paymentScreen.putText(customer.getMiddleName(), 25, 9, 2);
      paymentScreen.putText(customer.getLastName(),28,9,16);
      paymentScreen.putDate(custDate, 57, 9, 10);
      paymentScreen.putText(cust_addr.getStreet1(),8,10,20);
      paymentScreen.putText(customer.getCreditStatus(),
                            57,10, 2);
      paymentScreen.putText(cust_addr.getStreet2(),8,11,20);
      paymentScreen.putDouble((customer.getDiscountRate()
                               *100.0), 57, 11, 5);
      paymentScreen.putText(cust_addr.getCity(),  8, 12, 20);
      paymentScreen.putText(cust_addr.getState(), 29, 12, 2);
      zip = cust_addr.getZip();
      phone = customer.getPhone();
      paymentScreen.putSubstring(zip, 32, 12, 0, 5);
      paymentScreen.putChar('-', 37, 12);
      paymentScreen.putSubstring(zip, 38, 12, 5, 4);
      paymentScreen.putSubstring(phone, 57, 12, 0, 6);
      paymentScreen.putChar('-', 63, 12);
      paymentScreen.putSubstring(phone, 64, 12, 6, 3);
      paymentScreen.putChar('-', 67, 12);
      paymentScreen.putSubstring(phone, 68, 12, 9, 3);
      paymentScreen.putChar('-', 71, 12);
      paymentScreen.putSubstring(phone, 72, 12, 12, 4);
      paymentScreen.putDollars(paymentAmount, 17, 14, 8);
      paymentScreen.putDollars(customer.getBalance(), 
                               54, 14, 10);
      paymentScreen.putDollars(customer.getCreditLimit(), 
                               16, 15, 9);

      if (customer.getCreditStatus().equals("BC")) {
        String custData = customer.getCustomerDataParts();
        paymentScreen.putSubstring(custData, 11, 17, 0, 50);
        paymentScreen.putSubstring(custData,11,18, 50, 50);
        paymentScreen.putSubstring(custData,11,19, 100, 50);
        paymentScreen.putSubstring(custData,11,20, 150, 50);
      }
    } else {
      paymentScreen.putText("No customer found, "
                            + "last name =", 11, 17, 35);
      paymentScreen.putText(cust_last_name, 46, 17, 16);
      paymentScreen.putText("District :", 11, 18, 10);
      paymentScreen.putInt (districtId, 22, 18, 2);
      paymentScreen.putText("Warehouse:", 11, 19, 10);
      paymentScreen.putInt (warehouseId, 22, 19, 4);
      paymentScreen.putText("No payment processed.",
                            11,20,25);
    }

    if (SetValues.getScreenWrite())
      paymentScreen.display();
  }
}
