// This source is an example application.
// IBM grants you a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided by IBM for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// IBM, therefore, cannot guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL IBM BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
// 5648 - BP1
// (C) Copyright IBM Corp. 1998
// All rights reserved.
// US Government Users Restricted Rights -
// Use, duplication, or disclosure restricted
// by GSA ADP Schedule Contract with IBM Corp.
//
// Licensed Materials - Property of IBM
/**
 * This is the base class for specific tests.
 * Extend it to create your own tests.
 */
public class CompanyRunnable implements Runnable {
  private byte whId;
  private Company theCompany;
  
  public CompanyRunnable(byte whIdIn, Company companyIn) {
    whId = whIdIn;
    theCompany = companyIn;
  }

  public void run() {
    TransactionManager transMgr = null;
    short maxwh = theCompany.getMaxWarehouses();

    Butil.SecondsToSleep((10*maxwh)+5);
    
    if ((whId > 0) && (whId <= maxwh)) {
      transMgr = new TransactionManager(theCompany, whId);
      transMgr.go();
    } else {
      Butil.textOut("");
      Butil.textOut("Invalid Warehouse passed in. "
                    + "Value was " + whId 
                    + " and should be between 1 and " 
                    + maxwh);
      Butil.SecondsToSleep(15);
    }
  }

  public void start() {}
  public void stop() {}
}

