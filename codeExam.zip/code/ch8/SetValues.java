
/**
 * This is the base class for specific set up
 * actions. Extend it to create your own set up
 * actions.
 */
public class SetValues extends Setup {

  private final static String NAME = "Set test parameters";
  public static final int threadLimit = 1024;

  private static byte numberOfWarehouses = 1;
  private static short numberOfTerminals = 1;
  private static boolean useWaits = false;
  private static boolean screenWrite = false;
  private static boolean testType = true;
  // timing variables:
  private static long rampupTime = 120;
  private static long measurementTime = 120;

  public static byte getNumberOfWarehouses() {
    return numberOfWarehouses;
  }

  public static short getNumberOfTerminals() {
    return numberOfTerminals;
  }

  public static boolean getUseWaits() {
    return useWaits;
  }

  public static boolean getScreenWrite() {
    return screenWrite;
  }

  public static boolean getTestType() {
    return testType;
  }

  public static long getRampupTime() {
    return rampupTime;
  }

  public static long getMeasurementTime() {
    return measurementTime;
  }

  public SetValues() {
    
  }

  /**
   * Implement this method to do the work in
   * your own set up.
   */
  public void runSetup() {

    short selection = Butil.NON_NUMERIC_ENTRY;

    while (selection == Butil.NON_NUMERIC_ENTRY) {

      Butil.textOut("");
      Butil.textOut("1. Toggle wait times in testing");
      Butil.textOut("2. Toggle displaying the screens");
      Butil.textOut("3. Toggle minimal/full test");
      Butil.textOut("4. Set total number of warehouses");
      Butil.textOut("5. Set number of terminals/warehouse");
      Butil.textOut("6. Exit.");
      Butil.textOut("Enter selection here: ");

      selection = (short)Butil.getNumericInput();

      if ((selection < 1) || (selection > 5)) {
        selection = Butil.NON_NUMERIC_ENTRY;
      }

      switch (selection) {
      case Butil.NON_NUMERIC_ENTRY: { break;}

      case 1: // Toggle wait times in testing
        {
          useWaits = !useWaits;

          if (useWaits) {
            Butil.textOut(" Wait Times Enabled");
          } else {
            Butil.textOut(" Wait Times Disabled");
          }
          break;
        }

      case 2: // Toggle displaying the screens
        {
          screenWrite = !screenWrite;
          if (screenWrite) {
            Butil.textOut(" Screen Write Enabled");
          } else {
            Butil.textOut(" Screen Write Disabled");
          }
          break;
        }

      case 3: // Toggle minimal/full test
        {
          testType = !testType;
          if (testType) {
            Butil.textOut(" A minimal test will run.");
            measurementTime = 120; // 2 minutes
            rampupTime = 120;  // 2 minutes
          } else {
            Butil.textOut(" A full test will run.");
            measurementTime = 20 * 60; // 20 minutes
            rampupTime = 20 * 60; // 20 minutes
          }
          break;
        }

      case 4: // Set total number of warehouses
        {
          Butil.textOut("Enter number of warehouses:");

          numberOfWarehouses = (byte)
                               Butil.getNumericInput();

          if ((numberOfWarehouses == 
               Butil.NON_NUMERIC_ENTRY) ||
              numberOfWarehouses < 1 ||
              numberOfWarehouses > Company.warehouseCapacity) {
            Butil.textOut("Must be number between 1 and " 
                          + Company.warehouseCapacity
                          + ", (setting to 1)");
            numberOfWarehouses = 1;
          }

          Butil.textOut("numberOfWarehouses = " + 
                        String.valueOf(numberOfWarehouses));
          break;
        }

      case 5: // Set number of terminals
        {
          Butil.textOut("Enter number of terminals:");

          numberOfTerminals = (short)
                              Butil.getNumericInput();

          if (numberOfTerminals == Butil.NON_NUMERIC_ENTRY
              || numberOfTerminals < 1 ||
              numberOfTerminals > threadLimit) {
            Butil.textOut("Must be number between 1 and " + 
                          threadLimit + " (setting to 1)");
            numberOfTerminals = 1;
          }
          Butil.textOut("numberOfTerminals = " + 
                        String.valueOf(numberOfTerminals));
        }

      case 6:
        {
          return;
        }
      }
    }
  }

  /**
   * Implement this method return the
   * name of your own test.
   */
  public String getName() {
    return NAME;
  }
}


