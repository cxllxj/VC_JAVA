// This source is an example application.
// IBM grants you a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided by IBM for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// IBM, therefore, cannot guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL IBM BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
// 5648 - BP1
// (C) Copyright IBM Corp. 1998
// All rights reserved.
// US Government Users Restricted Rights -
// Use, duplication, or disclosure restricted
// by GSA ADP Schedule Contract with IBM Corp.
//
// Licensed Materials - Property of IBM
import java.util.Random;
import java.io.*;

class Butil {
  private static final String originalText = "ORIGINAL";
  private static Random r = new Random();
  private static final String last_name_parts[] =
  {
    "BAR",
    "OUGHT",
    "ABLE",
    "PRI",
    "PRES",
    "ESE",
    "ANTI",
    "CALLY",
    "ATION",
    "EING"
  };

  private static final char alnum[] =
     ("0123456789abcdefghijklmnopqrstuvwxyz"
     + "ABCDEFGHIJKLMNOPQRSTUVWXYZ").toCharArray();

  public static final short A_C_LAST  =  255; 
  public static final short C_C_LAST  =  173; 
  public static final short A_C_ID    =  102; 
  public static final short C_C_ID    =   34; 
  public static final short A_OL_I_ID = 8191; 
  public static final short C_OL_I_ID = 5456; 

  public static final byte MaxOrderLines = 15;
  public static final byte NON_NUMERIC_ENTRY = -99;

  public static void random_init() {
    r = new Random();
    r.setSeed(System.currentTimeMillis());
  }

  public static int random(int low,
                           int high) {
    return ((r.nextInt() & 0x7fffffff) % (high-low+1)) 
            + low;
  }

  // creates a random string of alphanumeric characters
  public static String create_random_a_string(int lo,
                                               int hi) {
    int actual_length = random(lo, hi);
    char [] temp = new char[actual_length];

    for (int i=0;i<actual_length;i++) {
      int aRandInt = random(0,61);
      if (aRandInt > 61)
        aRandInt = 61;
      temp[i] = alnum[aRandInt];
    }
    return new String(temp);
  }

  // creates a random string of numeric characters
  public static String create_random_n_string(int lo,
                                               int hi) {
    int i, actual_length;

    actual_length = random(lo, hi);
    char [] temp = new char[actual_length];
    for (i=0;i < actual_length; i++) {
      temp[i] = (char)random(48, 57);
    }
    return new String(temp);
  }


  public static float 
     create_random_float_val_return(float val_lo,
                                    float val_hi,
                                    float precision) {
    float f,result ;

    f = (float)r.nextFloat()*(val_hi-val_lo)+val_lo ;
    result = f - (float)Math.IEEEremainder(f,precision);
    return result;
  }

  public static String 
     create_a_string_with_original(int length_lo,
                                   int length_hi,
                                   float percent_to_set) {
    long f;
    int actual_length, start_pos;
    int i;
    char [] temp;

    actual_length = random(length_lo, length_hi);
    temp = new char[actual_length];

    for (i=0;i < actual_length; i++) {
      temp[i] = (char)random(48, 57);
    }

    f = random(0, 100);
    if (f < percent_to_set) {
      start_pos = random(0, temp.length-8);
      originalText.getChars(0, 8, temp, start_pos);
    }

    return new String(temp);
  }

  public static String 
     create_a_string_with_original(int length_lo,
                                   int length_hi,
                                   float percent_to_set,
                                   Integer hit) {
    long f;
    int actual_length, start_pos;
    char [] temp;
    int i;

    actual_length = random(length_lo, length_hi);
    temp = new char[actual_length];

    for (i=0;i < actual_length; i++) {
      temp[i] = (char)random(48, 57);
    }

    f = random(0, 100);
    if (f < percent_to_set) {
      start_pos = random(0, temp.length-8);
      originalText.getChars(0, 8, temp, start_pos);
    }

    return new String(temp);
  }

  public static String 
     create_random_last_name(int cust_num) {
    int random_num;
    String temp;

    if (cust_num == 0)
     random_num = NUrand_val( A_C_LAST, 0, 999, C_C_LAST );
    else
      random_num = cust_num - 1;

    temp = last_name_parts[random_num / 100];
    random_num %= 100;
    temp = temp + last_name_parts[random_num / 10];
    random_num %= 10;
    temp = temp + last_name_parts[random_num];

    return temp;
  }

  public static int NUrand_val ( int A,
                                 int x,
                                 int y,
                                 int C ) {
    return (((((random(0,A)|random(x,y))+C)%(y-x+1))+x));
  }


  public static void SecondsToSleep(long seconds) {
    try {
      // convert seconds to milliseconds
      Thread.currentThread().sleep(seconds * 1000);
    } catch (InterruptedException e) {
      Butil.textOut("  --> Exception: SLEEP INTERRUPTED!");
    }
  }

  public static void SecondsToSleep(double seconds) {
    long mills = (long)(seconds * 1000.0d);
    try {
      // convert seconds to milliseconds
      Thread.currentThread().sleep(mills);
    } catch (InterruptedException e) {
      Butil.textOut("  --> Exception: SLEEP INTERRUPTED!");
    }
  }

  public static double negativeExpDistribution(double mean) {
    double t;
    t = (-Math.log(r.nextFloat())) * mean;
    return t;
  }

  /**
  * Helper method to read a number.
  */
  public synchronized static int getNumericInput() {

    BufferedReader input = 
    new BufferedReader(new InputStreamReader(System.in));

    String keyboard_input;
    int number = 0;
    try {
      keyboard_input = input.readLine();
      number = Integer.valueOf(keyboard_input).intValue();
    } catch (IOException exception) {
      Butil.textOut("An IO Exception occured");
    } catch (NumberFormatException exception) {
      Butil.textOut("Invalid numeric entered");
      number = NON_NUMERIC_ENTRY;
    }
    return number;
  }

  public static void textOut(String text) {
     System.out.println(text);
  }
}
