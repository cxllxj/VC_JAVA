// This source is an example application.
// You are granted a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// There, therefore is, not guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL WE BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
package ch5.ex1;
import java.rmi.RemoteException;
import java.util.Properties;
import javax.transaction.*;
import javax.naming.InitialContext;
import javax.naming.Context;
import com.ibm.ejs.client.EJClient;
import javax.rmi.PortableRemoteObject;

public class OrderApp {

  static double duration, reqsPerSec, calibrate;
  static long start, finish;

  // static data
  private static InitialContext rootContext;
  // The following two Strings are dependent on the particular
  // Enterprise Java Server (EJS) provider that you use.
  private static String factoryName =
  "com.ibm.ejs.ns.jndi.CNInitialContextFactory";
  private static String provider="iiop://localhost:900";

  // Pass the number of iterations and the id of the Order as
  // parameters. For example java ch5.ex1.OrderApp 10 1
  // will run 10 iterations on the Order with id 1. If the
  // Order does not exist, it will be created.
  public static void main(String args[]) {
    try {
      int iterations, orderId;
      int i = 0;

      // Prime a hash table with values in order to get an
      // InitialContext object.
      java.util.Hashtable env = new java.util.Hashtable();
      env.put(Context.PROVIDER_URL, provider);
      env.put(Context.INITIAL_CONTEXT_FACTORY, factoryName);

      // Create the initial context. This is used for looking 
      // up names in the Java Naming Directory Interface (JNDI)
      rootContext = new InitialContext(env);

      UserTransaction current = (UserTransaction)
                    rootContext.lookup("jta/usertransaction");

      OrderHome myOrderHome = getOrderHome();
      OrderlineHome orderlineHome = getOrderlineHome();

      iterations=Integer.parseInt(args[0],10);
      orderId = Integer.parseInt(args[1],10);

      getStartTime();
      // Start the transaction
      current.begin();

      // Use the provided order id as the key
      OrderKey myOrderKey=new OrderKey(orderId);
      Order myOrder = null;
      Orderline currentLine = null;

      try { // attempt to find an existing order
        myOrder = myOrderHome.findByPrimaryKey(myOrderKey);
      } catch (javax.ejb.ObjectNotFoundException e) {
        
      }

      if (myOrder == null) { // no order existed
        System.out.println("Create the Order");
        myOrder = myOrderHome.create(orderId, "Steve");

        // Order a bunch of waffles
        for (i=0; i<iterations; i++) {
          currentLine = orderlineHome.create(i, orderId, 
                                             "Waffles", 
                                             3, i);
        }      
      } else
        System.out.println("The Order was found.");

      current.commit();

      getDuration();
      if (i > 0)
        System.out.println("A total of " + iterations 
                           + " iterations were run.");

      OrderlineKey lineKey=new OrderlineKey();

      // Time orderline updating operations
      getStartTime();
      // Order more pancakes
      for (i=0; i<iterations; i++) {
        current.begin();
        lineKey.setId(i);
        lineKey.setOrderId(orderId);

        currentLine=orderlineHome.findByPrimaryKey(lineKey);

        int currentQuantity = currentLine.getQuantity();

        // double the order!!!
        currentLine.setQuantity(currentQuantity*2);
        current.commit();
      }

      getDuration();
      System.out.println("A total of " + iterations 
               + " iterations were run in the second phase.");

      // Time some empty transactions for comparison
      getStartTime();
      for (i=0; i<iterations; i++) {
        current.begin();
        current.commit();
      }
      getDuration();
      System.out.println("A total of " + iterations 
               + " iterations were run in empty transactions.");

    } catch (RemoteException e) {
      e.printStackTrace();
    } catch (NullPointerException e) {
      e.printStackTrace();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  private static OrderHome getOrderHome () {
    Object obj = null;
    try {
      obj = rootContext.lookup("OrderHome");
      return (OrderHome) PortableRemoteObject.narrow(obj,
                                             OrderHome.class);
    } catch (javax.naming.NamingException e) {
      e.printStackTrace();
      return null;
    }
  }

  private static OrderlineHome getOrderlineHome () {
    Object obj = null;
    try {
      obj = rootContext.lookup("OrderlineHome");
      return (OrderlineHome)PortableRemoteObject.narrow(obj,
                                         OrderlineHome.class);
    } catch (javax.naming.NamingException e) {
      e.printStackTrace();
      return null;
    }
  }

  static void getStartTime() {
    start = System.currentTimeMillis();
  }

  static void getDuration() {
    finish = System.currentTimeMillis();
    duration = ((double)(finish - start));
    System.out.println("Elapsed milliseconds: "
                       +(finish-start));
    if (duration <= 0) duration = 0.00000001;
  }
}