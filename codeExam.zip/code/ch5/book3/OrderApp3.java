// This source is an example application.
// You are granted a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// There, therefore is, not guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL WE BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
package book3;
import java.rmi.RemoteException;
import java.util.Properties;
import javax.transaction.*;
import javax.naming.InitialContext;
import javax.naming.Context;

public class OrderApp3 {

  static double duration, reqsPerSec, calibrate;
  static long start, finish;

  // static data
  private static InitialContext theRootContext;

  public static void main(String args[]) {
    try {

      int iterations, i, orderId;

      Properties p = new Properties();
      p.put(Context.INITIAL_CONTEXT_FACTORY, "com.ibm.ejb.cb.runtime.CBCtxFactory");

      String bootstrapHostname;

      if (args.length > 2)
        bootstrapHostname = args[2];
      else
        bootstrapHostname = "/";

      System.out.println("PROVIDER_URL string is iiop://" + bootstrapHostname );
      p.put(Context.PROVIDER_URL, "iiop://" + bootstrapHostname );
      theRootContext = new InitialContext(p);

      UserTransaction current = (UserTransaction)theRootContext.lookup("jta/usertransaction");

      Order3Home myOrderHome = getOrder3Home();
      Orderline3Home myOrderlineHome = getOrderline3Home();

      iterations=Integer.parseInt(args[0],10);

      orderId = Integer.parseInt(args[1],10);

      current.begin();
     
      Order3Key myOrderKey=new Order3Key(orderId);
      Order3 myOrder = null;
      Orderline3 currentLine = null;

      try {
        myOrder = myOrderHome.findByPrimaryKey(myOrderKey);
      } catch (javax.ejb.ObjectNotFoundException e) {
        
      }

      if (myOrder == null) {
        System.out.println( "Create the Order");
        myOrder = myOrderHome.create(orderId);
      
        // Order a bunch of waffles
        for (i=0; i<iterations; i++) {
          currentLine = myOrderlineHome.create(i, orderId, "Waffles", 3, i);
        }      
      } else
        System.out.println("The Order was found.");

      getStartTime();

      current.commit();

      getDuration();
      System.out.println("A total of " + iterations + " iterations were run in the first phase.");
      System.out.println("A total of " + duration + " milliseconds were spent.");
      
      Orderline3Key myOrderlineKey=new Orderline3Key();
      myOrderlineKey.setOrderId(orderId);

      getStartTime();
      // Order more pancakes
      for (i=0; i<iterations; i++) {
        current.begin();
        myOrderlineKey.setId(i);

        OrderlineInfo currentLineInfo = myOrder.getLineInfo(myOrderlineKey);

        int currentQuantity = currentLineInfo.getQuantity();

        // double the order!!!
        currentLineInfo.setQuantity(currentQuantity*2);

        myOrder.setLineInfo(currentLineInfo);
        current.commit();
      }

      getDuration();
      System.out.println("A total of " + iterations + " iterations were runin the second phase.");
      System.out.println("A total of " + duration + " milliseconds were spent.");
    } catch (RemoteException e) {
      e.printStackTrace();
    } catch (NullPointerException e) {
      e.printStackTrace();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  private static Order3Home getOrder3Home () {
    try {
      java.lang.Object obj = theRootContext.lookup("Order3Home");
      return (Order3Home) javax.rmi.PortableRemoteObject.narrow (obj, Order3Home.class);
    } catch (javax.naming.NamingException e) {
      e.printStackTrace();
      return null;
    }
  }

  private static Orderline3Home getOrderline3Home () {
    try {
      java.lang.Object obj = theRootContext.lookup("Orderline3Home");
      return (Orderline3Home) javax.rmi.PortableRemoteObject.narrow (obj, Orderline3Home.class);
    } catch (javax.naming.NamingException e) {
      e.printStackTrace();
      return null;
    }
  }

  static void getStartTime() {
    start = System.currentTimeMillis();
  }

  static void getDuration() {
    finish = System.currentTimeMillis();
    duration = ((double)(finish - start))/1000.0;
    System.out.println("Elapsed milliseconds: "+(finish-start));
    System.out.println("duration is " + duration);
    if (duration <= 0) duration = 0.00000001;
  }
}