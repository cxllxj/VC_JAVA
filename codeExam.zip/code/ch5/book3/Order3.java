// This source is an example application.
// You are granted a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// There, therefore is, not guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL WE BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
package book3;

public interface Order3 extends javax.ejb.EJBObject {
  // Return the id of the order
  public long getId() throws java.rmi.RemoteException, Order3Exception; 
  // Set the id of the order
  public void setId(long inId) throws java.rmi.RemoteException;
  // get local information on a line
  OrderlineInfo getLineInfo(Orderline3Key lineKey) throws java.rmi.RemoteException;
  // set line information
  void setLineInfo(OrderlineInfo info) throws java.rmi.RemoteException;
}


