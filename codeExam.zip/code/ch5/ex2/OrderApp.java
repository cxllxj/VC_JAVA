// This source is an example application.
// You are granted a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// There, therefore is, not guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL WE BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
package ch5.ex2;
import java.rmi.RemoteException;
import java.util.Properties;
import javax.transaction.*;
import javax.naming.InitialContext;
import javax.naming.Context;
import javax.rmi.PortableRemoteObject;

public class OrderApp {
  // static data
  private static long start, finish;
  private static InitialContext rootContext;
  // The following two Strings are dependent on the particular
  // Enterprise Java Server (EJS) provider that you use.
  private static String factoryName =
  "com.ibm.ejs.ns.jndi.CNInitialContextFactory";
  private static String provider="iiop://localhost:900";

  // Pass the number of iterations and the id of the Order as
  // parameters. For example java ch5.ex1.OrderApp 10 1
  // will run 10 iterations on the Order with id 1. If the
  // Order does not exist, it will be created.
  public static void main(String args[]) {
    try {

      int iterations, orderId;
      int i = 0;

      // Prime a hash table with values in order to get an
      // InitialContext object.
      java.util.Hashtable env = new java.util.Hashtable();
      env.put(Context.PROVIDER_URL, provider);
      env.put(Context.INITIAL_CONTEXT_FACTORY, factoryName);

      // Create the initial context. This is used for looking 
      // up names in the Java Naming Directory Interface (JNDI)
      rootContext = new InitialContext(env);

      UserTransaction current = (UserTransaction)
                    rootContext.lookup("jta/usertransaction");

      OrderHome myOrderHome = getOrderHome();

      iterations = Integer.parseInt(args[0],10);

      orderId = Integer.parseInt(args[1],10);

      // Start the transaction
      current.begin();

      // see if an order already exists
      OrderKey myOrderKey=new OrderKey(orderId);
      Order myOrder = null;
      try {
        myOrder = myOrderHome.findByPrimaryKey(myOrderKey);
      } catch (javax.ejb.ObjectNotFoundException e) {
        
      }

      if (myOrder == null) { // no order existed
        System.out.println( "Create the Order");
        myOrder = myOrderHome.create(orderId);
      } else
        System.out.println("The Order was found.");

      getStartTime();

      Orderline currentLine = new OrderlineImpl();

      currentLine.setDescription("Waffles");
      currentLine.setItemId(3);
      java.util.Random rand = 
            new java.util.Random(System.currentTimeMillis());

      // Order a bunch of waffles
      for (i=0; i<iterations; i++) {
        currentLine.setQuantity(i);
        currentLine.setId(rand.nextInt());
        myOrder.addLine(currentLine);
      }

      current.commit();

      getDuration();
      System.out.println("A total of " + iterations 
               + " iterations were run in the first phase.");

      // Now modify the orders
      getStartTime();
      // Order more waffles
      for (i=0; i<iterations; i++) {
        current.begin();
        currentLine = myOrder.getNthLine(i);

        int currentQuantity = currentLine.getQuantity();

        // double the order!!!
        currentLine.setQuantity(currentQuantity*2);
        myOrder.updateLine(currentLine);
        current.commit();
      }

      getDuration();
      System.out.println("A total of " + iterations 
               + " iterations were runin the second phase.");
    } catch (RemoteException e) {
      e.printStackTrace();
    } catch (NullPointerException e) {
      e.printStackTrace();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  private static OrderHome getOrderHome () {
    try {
      java.lang.Object obj = 
         rootContext.lookup("OrderHome");
      return (OrderHome) 
            PortableRemoteObject.narrow(obj,OrderHome.class);
    } catch (javax.naming.NamingException e) {
      e.printStackTrace();
      return null;
    }
  }

  static void getStartTime() {
    start = System.currentTimeMillis();
  }

  static void getDuration() {
    finish = System.currentTimeMillis();
    System.out.println("Elapsed milliseconds: "
                       +(finish-start));
  }
}