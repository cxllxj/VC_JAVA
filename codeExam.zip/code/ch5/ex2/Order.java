// This source is an example application.
// You are granted a nonexclusive license to use this as an example
// from which you can generate similar function tailored to
// your own specific needs. This sample is provided in the form of source
// material which you may change and use. If you change the source, it is
// recommended that you first copy the source to a user directory.
//
// This sample code is provided for illustrative purposes only.
// These examples have not been thoroughly tested under all conditions.
// There, therefore is, not guarantee or imply reliability,serviceability,
// or function of these programs. All programs contained herein are
// provided to you "AS IS" without any warranties of any kind.
//
// THE IMPLIED WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGMENT
// ARE EXPRESSLY DISCLAIMED. SOME JURISDICTION DO NOT ALLOW
// THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS
// MAY NOT APPLY TO YOU. IN NO EVENT WILL WE BE LIABLE TO ANY PARTY
// FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER CONSEQUENTIAL
// DAMAGES FOR ANY USE OF THIS SAMPLE CODE INCLUDING, WITHOUT
// LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS
// OF PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM
// OR OTHERWISE, EVEN IF WE ARE EXPRESSLY ADVISED OF THE POSSIBILITY
// OF SUCH DAMAGES
//
package ch5.ex2;

public interface Order extends javax.ejb.EJBObject {
  // Add a line to the order.
  public void addLine(Orderline line) throws 
                                    java.rmi.RemoteException;
  // Remove the line from the Order
  public void removeLine(Orderline line) throws 
                                    java.rmi.RemoteException;
  // return the line in position lineNum
  public Orderline getNthLine(int lineNum) throws 
                                    java.rmi.RemoteException;
  // Update the line in the order
  public void updateLine(Orderline lineToUpdate) throws 
                                    java.rmi.RemoteException;
  // Get the name of the customer requesting the Order.
  public String getCustomerName() throws 
                                    java.rmi.RemoteException;
  // Set the name of the customer requesting the Order.
  public void setCustomerName(String name) throws 
                                    java.rmi.RemoteException;
}


