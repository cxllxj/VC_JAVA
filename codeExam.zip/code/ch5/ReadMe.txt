These examples require an EJB server.
